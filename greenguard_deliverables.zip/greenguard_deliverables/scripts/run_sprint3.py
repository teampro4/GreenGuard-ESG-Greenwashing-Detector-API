"""
scripts/run_sprint3.py
───────────────────────
Sprint 3 master runner: Cross-Source Inconsistency Engine

Steps:
  1. Load external data from all three connectors (SEC, CDP, Sustainalytics)
  2. Run claim alignment for 5 target companies
  3. Run full inconsistency detection (numeric, temporal, scope, verification, controversy)
  4. Run temporal consistency analysis (CAGR, trajectory, anomaly detection)
  5. Compute Greenwashing Risk Scores for each company
  6. Generate portfolio-level comparison
  7. Log everything to MLflow
"""

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.connectors.external_data import ExternalDataRegistry
from src.inconsistency.alignment import ClaimAligner
from src.inconsistency.detector import InconsistencyDetector, InconsistencyReport
from src.inconsistency.temporal_checker import TemporalConsistencyChecker
from src.config import get_config
from src.tracking.mlflow_tracker import ExperimentTracker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("sprint3_runner")

# ── Test claims per company ────────────────────────────────────────────────────
# Realistic ESG claims for each company, including deliberate inconsistencies
COMPANY_CLAIMS: list[dict] = [
    # ── Apple (AAPL) — well-reported, minor issues ──
    {"ticker":"AAPL","name":"Apple Inc.","year":2023,"sector":"Technology","claims":[
        {"text":"Apple's Scope 1 and Scope 2 market-based emissions totalled approximately 50,000 tCO2e in fiscal 2023, representing a 58% reduction from 2016 levels, independently limited-assured by Bureau Veritas.","company_ticker":"AAPL","report_year":2023},
        {"text":"We have maintained 100% renewable electricity across all our operations since 2018, procured through power purchase agreements and unbundled energy attribute certificates.","company_ticker":"AAPL","report_year":2023},
        {"text":"Our Scope 3 emissions — representing more than 99% of our total carbon footprint — were 21.37 million metric tonnes CO2e in fiscal 2023.","company_ticker":"AAPL","report_year":2023},
        {"text":"Apple is committed to becoming carbon neutral across our entire supply chain and all products by 2030.","company_ticker":"AAPL","report_year":2023},
    ]},
    # ── ExxonMobil (XOM) — high-risk, scope omission, controversy ──
    {"ticker":"XOM","name":"ExxonMobil Corp.","year":2023,"sector":"Energy","claims":[
        {"text":"ExxonMobil reduced its Scope 1 and Scope 2 greenhouse gas emissions intensity by 18% between 2016 and 2023, exceeding our 2025 reduction target of 15%.","company_ticker":"XOM","report_year":2023},
        {"text":"We have invested $17 billion in lower-emission energy solutions since 2000, demonstrating our commitment to the energy transition.","company_ticker":"XOM","report_year":2023},
        {"text":"Our methane intensity from operated assets was 0.18% in 2023, a 14% improvement from 0.21% in 2022.","company_ticker":"XOM","report_year":2023},
        {"text":"ExxonMobil is committed to achieving net zero Scope 1 and Scope 2 emissions from our operated assets by 2050, consistent with the goals of the Paris Agreement.","company_ticker":"XOM","report_year":2023},
    ]},
    # ── Microsoft (MSFT) — strong discloser, target trajectory check ──
    {"ticker":"MSFT","name":"Microsoft Corp.","year":2023,"sector":"Technology","claims":[
        {"text":"Microsoft's direct Scope 1 and market-based Scope 2 GHG emissions totalled approximately 16,000 tCO2e in fiscal year 2023, limited-assured by PwC.","company_ticker":"MSFT","report_year":2023},
        {"text":"We purchased sufficient renewable energy certificates and power purchase agreements to match 100% of our electricity consumption in 2023.","company_ticker":"MSFT","report_year":2023},
        {"text":"Our Scope 3 emissions were approximately 13 million metric tonnes CO2e, representing 99% of our total carbon footprint, primarily from purchased goods and services.","company_ticker":"MSFT","report_year":2023},
        {"text":"Microsoft has committed to being carbon negative by 2030 and to removing all historical carbon emissions by 2050.","company_ticker":"MSFT","report_year":2023},
    ]},
    # ── BP (BP) — transition claims, temporal anomaly ──
    {"ticker":"BP","name":"BP plc","year":2023,"sector":"Energy","claims":[
        {"text":"BP's Scope 1 and 2 greenhouse gas emissions were 40.1 million tonnes of CO2 equivalent in 2023, a 5.6% reduction compared to 2022, independently limited-assured by EY.","company_ticker":"BP","report_year":2023},
        {"text":"We are committed to achieving net zero across our operations on an absolute basis by 2050 or sooner, with an interim target of a 20% reduction by 2025 versus a 2019 baseline.","company_ticker":"BP","report_year":2023},
        {"text":"BP invested $8.2 billion in low and zero carbon energy in 2023, more than double our 2022 investment level, as we accelerate our transition to a diversified energy company.","company_ticker":"BP","report_year":2023},
        {"text":"Our methane intensity for operations within our reporting boundary was 0.08% in 2023, better than our 2025 target of below 0.10%.","company_ticker":"BP","report_year":2023},
    ]},
    # ── Nike (NKE) — selective disclosure, scope omission ──
    {"ticker":"NKE","name":"Nike Inc.","year":2023,"sector":"Consumer","claims":[
        {"text":"Nike's direct Scope 1 and market-based Scope 2 emissions were approximately 106,000 tCO2e and 35,000 tCO2e respectively in fiscal 2023.","company_ticker":"NKE","report_year":2023},
        {"text":"We sourced 78% of our electricity from renewable sources in fiscal 2023, on track to reach 100% by fiscal 2025.","company_ticker":"NKE","report_year":2023},
        {"text":"Nike is committed to reducing absolute GHG emissions across our owned-and-operated facilities by 70% by fiscal 2025 versus a fiscal 2015 baseline.","company_ticker":"NKE","report_year":2023},
        {"text":"We are deeply committed to a sustainable future and strive to design products that minimise environmental impact across the full lifecycle.","company_ticker":"NKE","report_year":2023},
    ]},
]


def main() -> None:
    config = get_config()
    tracker = ExperimentTracker.from_config(config)
    out_dir = config.paths.outputs / "evaluation" / "sprint3"
    out_dir.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 64)
    logger.info("SPRINT 3 — CROSS-SOURCE INCONSISTENCY ENGINE")
    logger.info("=" * 64)

    t_global = time.time()

    with tracker.start_run("sprint3_inconsistency"):
        tracker.log_config_snapshot(PROJECT_ROOT / "configs" / "config.yaml")
        tracker.log_param("sprint", 3)
        tracker.log_param("companies_analysed", len(COMPANY_CLAIMS))
        tracker.log_param("data_sources", "SEC_EDGAR,CDP,SUSTAINALYTICS")

        # ── Step 1: Load external data ───────────────────────────────────
        logger.info("\n── Step 1: Loading external data from 3 connectors ──")
        registry = ExternalDataRegistry(use_mock=True)
        tickers = [c["ticker"] for c in COMPANY_CLAIMS]

        ext_df = registry.to_dataframe(tickers)
        logger.info("  Total data points loaded: %d", len(ext_df))
        logger.info("  Tickers covered: %s", tickers)
        logger.info("  Metrics available: %s", sorted(ext_df["metric_name"].unique().tolist()))
        logger.info("  Sources: %s", ext_df["source"].value_counts().to_dict())

        ext_snap = registry.save(out_dir)
        tracker.log_artifact(ext_snap, "external_data")
        tracker.log_metric("ext_data_points", len(ext_df))
        tracker.log_metric("ext_sources", 3)
        ext_df.to_parquet(out_dir / "external_data.parquet", index=False)

        # ── Step 2: Claim alignment ─────────────────────────────────────
        logger.info("\n── Step 2: Claim-to-datapoint alignment ──")
        aligner   = ClaimAligner(registry)
        all_alignments = []

        for co in COMPANY_CLAIMS:
            for claim in co["claims"]:
                ar = aligner.align(
                    claim_text=claim["text"],
                    company_ticker=co["ticker"],
                    reporting_year=co["year"],
                )
                all_alignments.append({
                    "ticker": co["ticker"],
                    "claim_metric": ar.claim_metric,
                    "alignment_score": ar.alignment_score,
                    "is_aligned": ar.is_aligned(),
                    "numeric_match": ar.numeric_match,
                    "numeric_delta_pct": ar.numeric_delta_pct,
                    "nums_extracted": len(ar.extracted_nums),
                    "evidence": ar.evidence_text,
                    "claim_text": claim["text"][:120],
                })

        align_df = pd.DataFrame(all_alignments)
        aligned_count = align_df["is_aligned"].sum()
        logger.info("  Total claims: %d | Aligned to external data: %d (%.0f%%)",
                    len(align_df), aligned_count, aligned_count/len(align_df)*100)
        logger.info("  Metrics classified:")
        for m, cnt in align_df["claim_metric"].value_counts().items():
            logger.info("    %-40s %d", m, cnt)

        tracker.log_metric("total_claims_analysed", len(align_df))
        tracker.log_metric("claims_aligned_pct", round(aligned_count/len(align_df)*100, 1))
        align_df.to_parquet(out_dir / "alignment_results.parquet", index=False)
        tracker.log_artifact(out_dir / "alignment_results.parquet", "alignment")

        # ── Step 3: Inconsistency detection ─────────────────────────────
        logger.info("\n── Step 3: Running inconsistency detector ──")
        detector  = InconsistencyDetector(registry)
        reports: list[InconsistencyReport] = []

        for co in COMPANY_CLAIMS:
            report = detector.analyse_company(
                ticker=co["ticker"],
                company_name=co["name"],
                claims=co["claims"],
                report_year=co["year"],
            )
            reports.append(report)

            grs = report.greenwashing_risk_score
            logger.info(
                "\n  %s (%s) — GRS: %.1f (%s) | Flags: %d (%d CRIT, %d MED, %d LOW)",
                co["name"], co["ticker"], grs, report.risk_band,
                len(report.flags), report.n_critical, report.n_medium, report.n_low,
            )
            for flag in report.flags:
                icon = {"CRITICAL":"🔴","MEDIUM":"🟡","LOW":"🟢"}.get(flag.severity.value,"•")
                logger.info("    %s [%s] %s — %s",
                            icon, flag.inconsistency_type, flag.severity.value,
                            flag.explanation[:120])

            tracker.log_metric(f"grs_{co['ticker'].lower()}", grs)
            tracker.log_metric(f"flags_critical_{co['ticker'].lower()}", report.n_critical)
            tracker.log_metric(f"flags_total_{co['ticker'].lower()}", len(report.flags))

        # Save reports
        rep_path = detector.save_reports(reports, out_dir)
        sum_path = detector.save_summary(reports, out_dir)
        tracker.log_artifact(rep_path, "inconsistency")
        tracker.log_artifact(sum_path, "inconsistency")

        total_flags    = sum(len(r.flags) for r in reports)
        total_critical = sum(r.n_critical for r in reports)
        tracker.log_metric("total_flags", total_flags)
        tracker.log_metric("total_critical_flags", total_critical)
        tracker.log_metric("avg_grs", round(sum(r.greenwashing_risk_score for r in reports)/len(reports), 2))

        # ── Step 4: Temporal analysis ────────────────────────────────────
        logger.info("\n── Step 4: Temporal consistency analysis ──")
        temp_checker = TemporalConsistencyChecker(registry)
        all_insights = []
        sectors = {c["ticker"]: c["sector"] for c in COMPANY_CLAIMS}

        for ticker in tickers:
            insights = temp_checker.analyse_company(ticker, sector=sectors.get(ticker,"Technology"))
            for ins in insights:
                logger.info("  [%s] %s (%s): %s",
                            ticker, ins.insight_type, ins.severity, ins.description[:120])
                all_insights.append(ins.to_dict())

        trends_path = temp_checker.save_trends(tickers, out_dir)
        tracker.log_artifact(trends_path, "temporal")
        tracker.log_metric("temporal_insights_total", len(all_insights))
        tracker.log_metric("temporal_critical", sum(1 for i in all_insights if i["severity"]=="CRITICAL"))

        insights_path = out_dir / "temporal_insights.json"
        with open(insights_path, "w") as f:
            json.dump(all_insights, f, indent=2)
        tracker.log_artifact(insights_path, "temporal")

        # ── Step 5: Portfolio comparison ─────────────────────────────────
        logger.info("\n── Step 5: Portfolio-level GRS comparison ──")
        portfolio = pd.DataFrame([r.summary() for r in reports])
        portfolio = portfolio.sort_values("greenwashing_risk_score", ascending=False)
        logger.info("\n%s", portfolio[["company_ticker","greenwashing_risk_score","risk_band","total_flags","critical_flags"]].to_string(index=False))

        port_path = out_dir / "portfolio_summary.parquet"
        portfolio.to_parquet(port_path, index=False)
        tracker.log_artifact(port_path, "portfolio")

        # Scope 1 trend table
        trend_table = temp_checker.build_portfolio_trend_table(tickers, "scope_1_emissions_tco2e")
        logger.info("\n── Scope 1 Emissions Trend (tCO2e) ──")
        for t, data in trend_table.items():
            yrs_vals = list(zip(data["years"], data["values"]))
            logger.info("  %-8s  %s  CAGR: %s%%",
                        t,
                        "  ".join(f"{yr}: {val/1e6:.2f}Mt" for yr, val in yrs_vals),
                        data["cagr_pct"])

        total_time = time.time() - t_global
        tracker.log_metric("total_runtime_seconds", round(total_time, 2))

        logger.info("\n" + "=" * 64)
        logger.info("SPRINT 3 COMPLETE in %.1fs", total_time)
        logger.info("  Companies analysed   : %d", len(reports))
        logger.info("  External data points : %d", len(ext_df))
        logger.info("  Claims aligned       : %d / %d", aligned_count, len(align_df))
        logger.info("  Total flags raised   : %d (%d CRITICAL)", total_flags, total_critical)
        logger.info("  Temporal insights    : %d", len(all_insights))
        logger.info("  Highest GRS          : %s (%.1f)",
                    portfolio.iloc[0]["company_ticker"],
                    portfolio.iloc[0]["greenwashing_risk_score"])
        logger.info("=" * 64)

        return {
            "reports": reports,
            "portfolio": portfolio,
            "align_df": align_df,
            "all_insights": all_insights,
        }


if __name__ == "__main__":
    results = main()
