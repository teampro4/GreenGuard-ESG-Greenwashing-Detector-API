"""
scripts/run_sprint5.py
───────────────────────
Sprint 5: Evaluation, Benchmarking & Research

Steps:
  1.  Build 100-sample held-out evaluation corpus
  2.  Compute full classification metrics (F1, AUC, kappa)
  3.  Human-vs-system comparison
  4.  Sector-stratified performance analysis
  5.  Difficulty-stratified analysis
  6.  Module ablation study
  7.  Baseline comparisons (majority, TF-IDF only, Sprint 1 heuristic)
  8.  Error analysis (top confused pairs, hard cases)
  9.  Portfolio GRS accuracy review
  10. Log all results to MLflow + export JSON/Parquet
"""

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

import pandas as pd
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.annotation.corpus_builder import build_corpus
from src.evaluation.eval_corpus import build_eval_corpus, compute_eval_iaa
from src.evaluation.evaluator import Sprint5Evaluator
from src.config import get_config
from src.tracking.mlflow_tracker import ExperimentTracker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("sprint5_runner")


def main() -> dict:
    config  = get_config()
    tracker = ExperimentTracker.from_config(config)
    out_dir = config.paths.outputs / "evaluation" / "sprint5"
    out_dir.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 64)
    logger.info("SPRINT 5 — EVALUATION, BENCHMARKING & RESEARCH")
    logger.info("=" * 64)
    t_global = time.time()

    with tracker.start_run("sprint5_evaluation"):
        tracker.log_config_snapshot(PROJECT_ROOT / "configs" / "config.yaml")
        tracker.log_param("sprint", 5)
        tracker.log_param("eval_corpus_size", 100)

        # ── Step 1: Build corpora ────────────────────────────────────────
        logger.info("\n── Step 1: Building evaluation corpus ──")
        eval_df  = build_eval_corpus(seed=99)
        train_df = build_corpus(seed=42)
        iaa      = compute_eval_iaa(eval_df)

        logger.info("  Eval corpus : %d claims | label dist: %s", len(eval_df), iaa["label_dist"])
        logger.info("  Train corpus: %d claims", len(train_df))
        logger.info("  Eval IAA    : kappa=%.4f (%s) | agreement=%.1f%%",
                    iaa["cohen_kappa"], iaa["kappa_interpret"], iaa["agreement_rate"]*100)

        eval_df.to_parquet(out_dir / "eval_corpus.parquet", index=False)
        tracker.log_artifact(out_dir / "eval_corpus.parquet", "evaluation")
        tracker.log_metric("eval_iaa_kappa", iaa["cohen_kappa"])
        tracker.log_metric("eval_iaa_agreement", iaa["agreement_rate"])

        # ── Step 2: Load model + evaluate ───────────────────────────────
        logger.info("\n── Step 2: Full classification evaluation (n=100) ──")
        model_path = config.paths.models / "greenwashing_clf_sprint2.pkl"
        evaluator  = Sprint5Evaluator(model_path)
        metrics    = evaluator.evaluate(eval_df)

        logger.info("  F1 Macro   : %.4f", metrics["f1_macro"])
        logger.info("  F1 Weighted: %.4f", metrics["f1_weighted"])
        logger.info("  Accuracy   : %.4f", metrics["accuracy"])
        logger.info("  Kappa      : %.4f", metrics["cohen_kappa"])
        logger.info("  Runtime    : %dms for %d claims", metrics["runtime_ms"], metrics["n_samples"])
        logger.info("\n  Per-class:")
        for cls, m in metrics["per_class"].items():
            bar = "█" * int(m["f1"] * 20)
            logger.info("    %-14s  P=%.3f  R=%.3f  F1=%.3f  n=%2d  %s",
                        cls, m["precision"], m["recall"], m["f1"], m["support"], bar)
        if metrics["auc_per_class"]:
            logger.info("\n  AUC per class:")
            for cls, auc in metrics["auc_per_class"].items():
                logger.info("    %-14s  %.4f", cls, auc)

        tracker.log_metric("eval_f1_macro",    metrics["f1_macro"])
        tracker.log_metric("eval_f1_weighted", metrics["f1_weighted"])
        tracker.log_metric("eval_accuracy",    metrics["accuracy"])
        tracker.log_metric("eval_kappa",       metrics["cohen_kappa"])
        for cls, m in metrics["per_class"].items():
            tracker.log_metric(f"eval_f1_{cls.lower()}",        m["f1"])
            tracker.log_metric(f"eval_precision_{cls.lower()}", m["precision"])
            tracker.log_metric(f"eval_recall_{cls.lower()}",    m["recall"])

        # ── Step 3: Human-vs-system ──────────────────────────────────────
        logger.info("\n── Step 3: Human-vs-system comparison ──")
        hvs = evaluator.human_vs_system(eval_df)
        logger.info("  System kappa    : %.4f (%s)", hvs["system_kappa"],    hvs["system_kappa_interpretation"])
        logger.info("  Human kappa     : %.4f (%s)", hvs["human_kappa"],     hvs["human_kappa_interpretation"])
        logger.info("  System agreement: %.1f%%",    hvs["system_agreement_rate"] * 100)
        logger.info("  Human agreement : %.1f%%",    hvs["human_agreement_rate"]  * 100)
        logger.info("  Kappa gap       : %.4f",      hvs["kappa_gap"])
        logger.info("  Per-class system agreement:")
        for cls, agr in sorted(hvs["per_class_system_agreement"].items(), key=lambda x: -x[1]):
            logger.info("    %-14s %.1f%%", cls, agr * 100)

        tracker.log_metric("hvs_system_kappa", hvs["system_kappa"])
        tracker.log_metric("hvs_human_kappa",  hvs["human_kappa"])
        tracker.log_metric("hvs_kappa_gap",    hvs["kappa_gap"])

        # ── Step 4: Sector analysis ──────────────────────────────────────
        logger.info("\n── Step 4: Sector-stratified performance ──")
        sector_res = evaluator.sector_analysis(eval_df)
        for sector, m in sorted(sector_res.items(), key=lambda x: -x[1]["f1_macro"]):
            logger.info("  %-15s  n=%2d  F1=%.3f  Acc=%.3f",
                        sector, m["n"], m["f1_macro"], m["accuracy"])
            tracker.log_metric(f"sector_f1_{sector.lower().replace(' ','_')}", m["f1_macro"])

        # ── Step 5: Difficulty analysis ──────────────────────────────────
        logger.info("\n── Step 5: Difficulty-stratified performance ──")
        diff_res = evaluator.difficulty_analysis(eval_df)
        for lvl in ["easy", "medium", "hard"]:
            m = diff_res.get(lvl, {})
            logger.info("  %-8s  n=%2d  F1=%.3f  Acc=%.3f",
                        lvl, m.get("n", 0), m.get("f1_macro", 0), m.get("accuracy", 0))
            tracker.log_metric(f"difficulty_f1_{lvl}", m.get("f1_macro", 0))

        # ── Step 6: Baselines ────────────────────────────────────────────
        logger.info("\n── Step 6: Baseline comparisons ──")
        baselines = evaluator.baseline_comparison(train_df, eval_df)
        logger.info("  %-30s  F1=%.4f  Acc=%.4f", "Majority class",      baselines["majority_class"]["f1_macro"],     baselines["majority_class"]["accuracy"])
        logger.info("  %-30s  F1=%.4f  Acc=%.4f", "TF-IDF only LR",      baselines["tfidf_only_lr"]["f1_macro"],      baselines["tfidf_only_lr"]["accuracy"])
        logger.info("  %-30s  F1=%.4f  Acc=%.4f", "Sprint 1 heuristic",  baselines["sprint1_heuristic"]["f1_macro"],  baselines["sprint1_heuristic"]["accuracy"])
        logger.info("  %-30s  F1=%.4f  Acc=%.4f", "Our model (Sprint 2)", baselines["our_model_sprint2"]["f1_macro"],  baselines["our_model_sprint2"]["accuracy"])
        improvement = baselines["our_model_sprint2"]["f1_macro"] - baselines["tfidf_only_lr"]["f1_macro"]
        logger.info("  Lift vs TF-IDF only: +%.4f F1 macro", improvement)
        for name, m in baselines.items():
            tracker.log_metric(f"baseline_f1_{name}", m["f1_macro"])

        # ── Step 7: Module ablation ──────────────────────────────────────
        logger.info("\n── Step 7: Module ablation study ──")
        ablation = evaluator.module_ablation(train_df, eval_df)
        for variant, m in ablation.items():
            logger.info("  %-35s  F1=%.4f", variant, m["f1_macro"])
            tracker.log_metric(f"ablation_f1_{variant[:20]}", m["f1_macro"])

        # ── Step 8: Error analysis ───────────────────────────────────────
        logger.info("\n── Step 8: Error analysis ──")
        errors = evaluator.error_analysis(eval_df)
        logger.info("  Total errors  : %d / %d (%.1f%%)",
                    errors["total_errors"], len(eval_df), errors["error_rate"] * 100)
        logger.info("  Top confused pairs:")
        for pair in errors["top_confused_pairs"]:
            logger.info("    %-14s → %-14s  (n=%d)", pair["true"], pair["predicted"], pair["count"])
        tracker.log_metric("error_rate",    errors["error_rate"])
        tracker.log_metric("total_errors",  errors["total_errors"])

        # ── Save all results ─────────────────────────────────────────────
        all_results = {
            "eval_iaa":      iaa,
            "metrics":       metrics,
            "human_vs_system": hvs,
            "sector":        sector_res,
            "difficulty":    diff_res,
            "baselines":     baselines,
            "ablation":      ablation,
            "errors":        errors,
        }
        results_path = out_dir / "sprint5_full_results.json"
        with open(results_path, "w") as f:
            json.dump(all_results, f, indent=2, default=str)
        tracker.log_artifact(results_path, "evaluation")

        total_time = time.time() - t_global
        tracker.log_metric("total_runtime_seconds", round(total_time, 2))

        logger.info("\n" + "=" * 64)
        logger.info("SPRINT 5 COMPLETE in %.1fs", total_time)
        logger.info("  Eval corpus        : %d claims (held-out)", len(eval_df))
        logger.info("  F1 Macro           : %.4f (target was >= 0.75)", metrics["f1_macro"])
        logger.info("  System kappa       : %.4f (%s)", hvs["system_kappa"], hvs["system_kappa_interpretation"])
        logger.info("  Lift vs TF-IDF     : +%.4f F1", improvement)
        logger.info("  Best sector        : %s (F1=%.3f)", max(sector_res, key=lambda k: sector_res[k]["f1_macro"]), max(v["f1_macro"] for v in sector_res.values()))
        logger.info("  Worst sector       : %s (F1=%.3f)", min(sector_res, key=lambda k: sector_res[k]["f1_macro"]), min(v["f1_macro"] for v in sector_res.values()))
        logger.info("  Error rate         : %.1f%%", errors["error_rate"] * 100)
        logger.info("=" * 64)

        return all_results


if __name__ == "__main__":
    results = main()
