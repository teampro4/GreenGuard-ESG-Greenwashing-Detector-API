"""
scripts/run_sprint2.py
───────────────────────
Sprint 2 master runner: Claim Classification & Semantic Index

Steps:
  1. Build annotated corpus (128 labelled claims)
  2. Compute inter-annotator agreement
  3. Train/test split (80/20, stratified)
  4. Train GreenwashingClassifier (TF-IDF + ESG features + Logistic Regression)
  5. Evaluate on held-out test set
  6. Run ablation study (7 feature variants)
  7. Build semantic similarity index
  8. Find near-duplicate claims
  9. Demo: inference on new claims
  10. Log everything to MLflow
"""

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.annotation.corpus_builder import build_corpus, compute_iaa_stats
from src.classification.greenwashing_classifier import GreenwashingClassifier, SemanticIndex
from src.classification.ablation import run_ablation
from src.config import get_config
from src.tracking.mlflow_tracker import ExperimentTracker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("sprint2_runner")

DEMO_INFERENCE_TEXTS = [
    "We are committed to a greener future and strive to minimise our impact.",
    "Our Scope 1+2 emissions fell 42% vs 2019 baseline, verified by Bureau Veritas (ISO 14064-3).",
    "We achieve carbon neutrality today through offsets — our Scope 3 remains untracked.",
    "The Company is the most sustainable airline in the world having offset 100% of all emissions.",
    "Our 2023 GHG inventory was limited-assured by KPMG; total Scope 1+2: 87,400 tCO2e, a 28% reduction vs 2018.",
    "By 2030, we plan to reduce emissions by 40% — no methodology or baseline year specified.",
    "Gender pay gap audit (Korn Ferry, 2023): adjusted gap 1.2%, within our <2% target.",
    "We are deeply passionate about biodiversity and strive to be good environmental stewards.",
    "Our packaging is 100% sustainable — made with 8% recycled content, 92% virgin plastic.",
    "We reduced absolute Scope 1 emissions 18% in 2023 — driven by plant closures, not efficiency.",
]


def main() -> None:
    config = get_config()
    tracker = ExperimentTracker.from_config(config)

    logger.info("=" * 64)
    logger.info("SPRINT 2 — CLAIM CLASSIFICATION & SEMANTIC INDEX")
    logger.info("=" * 64)

    t_global = time.time()

    with tracker.start_run("sprint2_classification"):
        tracker.log_config_snapshot(PROJECT_ROOT / "configs" / "config.yaml")
        tracker.log_param("sprint", 2)
        tracker.log_param("classifier", "LogisticRegression+TF-IDF+ESGFeatures")
        tracker.log_param("calibration", "CalibratedClassifierCV(cv=3, sigmoid)")

        # ── Step 1: Build corpus ─────────────────────────────────────────
        logger.info("\n── Step 1: Building annotated corpus ──")
        corpus_df = build_corpus(seed=42)
        iaa = compute_iaa_stats(corpus_df)
        logger.info("  Corpus: %d claims | %d labels | kappa=%.4f (%s)",
                    iaa["total_claims"], len(iaa["label_distribution"]),
                    iaa["cohen_kappa"], iaa["kappa_interpretation"])
        logger.info("  Label dist: %s", iaa["label_distribution"])
        logger.info("  IAA agreement rate: %.1f%%", iaa["raw_agreement_rate"] * 100)

        for k, v in iaa.items():
            if isinstance(v, (int, float)):
                tracker.log_metric(f"iaa_{k}", v)
        tracker.log_param("corpus_size", iaa["total_claims"])
        tracker.log_param("iaa_kappa_interpretation", iaa["kappa_interpretation"])

        # Save corpus
        corpus_path = config.paths.data_annotated / "annotated_corpus_sprint2.parquet"
        corpus_df.to_parquet(corpus_path, index=False)
        tracker.log_artifact(corpus_path, "datasets")

        # ── Step 2: Train/test split ─────────────────────────────────────
        logger.info("\n── Step 2: Train/test split (80/20 stratified) ──")
        texts = corpus_df["text"].tolist()
        labels = corpus_df["label"].tolist()

        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels, test_size=0.20, stratify=labels, random_state=42
        )
        logger.info("  Train: %d | Test: %d", len(X_train), len(X_test))
        tracker.log_param("train_size", len(X_train))
        tracker.log_param("test_size", len(X_test))

        # ── Step 3: Train classifier ─────────────────────────────────────
        logger.info("\n── Step 3: Training GreenwashingClassifier ──")
        clf = GreenwashingClassifier(C=1.0, max_iter=1000)
        clf.fit(X_train, y_train)
        logger.info("  Fit complete in %.2fs | %d features",
                    clf.training_metrics["fit_time_s"],
                    clf.training_metrics["n_features"])

        # ── Step 4: Evaluate ─────────────────────────────────────────────
        logger.info("\n── Step 4: Evaluation on held-out test set ──")
        eval_metrics = clf.evaluate(X_test, y_test)

        logger.info("  F1 Macro   : %.4f", eval_metrics["f1_macro"])
        logger.info("  F1 Weighted: %.4f", eval_metrics["f1_weighted"])
        logger.info("  Cohen Kappa: %.4f", eval_metrics["cohen_kappa"])
        logger.info("\n  Per-class results:")
        for cls, m in eval_metrics["per_class_report"].items():
            logger.info("    %-14s  P=%.3f  R=%.3f  F1=%.3f  n=%d",
                        cls, m["precision"], m["recall"], m["f1"], m["support"])

        tracker.log_metric("test_f1_macro", eval_metrics["f1_macro"])
        tracker.log_metric("test_f1_weighted", eval_metrics["f1_weighted"])
        tracker.log_metric("test_cohen_kappa", eval_metrics["cohen_kappa"])
        for cls, m in eval_metrics["per_class_report"].items():
            tracker.log_metric(f"test_f1_{cls.lower()}", m["f1"])
            tracker.log_metric(f"test_precision_{cls.lower()}", m["precision"])
            tracker.log_metric(f"test_recall_{cls.lower()}", m["recall"])

        # Save model
        model_path = config.paths.models / "greenwashing_clf_sprint2.pkl"
        clf.save(model_path)
        metrics_path = config.paths.outputs / "evaluation" / "sprint2_eval_metrics.json"
        clf.save_metrics(metrics_path)
        tracker.log_artifact(model_path, "models")
        tracker.log_artifact(metrics_path, "evaluation")

        # ── Step 5: Cross-validation ─────────────────────────────────────
        logger.info("\n── Step 5: 5-fold stratified cross-validation ──")
        clf2 = GreenwashingClassifier(C=1.0, max_iter=1000)
        cv_results = clf2.cross_validate(texts, labels, cv=5)
        logger.info("  CV F1 Macro: %.4f ± %.4f",
                    cv_results["f1_macro_mean"], cv_results["f1_macro_std"])
        logger.info("  Per-fold:    %s", cv_results["f1_macro_scores"])
        tracker.log_metric("cv5_f1_macro_mean", cv_results["f1_macro_mean"])
        tracker.log_metric("cv5_f1_macro_std", cv_results["f1_macro_std"])

        # ── Step 6: Ablation study ───────────────────────────────────────
        logger.info("\n── Step 6: Ablation study (7 feature variants) ──")
        ablation_df = run_ablation(texts, labels, cv=5)
        logger.info("\n%s", ablation_df[["ablation", "f1_macro_mean", "f1_macro_std", "delta_vs_tfidf_only"]].to_string(index=False))

        ablation_path = config.paths.outputs / "evaluation" / "ablation_results.csv"
        ablation_df.to_csv(ablation_path, index=False)
        tracker.log_artifact(ablation_path, "evaluation")
        tracker.log_metric("ablation_best_f1", float(ablation_df["f1_macro_mean"].max()))
        tracker.log_metric("ablation_esg_feature_delta",
                           float(ablation_df.loc[ablation_df["ablation"].str.startswith("A"), "delta_vs_tfidf_only"].values[0]))

        # ── Step 7: Semantic index ───────────────────────────────────────
        logger.info("\n── Step 7: Building semantic similarity index ──")
        index = SemanticIndex(max_features=5000)
        index.build(texts, labels)
        dupes = index.find_duplicates(threshold=0.85)
        logger.info("  Index built: %d claims | vocabulary: %d terms",
                    len(texts), len(index.vectorizer.vocabulary_))
        logger.info("  Near-duplicate pairs found (sim >= 0.85): %d", len(dupes))

        index_path = config.paths.models / "semantic_index_sprint2.pkl"
        index.save(index_path)
        index_stats_path = config.paths.outputs / "evaluation" / "index_stats.json"
        index.save_index_stats(index_stats_path)
        tracker.log_artifact(index_path, "models")
        tracker.log_metric("index_vocabulary_size", len(index.vectorizer.vocabulary_))
        tracker.log_metric("near_duplicate_pairs", len(dupes))

        # ── Step 8: Demo inference ───────────────────────────────────────
        logger.info("\n── Step 8: Demo inference on 10 new claims ──")
        predictions = clf.predict_batch(DEMO_INFERENCE_TEXTS)
        inference_rows = []
        for txt, pred in zip(DEMO_INFERENCE_TEXTS, predictions):
            logger.info("  [%s | conf=%.2f]  %s",
                        pred["label"], pred["confidence"], txt[:90])

            # Nearest neighbours from index
            similar = index.find_similar(txt, top_k=2, threshold=0.15)

            inference_rows.append({
                "text": txt,
                "predicted_label": pred["label"],
                "confidence": pred["confidence"],
                "probabilities": pred["probabilities"],
                "nearest_neighbour": similar[0]["text"][:80] if similar else "",
                "nn_label": similar[0]["label"] if similar else "",
                "nn_similarity": similar[0]["similarity"] if similar else 0.0,
            })

        inference_df = pd.DataFrame(inference_rows)
        inf_path = config.paths.outputs / "evaluation" / "sprint2_inference_demo.json"
        inference_df.to_json(inf_path, orient="records", indent=2)
        tracker.log_artifact(inf_path, "evaluation")

        # ── Final summary ────────────────────────────────────────────────
        total_time = time.time() - t_global
        tracker.log_metric("total_runtime_seconds", round(total_time, 2))

        logger.info("\n" + "=" * 64)
        logger.info("SPRINT 2 COMPLETE in %.1fs", total_time)
        logger.info("  Corpus         : %d labelled claims", len(corpus_df))
        logger.info("  IAA Kappa      : %.4f (%s)", iaa["cohen_kappa"], iaa["kappa_interpretation"])
        logger.info("  Test F1 Macro  : %.4f", eval_metrics["f1_macro"])
        logger.info("  CV F1 Macro    : %.4f ± %.4f", cv_results["f1_macro_mean"], cv_results["f1_macro_std"])
        logger.info("  Best ablation  : %s",
                    ablation_df.loc[ablation_df["f1_macro_mean"].idxmax(), "ablation"])
        logger.info("  Model saved    : %s", model_path)
        logger.info("  Index saved    : %s", index_path)
        logger.info("=" * 64)

        return {
            "corpus_df": corpus_df,
            "iaa": iaa,
            "clf": clf,
            "eval_metrics": eval_metrics,
            "cv_results": cv_results,
            "ablation_df": ablation_df,
            "index": index,
            "inference_df": inference_df,
        }


if __name__ == "__main__":
    results = main()
