"""
scripts/run_sprint4.py
───────────────────────
Sprint 4: Explainability & Risk Scoring

Steps:
  1.  Fix Sprint 3 unit-type false positives in numeric alignment
  2.  Load Sprint 2 trained classifier
  3.  Compute SHAP attributions for all demo claims
  4.  Build global feature importance table
  5.  Run Sprint 3 inconsistency engine (with fixes applied)
  6.  Build evidence citation bundles for all flags
  7.  Generate LLM-powered natural language explanations
  8.  Generate PDF risk report per company
  9.  Produce portfolio summary
  10. Log everything to MLflow
"""

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.annotation.corpus_builder import build_corpus
from src.classification.greenwashing_classifier import GreenwashingClassifier
from src.connectors.external_data import ExternalDataRegistry
from src.inconsistency.alignment import ClaimAligner
from src.inconsistency.detector import InconsistencyDetector, InconsistencyReport
from src.inconsistency.temporal_checker import TemporalConsistencyChecker
from src.explainability.shap_explainer import LRSHAPExplainer
from src.explainability.evidence_citations import EvidenceCitationEngine
from src.explainability.explanation_generator import ExplanationGenerator
from src.explainability.risk_report import generate_company_report
from src.config import get_config
from src.tracking.mlflow_tracker import ExperimentTracker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("sprint4_runner")

# ── Same company claims as Sprint 3 ─────────────────────────────────────────
COMPANY_CLAIMS = [
    {"ticker":"AAPL","name":"Apple Inc.","year":2023,"sector":"Technology","claims":[
        {"text":"Apple's Scope 1 and Scope 2 market-based emissions totalled approximately 50,000 tCO2e in fiscal 2023, representing a 58% reduction from 2016 levels, independently limited-assured by Bureau Veritas.","company_ticker":"AAPL","report_year":2023},
        {"text":"We have maintained 100% renewable electricity across all our operations since 2018, procured through power purchase agreements and unbundled energy attribute certificates.","company_ticker":"AAPL","report_year":2023},
        {"text":"Our Scope 3 emissions — representing more than 99% of our total carbon footprint — were 21.37 million metric tonnes CO2e in fiscal 2023.","company_ticker":"AAPL","report_year":2023},
        {"text":"Apple is committed to becoming carbon neutral across our entire supply chain and all products by 2030.","company_ticker":"AAPL","report_year":2023},
    ]},
    {"ticker":"XOM","name":"ExxonMobil Corp.","year":2023,"sector":"Energy","claims":[
        {"text":"ExxonMobil reduced its Scope 1 and Scope 2 greenhouse gas emissions intensity by 18% between 2016 and 2023, exceeding our 2025 reduction target of 15%.","company_ticker":"XOM","report_year":2023},
        {"text":"We have invested $17 billion in lower-emission energy solutions since 2000, demonstrating our commitment to the energy transition.","company_ticker":"XOM","report_year":2023},
        {"text":"Our methane intensity from operated assets was 0.18% in 2023, a 14% improvement from 0.21% in 2022.","company_ticker":"XOM","report_year":2023},
        {"text":"ExxonMobil is committed to achieving net zero Scope 1 and Scope 2 emissions from our operated assets by 2050, consistent with the goals of the Paris Agreement.","company_ticker":"XOM","report_year":2023},
    ]},
    {"ticker":"BP","name":"BP plc","year":2023,"sector":"Energy","claims":[
        {"text":"BP's Scope 1 and 2 greenhouse gas emissions were 40.1 million tonnes of CO2 equivalent in 2023, a 5.6% reduction compared to 2022, independently limited-assured by EY.","company_ticker":"BP","report_year":2023},
        {"text":"We are committed to achieving net zero across our operations on an absolute basis by 2050 or sooner, with an interim target of a 20% reduction by 2025 versus a 2019 baseline.","company_ticker":"BP","report_year":2023},
        {"text":"BP invested $8.2 billion in low and zero carbon energy in 2023, more than double our 2022 investment level.","company_ticker":"BP","report_year":2023},
        {"text":"Our methane intensity for operations within our reporting boundary was 0.08% in 2023, better than our 2025 target of below 0.10%.","company_ticker":"BP","report_year":2023},
    ]},
    {"ticker":"NKE","name":"Nike Inc.","year":2023,"sector":"Consumer","claims":[
        {"text":"Nike's direct Scope 1 and market-based Scope 2 emissions were approximately 106,000 tCO2e and 35,000 tCO2e respectively in fiscal 2023.","company_ticker":"NKE","report_year":2023},
        {"text":"We sourced 78% of our electricity from renewable sources in fiscal 2023, on track to reach 100% by fiscal 2025.","company_ticker":"NKE","report_year":2023},
        {"text":"Nike is committed to reducing absolute GHG emissions across our owned-and-operated facilities by 70% by fiscal 2025 versus a fiscal 2015 baseline.","company_ticker":"NKE","report_year":2023},
        {"text":"We are deeply committed to a sustainable future and strive to design products that minimise environmental impact across the full lifecycle.","company_ticker":"NKE","report_year":2023},
    ]},
]


def _build_shap_summary(expl_list: list, top_k: int = 12) -> dict:
    """Aggregate SHAP attributions across multiple explanations."""
    from collections import defaultdict
    sums = defaultdict(lambda: {"total_abs": 0.0, "count": 0, "type": "", "direction_votes": []})
    for expl in expl_list:
        for attr in expl.top_attributions:
            sums[attr.feature_name]["total_abs"]    += attr.abs_shap
            sums[attr.feature_name]["count"]        += 1
            sums[attr.feature_name]["type"]          = attr.feature_type
            sums[attr.feature_name]["direction_votes"].append(attr.direction)

    rows = []
    for name, data in sorted(sums.items(), key=lambda x: -x[1]["total_abs"])[:top_k]:
        mean_abs = data["total_abs"] / max(data["count"], 1)
        votes = data["direction_votes"]
        direction = max(set(votes), key=votes.count) if votes else "neutral"
        feat_type = data["type"]

        interp_map = {
            "vagueness_score":              "High vagueness language detected",
            "specificity_score":            "Specific measurable claims present",
            "has_quantified_target":        "Numerical target present",
            "has_temporal_target":          "Target year detected",
            "has_third_party_verification": "External verifier cited",
            "kw_commitment_language":       "Pledge/commitment language",
            "kw_verified_standards":        "Standards (SBTi, ISO) cited",
            "kw_quantified":                "Quantification present",
            "kw_selective_disclosure":      "Selective disclosure language",
            "kw_awards_best_in_class":      "Superlative/leader claims",
            "kw_offset_heavy":              "Carbon offset language",
        }
        clean = name.replace("token:", "").replace("_", " ")
        interp = interp_map.get(name.replace("token:", ""), f'Text token: "{clean}"')

        rows.append({
            "feature":        clean[:35],
            "type":           feat_type,
            "mean_abs_shap":  round(mean_abs, 5),
            "direction":      direction,
            "interpretation": interp,
        })

    return {"top_features": rows}


def main() -> None:
    config   = get_config()
    tracker  = ExperimentTracker.from_config(config)
    out_dir  = config.paths.outputs / "evaluation" / "sprint4"
    rep_dir  = config.paths.outputs / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    rep_dir.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 64)
    logger.info("SPRINT 4 — EXPLAINABILITY & RISK SCORING")
    logger.info("=" * 64)
    t_global = time.time()

    with tracker.start_run("sprint4_explainability"):
        tracker.log_config_snapshot(PROJECT_ROOT / "configs" / "config.yaml")
        tracker.log_param("sprint", 4)

        # ── Step 1: Fix unit-type false positives ────────────────────────
        logger.info("\n── Step 1: Applying Sprint 3 unit-type fix ──")
        # Patch: add unit guard to ClaimAligner._check_numeric_mismatch
        # The fix is applied directly in the detector — only compare if units match
        from src.inconsistency import detector as det_module
        original_check = det_module.InconsistencyDetector._check_numeric_mismatch

        def _patched_check(self, ar, report):
            dp = ar.matched_dp
            if not dp:
                return
            # SPRINT 4 FIX: skip if extracted unit and dp unit are incompatible
            if ar.extracted_nums:
                extracted_unit = ar.extracted_nums[0].unit
                dp_unit = dp.metric_unit
                # Skip: percentage vs absolute, year vs tCO2e, etc.
                incompatible_pairs = [
                    ("%", "tCO2e"), ("year", "tCO2e"), ("year", "%"),
                    ("%", "Mt CO2e"), ("year", "Bn USD"),
                ]
                pair = (extracted_unit, dp_unit)
                rev  = (dp_unit, extracted_unit)
                if pair in incompatible_pairs or rev in incompatible_pairs:
                    logger.info("  [Unit fix] Skipping %s vs %s mismatch (%s → %s)",
                                extracted_unit, dp_unit, ar.claim_ticker, ar.claim_metric)
                    return
            original_check(self, ar, report)

        det_module.InconsistencyDetector._check_numeric_mismatch = _patched_check
        logger.info("  Unit-type guard patched into InconsistencyDetector")
        tracker.log_param("sprint3_fp_fix", "unit_type_guard_applied")

        # ── Step 2: Load Sprint 2 classifier ────────────────────────────
        logger.info("\n── Step 2: Loading Sprint 2 trained classifier ──")
        model_path = config.paths.models / "greenwashing_clf_sprint2.pkl"
        clf = GreenwashingClassifier.load(model_path)
        logger.info("  Classifier loaded | classes: %s", clf.training_metrics.get("classes"))

        # ── Step 3: SHAP attributions ────────────────────────────────────
        logger.info("\n── Step 3: Computing SHAP attributions ──")
        explainer = LRSHAPExplainer(model_path)

        # Fit baseline on training corpus
        corpus_df = build_corpus(seed=42)
        train_texts = corpus_df["text"].tolist()
        explainer.fit_baseline(train_texts)

        # Explain all company claims
        all_texts_flat = [c["text"] for co in COMPANY_CLAIMS for c in co["claims"]]
        all_expls = explainer.explain_batch(all_texts_flat)

        logger.info("  SHAP computed for %d claims", len(all_expls))
        logger.info("\n  Sample attributions:")
        for expl in all_expls[:3]:
            top_tokens = [a.feature_name.replace("token:", "") for a in expl.token_attributions[:3]]
            logger.info("  [%s conf=%.2f] drivers: %s | tokens: %s",
                        expl.predicted_label, expl.confidence,
                        expl.risk_drivers[0][:60] if expl.risk_drivers else "N/A",
                        ", ".join(top_tokens))

        # Save SHAP outputs
        shap_records = [e.to_dict() for e in all_expls]
        shap_path = out_dir / "shap_explanations.json"
        with open(shap_path, "w") as f:
            json.dump(shap_records, f, indent=2)
        tracker.log_artifact(shap_path, "explainability")
        tracker.log_metric("claims_shap_explained", len(all_expls))

        # Global feature importance
        global_fi = explainer.feature_importance_global(train_texts, corpus_df["label"].tolist())
        fi_path = out_dir / "global_feature_importance.parquet"
        global_fi.to_parquet(fi_path, index=False)
        tracker.log_artifact(fi_path, "explainability")
        logger.info("  Global FI computed: %d class x feature rows", len(global_fi))

        # ── Step 4: Re-run inconsistency engine (with fix) ───────────────
        logger.info("\n── Step 4: Re-running Sprint 3 engine (with unit fix) ──")
        registry = ExternalDataRegistry(use_mock=True)
        detector = InconsistencyDetector(registry)
        reports: list[InconsistencyReport] = []
        for co in COMPANY_CLAIMS:
            r = detector.analyse_company(co["ticker"], co["name"], co["claims"], co["year"])
            reports.append(r)

        total_flags_new = sum(len(r.flags) for r in reports)
        total_crit_new  = sum(r.n_critical for r in reports)
        logger.info("  Flags after fix: %d total (%d CRITICAL) — was 9 total, 7 CRITICAL",
                    total_flags_new, total_crit_new)
        tracker.log_metric("flags_after_fix_total",    total_flags_new)
        tracker.log_metric("flags_after_fix_critical", total_crit_new)
        tracker.log_metric("false_positives_eliminated", max(0, 9 - total_flags_new))

        # ── Step 5: Evidence citation bundles ────────────────────────────
        logger.info("\n── Step 5: Building evidence citation bundles ──")
        citation_engine = EvidenceCitationEngine()
        text_to_expl = {e.claim_text: e for e in all_expls}
        all_bundles = []
        for report in reports:
            bundles = citation_engine.build_bundles(report, text_to_expl)
            all_bundles.extend(bundles)

        cit_path = citation_engine.save(all_bundles, out_dir)
        tracker.log_artifact(cit_path, "explainability")
        tracker.log_metric("evidence_bundles_created", len(all_bundles))
        citations_with_shap = sum(
            1 for b in all_bundles
            if any(e.evidence_type == "shap_feature" for e in b.evidence_pieces)
        )
        logger.info("  Bundles created: %d | with SHAP evidence: %d",
                    len(all_bundles), citations_with_shap)
        tracker.log_metric("bundles_with_shap_evidence", citations_with_shap)

        # ── Step 6: LLM explanations ─────────────────────────────────────
        logger.info("\n── Step 6: Generating LLM-powered explanations ──")
        gen = ExplanationGenerator(use_api=True)
        logger.info("  API available: %s", gen._api_available)

        all_generated = []
        bundle_map = {b.flag_id: b for b in all_bundles}
        for report in reports:
            generated = gen.generate_batch(report, all_bundles)
            all_generated.extend(generated)
            for g in generated:
                logger.info("  [%s][%s] %s (%s)",
                            g.company_ticker, g.severity, g.explanation_short[:80],
                            g.generated_by)

        gen_path = gen.save(all_generated, out_dir)
        tracker.log_artifact(gen_path, "explainability")

        api_count      = sum(1 for g in all_generated if g.generated_by == "claude")
        template_count = sum(1 for g in all_generated if g.generated_by == "template")
        avg_ms         = sum(g.generation_time_ms for g in all_generated) / max(len(all_generated), 1)
        logger.info("  Generated: %d total | API: %d | Template: %d | Avg: %.0fms",
                    len(all_generated), api_count, template_count, avg_ms)
        tracker.log_metric("explanations_generated",      len(all_generated))
        tracker.log_metric("explanations_api",            api_count)
        tracker.log_metric("explanations_avg_latency_ms", round(avg_ms))

        # ── Step 7: Temporal analysis ────────────────────────────────────
        logger.info("\n── Step 7: Temporal consistency analysis ──")
        temp_checker = TemporalConsistencyChecker(registry)
        sectors = {c["ticker"]: c["sector"] for c in COMPANY_CLAIMS}
        ticker_insights: dict[str, list] = {}
        for co in COMPANY_CLAIMS:
            insights = temp_checker.analyse_company(co["ticker"], co.get("sector","Technology"))
            ticker_insights[co["ticker"]] = [i.to_dict() for i in insights]

        # ── Step 8: PDF reports ──────────────────────────────────────────
        logger.info("\n── Step 8: Generating PDF risk reports ──")
        expl_map = {g.flag_id: g.to_dict() for g in all_generated}
        pdf_paths = []

        for co, report in zip(COMPANY_CLAIMS, reports):
            ticker = co["ticker"]
            flag_dicts  = [f.to_dict() for f in report.flags]
            shap_expls  = [e for e in all_expls
                           if any(e.claim_text == c["text"] for c in co["claims"])]
            shap_summary = _build_shap_summary(shap_expls)
            t_insights = ticker_insights.get(ticker, [])
            exp_list = [expl_map[f["flag_id"]] for f in flag_dicts if f["flag_id"] in expl_map]

            pdf_path = rep_dir / f"ESG_Risk_Report_{ticker}_{co['year']}.pdf"
            generate_company_report(
                company_ticker=ticker,
                company_name=co["name"],
                report_year=co["year"],
                grs=report.greenwashing_risk_score,
                risk_band=report.risk_band,
                flags=flag_dicts,
                explanations=exp_list,
                evidence_bundles=[b.to_dict() for b in all_bundles
                                  if b.company_ticker == ticker],
                shap_summary=shap_summary,
                temporal_insights=t_insights,
                output_path=pdf_path,
            )
            pdf_paths.append(pdf_path)
            logger.info("  PDF generated: %s (GRS=%.1f, %s)",
                        pdf_path.name, report.greenwashing_risk_score, report.risk_band)
            tracker.log_artifact(pdf_path, "reports")

        tracker.log_metric("pdf_reports_generated", len(pdf_paths))

        # ── Step 9: Portfolio summary ────────────────────────────────────
        logger.info("\n── Step 9: Portfolio summary with explainability ──")
        portfolio_rows = []
        for co, report in zip(COMPANY_CLAIMS, reports):
            gen_for_co = [g for g in all_generated if g.company_ticker == co["ticker"]]
            portfolio_rows.append({
                "ticker":       co["ticker"],
                "name":         co["name"],
                "grs":          report.greenwashing_risk_score,
                "risk_band":    report.risk_band,
                "total_flags":  len(report.flags),
                "critical":     report.n_critical,
                "medium":       report.n_medium,
                "explanations": len(gen_for_co),
                "shap_claims":  len([e for e in all_expls
                                     if any(e.claim_text == c["text"] for c in co["claims"])]),
            })
        portfolio_df = pd.DataFrame(portfolio_rows).sort_values("grs", ascending=False)
        logger.info("\n%s", portfolio_df.to_string(index=False))

        port_path = out_dir / "sprint4_portfolio.parquet"
        portfolio_df.to_parquet(port_path, index=False)
        tracker.log_artifact(port_path, "portfolio")
        tracker.log_metric("avg_grs_after_fix",
                           round(portfolio_df["grs"].mean(), 2))

        total_time = time.time() - t_global
        tracker.log_metric("total_runtime_seconds", round(total_time, 2))

        logger.info("\n" + "=" * 64)
        logger.info("SPRINT 4 COMPLETE in %.1fs", total_time)
        logger.info("  Unit-type false positives fixed : %d → %d total flags",
                    9, total_flags_new)
        logger.info("  SHAP attributions computed     : %d claims", len(all_expls))
        logger.info("  Evidence bundles               : %d", len(all_bundles))
        logger.info("  Explanations generated         : %d (%d via API, %d template)",
                    len(all_generated), api_count, template_count)
        logger.info("  PDF reports generated          : %d", len(pdf_paths))
        logger.info("  Highest GRS                    : %s (%.1f)",
                    portfolio_df.iloc[0]["ticker"], portfolio_df.iloc[0]["grs"])
        logger.info("=" * 64)

        return {
            "reports":       reports,
            "all_expls":     all_expls,
            "all_bundles":   all_bundles,
            "all_generated": all_generated,
            "portfolio_df":  portfolio_df,
            "pdf_paths":     pdf_paths,
        }


if __name__ == "__main__":
    results = main()
