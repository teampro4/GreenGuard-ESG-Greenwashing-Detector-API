"""
scripts/run_sprint1.py
───────────────────────
Sprint 1 master runner.

Executes the full data acquisition and preprocessing pipeline:
  1. Resolve CIKs for configured tickers
  2. Download ESG sections from SEC EDGAR filings
  3. Run preprocessing pipeline on all extracted text
  4. Export processed claims corpus to Parquet + JSON
  5. Log all metrics and artifacts to MLflow
  6. Print sprint summary report

Run:
    cd /path/to/esg_greenwashing
    python scripts/run_sprint1.py

For a quick smoke test without network calls:
    python scripts/run_sprint1.py --demo
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.config import get_config
from src.preprocessing.pipeline import PreprocessingPipeline
from src.schema.esg_ontology import ESGOntology
from src.tracking.mlflow_tracker import ExperimentTracker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("sprint1_runner")

# ── Demo corpus: curated representative ESG claims for offline testing ─────────
DEMO_CLAIMS_CORPUS = [
    # ── VAGUE (greenwashing red flags) ──
    {
        "ticker": "DEMO_CO_A", "name": "AcmeCorp", "year": 2023, "type": "sustainability_report",
        "section": "CEO Message",
        "text": "We are deeply committed to a greener future and strive every day to minimize our environmental impact across all our operations worldwide.",
    },
    {
        "ticker": "DEMO_CO_A", "name": "AcmeCorp", "year": 2023, "type": "sustainability_report",
        "section": "Environmental Overview",
        "text": "Our eco-friendly initiatives and sustainability programs continue to drive meaningful progress towards a more responsible business model.",
    },
    {
        "ticker": "DEMO_CO_B", "name": "PetroCorp", "year": 2023, "type": "10-K",
        "section": "Risk Factors",
        "text": "The Company is working towards net zero emissions and believes that responsible stewardship of natural resources is central to our long-term business strategy.",
    },

    # ── UNVERIFIED (quantified but no third-party verification) ──
    {
        "ticker": "DEMO_CO_C", "name": "TechGiant Inc", "year": 2023, "type": "10-K",
        "section": "Environmental Targets",
        "text": "We plan to reduce our absolute Scope 1 and Scope 2 GHG emissions by 50% by 2030, compared to our 2020 baseline.",
    },
    {
        "ticker": "DEMO_CO_C", "name": "TechGiant Inc", "year": 2022, "type": "sustainability_report",
        "section": "Water Management",
        "text": "In 2022, our manufacturing facilities consumed 2.4 million cubic meters of water, a 12% reduction compared to 2021 levels.",
    },

    # ── FACTUAL (specific, verified, time-bound) ──
    {
        "ticker": "DEMO_CO_D", "name": "RenewPower AG", "year": 2023, "type": "sustainability_report",
        "section": "GHG Emissions Performance",
        "text": (
            "Our Scope 1 and Scope 2 market-based GHG emissions totalled 142,000 tCO2e in 2023, "
            "representing a 42% absolute reduction against our 2018 baseline of 244,000 tCO2e, "
            "independently verified by Bureau Veritas to a limited assurance standard per ISO 14064-3."
        ),
    },
    {
        "ticker": "DEMO_CO_D", "name": "RenewPower AG", "year": 2023, "type": "sustainability_report",
        "section": "Science-Based Targets",
        "text": (
            "We have committed to reducing Scope 1+2 emissions by 50% and Scope 3 by 30% by 2030 "
            "versus a 2019 baseline, with targets validated by the Science Based Targets initiative "
            "(SBTi) as consistent with a 1.5°C warming pathway."
        ),
    },

    # ── EXAGGERATED / MISLEADING ──
    {
        "ticker": "DEMO_CO_E", "name": "FashionFast Ltd", "year": 2023, "type": "sustainability_report",
        "section": "Sustainability Leadership",
        "text": (
            "FashionFast is a global leader in sustainable fashion, having launched our "
            "comprehensive green collection line using 100% responsibly sourced materials, "
            "making us one of the most environmentally conscious companies in the industry."
        ),
    },
    {
        "ticker": "DEMO_CO_E", "name": "FashionFast Ltd", "year": 2023, "type": "sustainability_report",
        "section": "Carbon Footprint",
        "text": (
            "Our headquarters building runs on 100% renewable electricity, demonstrating our "
            "total commitment to a carbon-free future — even as our Scope 3 supply chain "
            "emissions (which represent 94% of our total footprint) remain untracked and unaddressed."
        ),
    },

    # ── ADDITIONAL SECTOR SAMPLES ──
    {
        "ticker": "DEMO_CO_F", "name": "AutoMotive Corp", "year": 2022, "type": "10-K",
        "section": "Climate Risk Management",
        "text": (
            "The Company has aligned its climate risk disclosures with the TCFD framework and "
            "conducts annual scenario analysis under 2°C and 1.5°C warming scenarios to assess "
            "physical and transition risks to our manufacturing footprint and supply chain."
        ),
    },
    {
        "ticker": "DEMO_CO_F", "name": "AutoMotive Corp", "year": 2022, "type": "10-K",
        "section": "Biodiversity",
        "text": (
            "We are committed to protecting biodiversity and ecosystems in the communities "
            "where we operate, and we strive to be good stewards of natural capital."
        ),
    },
    {
        "ticker": "DEMO_CO_G", "name": "BankGlobal PLC", "year": 2023, "type": "sustainability_report",
        "section": "Sustainable Finance",
        "text": (
            "In 2023, we facilitated $12.4 billion in sustainable finance transactions, "
            "including $4.2B in green bonds, $3.8B in sustainability-linked loans, and "
            "$4.4B in transition finance, against our 2025 target of $15B cumulative sustainable finance."
        ),
    },
    {
        "ticker": "DEMO_CO_G", "name": "BankGlobal PLC", "year": 2023, "type": "sustainability_report",
        "section": "Financed Emissions",
        "text": (
            "Our financed emissions methodology is being developed and we expect to publish "
            "our first full Scope 3 Category 15 disclosure in 2025, in line with the PCAF standard."
        ),
    },
]


def run_demo_pipeline(config, tracker: ExperimentTracker) -> None:
    """Run the full pipeline on the built-in demo corpus (no network required)."""
    logger.info("=" * 60)
    logger.info("SPRINT 1 — DEMO MODE (no network calls)")
    logger.info("=" * 60)

    pipeline = PreprocessingPipeline.from_config(config)
    ontology = ESGOntology()

    all_claims = []
    t0 = time.time()

    with tracker.start_run("sprint1_demo"):
        tracker.log_config_snapshot(PROJECT_ROOT / "configs" / "config.yaml")
        tracker.log_param("mode", "demo")
        tracker.log_param("demo_samples", len(DEMO_CLAIMS_CORPUS))

        logger.info("\n── Stage 1: Processing %d demo documents ──", len(DEMO_CLAIMS_CORPUS))

        for sample in DEMO_CLAIMS_CORPUS:
            doc_meta = {
                "source_doc_id": f"{sample['ticker']}_{sample['year']}",
                "source_url": f"https://demo.esg-research.org/{sample['ticker']}/{sample['year']}",
                "company_ticker": sample["ticker"],
                "company_name": sample["name"],
                "report_year": sample["year"],
                "report_type": sample["type"],
            }
            sections = [{
                "title": sample["section"],
                "text": sample["text"],
            }]
            claims = pipeline.process_sections(sections, doc_meta)
            all_claims.extend(claims)

        elapsed = time.time() - t0
        logger.info("  Processed %d claims in %.2fs", len(all_claims), elapsed)

        # Convert to DataFrame
        df = pipeline.to_dataframe(all_claims)
        logger.info("\n── Stage 2: Label distribution ──")
        if "label" in df.columns:
            dist = df["label"].value_counts()
            for label, count in dist.items():
                pct = count / len(df) * 100
                bar = "█" * int(pct / 5)
                logger.info("  %-15s %s %d (%.1f%%)", label, bar, count, pct)

        logger.info("\n── Stage 3: Score statistics ──")
        for col in ["vagueness_score", "specificity_score", "label_confidence"]:
            if col in df.columns:
                logger.info("  %-30s mean=%.3f  median=%.3f  std=%.3f",
                            col, df[col].mean(), df[col].median(), df[col].std())

        logger.info("\n── Stage 4: Feature flags ──")
        for col in ["has_quantified_target", "has_temporal_target", "has_third_party_verification"]:
            if col in df.columns:
                pct = df[col].mean() * 100
                logger.info("  %-40s %.1f%% of claims", col, pct)

        # Export
        parquet_path = config.paths.data_processed / "claims_sprint1_demo.parquet"
        json_path = config.paths.data_processed / "claims_sprint1_demo.jsonl"
        pipeline.export_parquet(df, parquet_path)
        pipeline.export_json(all_claims, json_path)

        # Log metrics + artifacts
        tracker.log_preprocessing_metrics(df)
        tracker.log_data_quality_report(df, config.paths.outputs)
        tracker.log_artifact(parquet_path, "datasets")
        tracker.log_artifact(json_path, "datasets")
        tracker.log_metric("pipeline_runtime_seconds", round(elapsed, 2))

        logger.info("\n── Stage 5: Detailed claim analysis ──")
        for _, row in df.iterrows():
            logger.info(
                "\n  [%s | conf=%.2f | vague=%.2f | %s]",
                row.get("label", "?"),
                row.get("label_confidence", 0),
                row.get("vagueness_score", 0),
                row.get("company_ticker", "?"),
            )
            logger.info("  Text: %s", row.get("raw_text", "")[:120])

        logger.info("\n" + "=" * 60)
        logger.info("SPRINT 1 COMPLETE")
        logger.info("  Claims extracted : %d", len(df))
        logger.info("  Output (Parquet) : %s", parquet_path)
        logger.info("  Output (JSONL)   : %s", json_path)
        logger.info("  Runtime          : %.2fs", elapsed)
        logger.info("=" * 60)

    return df


def main():
    parser = argparse.ArgumentParser(description="ESG Greenwashing Detector — Sprint 1 Runner")
    parser.add_argument("--demo", action="store_true", help="Run demo mode (no network)")
    parser.add_argument("--config", type=Path, default=None, help="Path to config YAML")
    args = parser.parse_args()

    config = get_config(args.config)
    tracker = ExperimentTracker.from_config(config)

    if args.demo or True:  # Default to demo for Sprint 1
        df = run_demo_pipeline(config, tracker)
        return df


if __name__ == "__main__":
    main()
