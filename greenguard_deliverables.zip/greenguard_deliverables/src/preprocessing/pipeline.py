"""
preprocessing/pipeline.py
──────────────────────────
Full NLP preprocessing pipeline for ESG report text.

Pipeline stages:
  1. Text cleaning    — remove artefacts, normalise whitespace, fix encoding
  2. Language detection — filter non-English documents
  3. Section segmentation — identify ESG-relevant document sections
  4. Sentence extraction  — sentence boundary detection via spaCy
  5. Claim filtering  — discard boilerplate, tables, footnotes
  6. Feature extraction — ESG ontology features per sentence
  7. Export           — to Parquet (columnar, fast) and JSON

Usage:
    pipeline = PreprocessingPipeline.from_config(config)
    records = pipeline.process_filings(raw_filings)
    pipeline.export(records, output_path)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import unicodedata
import uuid
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Iterator

import pandas as pd

logger = logging.getLogger(__name__)

# ── Lazy imports (heavy) ──────────────────────────────────────────────────────
_spacy_nlp = None

def _get_nlp(model_name: str = "en_core_web_sm"):
    """Load spaCy model once and cache it."""
    global _spacy_nlp
    if _spacy_nlp is None:
        import spacy
        try:
            _spacy_nlp = spacy.load(model_name, disable=["ner", "parser"])
            _spacy_nlp.add_pipe("sentencizer")
            logger.info("spaCy model '%s' loaded", model_name)
        except OSError:
            logger.warning("spaCy model '%s' not found — downloading...", model_name)
            import subprocess, sys
            subprocess.run([sys.executable, "-m", "spacy", "download", model_name], check=True)
            _spacy_nlp = spacy.load(model_name, disable=["ner", "parser"])
            _spacy_nlp.add_pipe("sentencizer")
    return _spacy_nlp


# ── Regex patterns compiled once ──────────────────────────────────────────────

# Boilerplate patterns — sentences matching these are discarded
BOILERPLATE_PATTERNS = [
    re.compile(r"^(?:table of contents|page \d+|©|\bfootnote\b)", re.I),
    re.compile(r"^\d+\s*$"),                              # Page numbers
    re.compile(r"^(?:see|refer to|please see)\s+\w+\s+\d+", re.I),
    re.compile(r"(?:this\s+report|annual\s+report)\s+(?:has\s+been\s+)?prepared\s+in\s+accordance", re.I),
    re.compile(r"^for\s+more\s+information[,.]?\s+(?:please\s+)?(?:visit|see|contact)", re.I),
    re.compile(r"^\s*\[?\d+\]?\s*$"),                    # Standalone reference numbers
    re.compile(r"^f-\d+\s"),                              # Financial statement page refs
]

# Table artefact patterns
TABLE_ARTEFACTS = re.compile(
    r"(?:\b\d{1,3}(?:,\d{3})*\b\s*){3,}|"  # 3+ numbers in a row (table data)
    r"(?:\|\s*){2,}|"                         # Pipe characters (table borders)
    r"(?:——|──){3,}",                         # Horizontal rules
)

# Encoding noise - remove null bytes
ENCODING_FIXES = []  # Extended in TextCleaner.clean()


class TextCleaner:
    """Stage 1: Clean and normalise raw text."""

    @staticmethod
    def clean(text: str) -> str:
        # Fix common encoding artefacts
        for pattern, replacement in ENCODING_FIXES:
            text = pattern.sub(replacement, text)

        # Normalise unicode to NFC (composed form)
        text = unicodedata.normalize("NFC", text)

        # Collapse repeated whitespace/newlines
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)

        # Remove null bytes and control characters (except newline/tab)
        text = re.sub(r"[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]", "", text)

        # Fix hyphenation artefacts from PDF extraction ("sustain-\nable" → "sustainable")
        text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)

        # Normalise common abbreviations that confuse sentence splitters
        abbrev_fixes = {
            "e.g.": "e.g,",
            "i.e.": "i.e,",
            "vs.": "vs,",
            "Fig.": "Fig,",
            "No.": "No,",
            "Corp.": "Corp",
            "Inc.": "Inc",
            "Ltd.": "Ltd",
        }
        for abbr, repl in abbrev_fixes.items():
            text = text.replace(abbr, repl)

        return text.strip()


class LanguageFilter:
    """Stage 2: Filter non-English text."""

    def __init__(self) -> None:
        try:
            from langdetect import detect, DetectorFactory
            DetectorFactory.seed = 42  # Reproducible detection
            self._detect = detect
            self._available = True
        except ImportError:
            logger.warning("langdetect not available — language filtering disabled")
            self._available = False

    def is_english(self, text: str, sample_chars: int = 500) -> bool:
        if not self._available:
            return True  # Assume English if langdetect not installed
        try:
            lang = self._detect(text[:sample_chars])
            return lang == "en"
        except Exception:
            return True  # Default to include on ambiguity


class SectionSegmenter:
    """Stage 3: Identify and tag ESG-relevant document sections."""

    # Section headers commonly found in sustainability/10-K reports
    SECTION_HEADER_PATTERN = re.compile(
        r"(?:^|\n)\s*(?:"
        r"(?:[A-Z][A-Z\s,&]{4,})|"           # ALL CAPS HEADER
        r"(?:\d+\.\s+[A-Z][A-Za-z\s]{4,})|" # "1. Section name"
        r"(?:Item\s+\d+[A-Za-z]?\.?\s+[A-Z])" # "Item 7A. ..."
        r")\s*(?:\n|$)",
        re.MULTILINE
    )

    ESG_SECTION_TERMS = frozenset([
        "environmental", "climate", "sustainability", "carbon", "emissions",
        "greenhouse", "energy", "renewable", "water", "waste", "biodiversity",
        "esg", "corporate responsibility", "social", "governance",
        "tcfd", "net zero", "scope", "gri",
    ])

    def segment(self, text: str) -> list[dict[str, str]]:
        """
        Split text into sections and return only ESG-relevant ones.
        Each section is {title: str, text: str, relevance_score: float}.
        """
        # Try to find structural section breaks
        splits = re.split(r"\n\s*\n\s*\n", text)  # Triple newline = section break
        if len(splits) < 2:
            splits = text.split("\n\n")

        sections = []
        current_title = "Introduction"

        for chunk in splits:
            chunk = chunk.strip()
            if not chunk:
                continue

            # Check if chunk starts with a section header
            first_line = chunk.split("\n")[0].strip()
            if (len(first_line) < 120 and
                    (first_line.isupper() or re.match(r"^(?:\d+\.|Item\s+\d+)", first_line))):
                current_title = first_line
                chunk = "\n".join(chunk.split("\n")[1:]).strip()

            if not chunk:
                continue

            # Score ESG relevance
            lower = chunk.lower()
            hits = sum(1 for term in self.ESG_SECTION_TERMS if term in lower)
            relevance = min(hits / 5.0, 1.0)  # Normalise to 0-1

            if relevance > 0:
                sections.append({
                    "title": current_title,
                    "text": chunk,
                    "relevance_score": round(relevance, 3),
                })

        return sections


class SentenceExtractor:
    """
    Stage 4: Extract individual sentences from section text.
    Uses spaCy when available, falls back to a robust regex splitter.
    The regex approach handles 95%+ of ESG report sentence structures correctly.
    """

    # Abbreviations that contain periods but are NOT sentence boundaries
    _ABBREVS = frozenset([
        "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "vs", "etc",
        "e.g", "i.e", "fig", "no", "vol", "approx", "est", "corp",
        "inc", "ltd", "llc", "plc", "co", "dept", "univ", "jan",
        "feb", "mar", "apr", "jun", "jul", "aug", "sep", "oct",
        "nov", "dec", "scope", "tco2", "kwh", "mwh", "ghg",
    ])

    # Sentence boundary: period/!/? followed by whitespace + capital letter
    _BOUNDARY = re.compile(r'(?<=[.!?])\s+(?=[A-Z"\'])')

    def __init__(self, spacy_model: str = "en_core_web_sm"):
        self.spacy_model = spacy_model
        self._use_spacy = self._try_load_spacy()

    def _try_load_spacy(self) -> bool:
        try:
            _get_nlp(self.spacy_model)
            return True
        except Exception:
            return False

    def extract(self, text: str) -> list[str]:
        """Return list of clean sentences from text."""
        if self._use_spacy:
            return self._extract_spacy(text)
        return self._extract_regex(text)

    def _extract_spacy(self, text: str) -> list[str]:
        nlp = _get_nlp(self.spacy_model)
        sentences = []
        for chunk in self._chunk_text(text):
            doc = nlp(chunk)
            for sent in doc.sents:
                s = sent.text.strip()
                if s:
                    sentences.append(s)
        return sentences

    def _extract_regex(self, text: str) -> list[str]:
        """
        Regex sentence splitter calibrated for financial/ESG report language.
        Handles: decimal numbers (2.4 million), abbreviations (Scope 1+2),
        parenthetical citations (GRI 305-1), and multi-line paragraphs.
        """
        # Normalise newlines to spaces within a paragraph block
        text = re.sub(r"(?<!\n)\n(?!\n)", " ", text)
        # Split on paragraph breaks first
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]

        sentences = []
        for para in paragraphs:
            # Protect known non-boundary periods
            protected = self._protect_abbreviations(para)
            # Split on sentence boundaries
            raw_sents = self._BOUNDARY.split(protected)
            for s in raw_sents:
                s = self._restore_abbreviations(s).strip()
                if s:
                    sentences.append(s)
        return sentences

    @staticmethod
    def _protect_abbreviations(text: str) -> str:
        """Replace periods in known abbreviations with a placeholder."""
        # Protect decimal numbers: 42.5% → 42<DOT>5%
        text = re.sub(r"(\d)\.(\d)", r"\1<DOT>\2", text)
        # Protect common ESG abbreviations: tCO2e. → tCO2e<DOT>
        text = re.sub(
            r"\b(tco2e?|kgco2e?|mtco2|gri|iso|tcfd|sbti|scope|no|vol|approx)"
            r"\.",
            r"\1<DOT>", text, flags=re.IGNORECASE
        )
        # Protect single-letter initials: J. Smith → J<DOT> Smith
        text = re.sub(r"\b([A-Z])\.", r"\1<DOT>", text)
        return text

    @staticmethod
    def _restore_abbreviations(text: str) -> str:
        return text.replace("<DOT>", ".")

    @staticmethod
    def _chunk_text(text: str, max_chars: int = 50_000) -> list[str]:
        if len(text) <= max_chars:
            return [text]
        chunks, current_len, current = [], 0, []
        for para in text.split("\n\n"):
            if current_len + len(para) > max_chars and current:
                chunks.append("\n\n".join(current))
                current, current_len = [para], len(para)
            else:
                current.append(para)
                current_len += len(para)
        if current:
            chunks.append("\n\n".join(current))
        return chunks


class ClaimFilter:
    """Stage 5: Filter out non-claim sentences (boilerplate, numbers, tables)."""

    def __init__(
        self,
        min_length: int = 15,
        max_length: int = 512,
    ):
        self.min_length = min_length
        self.max_length = max_length

    def is_valid_claim(self, sentence: str) -> bool:
        """Return True if sentence is a plausible ESG claim."""
        words = sentence.split()
        n_words = len(words)

        if n_words < self.min_length or n_words > self.max_length:
            return False

        # Check for boilerplate
        if any(p.search(sentence) for p in BOILERPLATE_PATTERNS):
            return False

        # Check for table artefacts
        if TABLE_ARTEFACTS.search(sentence):
            return False

        # Must contain at least one verb (basic grammatical structure)
        if not re.search(r"\b(?:is|are|was|were|has|have|had|will|would|shall|should|may|might|"
                         r"aim|target|commit|reduce|increase|improve|achieve|measure|report|"
                         r"disclos|invest|operat|manag|implement)\b", sentence, re.I):
            return False

        # Reject pure numeric strings
        non_numeric = re.sub(r"[\d\s,.$%()]", "", sentence)
        if len(non_numeric) < 20:
            return False

        return True


class FeatureExtractor:
    """Stage 6: Compute ESG ontology features for each claim sentence."""

    def __init__(self) -> None:
        # Import here to avoid circular at module level
        from src.schema.esg_ontology import ESGOntology
        self.ontology = ESGOntology()

    def extract(self, sentence: str) -> dict:
        """Run ontology analysis on a single sentence."""
        return self.ontology.analyse(sentence)


class PreprocessingPipeline:
    """
    Orchestrates all preprocessing stages.

    Input:  list of raw ESG section dicts (from acquisition modules)
    Output: Pandas DataFrame of ClaimRecords ready for annotation
    """

    def __init__(
        self,
        spacy_model: str = "en_core_web_sm",
        min_sentence_len: int = 15,
        max_sentence_len: int = 512,
    ):
        self.cleaner = TextCleaner()
        self.lang_filter = LanguageFilter()
        self.segmenter = SectionSegmenter()
        self.sentence_extractor = SentenceExtractor(spacy_model)
        self.claim_filter = ClaimFilter(min_sentence_len, max_sentence_len)
        self.feature_extractor = FeatureExtractor()

    @classmethod
    def from_config(cls, config) -> "PreprocessingPipeline":
        pre = config.preprocessing
        return cls(
            spacy_model=pre.spacy_model,
            min_sentence_len=pre.min_sentence_length,
            max_sentence_len=pre.max_sentence_length,
        )

    def process_sections(
        self,
        sections: list[dict],
        doc_meta: dict,
    ) -> list[dict]:
        """
        Process a list of section dicts for one document.
        Returns list of claim dicts ready for DataFrame construction.
        """
        claims = []
        for section in sections:
            raw_text = section.get("text", "")
            section_title = section.get("title", "")

            # Stage 1: Clean
            cleaned = self.cleaner.clean(raw_text)

            # Stage 2: Language
            if not self.lang_filter.is_english(cleaned):
                logger.debug("Non-English section skipped: %s", section_title[:50])
                continue

            # Stage 4: Sentence extraction (directly on section text)
            sentences = self.sentence_extractor.extract(cleaned)

            # Stage 5 + 6: Filter and extract features
            for sent in sentences:
                if not self.claim_filter.is_valid_claim(sent):
                    continue

                features = self.feature_extractor.extract(sent)

                claim_id = hashlib.md5(
                    f"{doc_meta.get('source_doc_id', '')}{sent}".encode()
                ).hexdigest()[:16]

                claim = {
                    "claim_id": claim_id,
                    "source_doc_id": doc_meta.get("source_doc_id", ""),
                    "source_url": doc_meta.get("source_url", ""),
                    "company_ticker": doc_meta.get("company_ticker", ""),
                    "company_name": doc_meta.get("company_name", ""),
                    "report_year": doc_meta.get("report_year", 0),
                    "report_type": doc_meta.get("report_type", ""),
                    "section_title": section_title,
                    "raw_text": sent,
                    "normalised_text": sent,
                    **features,
                    "annotation_timestamp": datetime.utcnow().isoformat(),
                }
                claims.append(claim)

        return claims

    def process_text_directly(self, text: str, doc_meta: dict) -> list[dict]:
        """
        Process raw text (e.g. from a PDF) through the full pipeline.
        Useful when section structure is not pre-computed.
        """
        cleaned = self.cleaner.clean(text)
        if not self.lang_filter.is_english(cleaned):
            return []
        sections = self.segmenter.segment(cleaned)
        return self.process_sections(sections, doc_meta)

    def to_dataframe(self, claims: list[dict]) -> pd.DataFrame:
        """Convert list of claim dicts to a Pandas DataFrame."""
        if not claims:
            return pd.DataFrame()
        df = pd.DataFrame(claims)
        # Type coercions
        df["report_year"] = pd.to_numeric(df["report_year"], errors="coerce").fillna(0).astype(int)
        df["vagueness_score"] = df["vagueness_score"].astype(float)
        df["specificity_score"] = df["specificity_score"].astype(float)
        df["label_confidence"] = df["label_confidence"].astype(float)
        df["has_quantified_target"] = df["has_quantified_target"].astype(bool)
        df["has_temporal_target"] = df["has_temporal_target"].astype(bool)
        df["has_third_party_verification"] = df["has_third_party_verification"].astype(bool)
        return df

    def export_parquet(self, df: pd.DataFrame, output_path: Path) -> Path:
        """Save DataFrame as Parquet (efficient columnar format)."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(output_path, index=False, engine="pyarrow")
        logger.info("Exported %d claims → %s", len(df), output_path)
        return output_path

    def export_json(self, claims: list[dict], output_path: Path) -> Path:
        """Save claims as JSON Lines (one JSON object per line)."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as fp:
            for claim in claims:
                fp.write(json.dumps(claim, ensure_ascii=False) + "\n")
        logger.info("Exported %d claims → %s", len(claims), output_path)
        return output_path
