"""
api/app.py
───────────
GreenGuard — Production FastAPI REST API

Endpoints:
  POST /analyse          — Analyse one ESG claim (text or URL)
  POST /analyse/batch    — Analyse up to 50 claims in one request
  POST /company          — Full company analysis with GRS scoring
  GET  /health           — Health check
  GET  /model/info       — Model metadata and version

Run locally:
  cd esg_greenwashing
  uvicorn src.api.app:app --reload --port 8000

Then open: http://localhost:8000/docs
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

PROJECT_ROOT = Path(__file__).parent.parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from src.config import get_config
from src.classification.greenwashing_classifier import GreenwashingClassifier
from src.schema.esg_ontology import ESGOntology
from src.connectors.external_data import ExternalDataRegistry
from src.inconsistency.detector import InconsistencyDetector
from src.explainability.shap_explainer import LRSHAPExplainer
from src.annotation.corpus_builder import build_corpus


# ── App setup ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="GreenGuard — ESG Greenwashing Detector API",
    description=(
        "Automated ESG report authenticity verification. "
        "Classifies claims as FACTUAL, VAGUE, EXAGGERATED, UNVERIFIED, or MISLEADING "
        "with calibrated confidence scores, SHAP attributions, and cross-source validation."
    ),
    version="0.6.0",
    contact={"name": "ESG Research Team"},
    license_info={"name": "Apache 2.0"},
)

# ── Global model cache (loaded once on startup) ───────────────────────────────
_clf:      Optional[GreenwashingClassifier] = None
_explainer:Optional[LRSHAPExplainer]        = None
_ontology: Optional[ESGOntology]            = None
_registry: Optional[ExternalDataRegistry]   = None
_detector: Optional[InconsistencyDetector]  = None
_config    = None


def _get_clf() -> GreenwashingClassifier:
    global _clf
    if _clf is None:
        cfg = _get_config()
        # Prefer Sprint 6 model; fall back to Sprint 2
        s6 = cfg.paths.models / "greenwashing_clf_sprint6.pkl"
        s2 = cfg.paths.models / "greenwashing_clf_sprint2.pkl"
        path = s6 if s6.exists() else s2
        _clf = GreenwashingClassifier.load(path)
    return _clf


def _get_explainer() -> LRSHAPExplainer:
    global _explainer
    if _explainer is None:
        cfg = get_config()
        s6 = cfg.paths.models / "greenwashing_clf_sprint6.pkl"
        s2 = cfg.paths.models / "greenwashing_clf_sprint2.pkl"
        path = s6 if s6.exists() else s2
        _explainer = LRSHAPExplainer(path)
        train_texts = build_corpus(seed=42)["text"].tolist()
        _explainer.fit_baseline(train_texts)
    return _explainer


def _get_ontology() -> ESGOntology:
    global _ontology
    if _ontology is None:
        _ontology = ESGOntology()
    return _ontology


def _get_registry() -> ExternalDataRegistry:
    global _registry
    if _registry is None:
        _registry = ExternalDataRegistry(use_mock=True)
    return _registry


def _get_detector() -> InconsistencyDetector:
    global _detector
    if _detector is None:
        _detector = InconsistencyDetector(_get_registry())
    return _detector


def _get_config():
    global _config
    if _config is None:
        _config = get_config()
    return _config


# ── Request / Response models ─────────────────────────────────────────────────

class ClaimRequest(BaseModel):
    text: str = Field(
        ...,
        description="ESG claim text to analyse",
        min_length=10,
        max_length=2000,
        examples=["We are deeply committed to a greener future and strive to minimise our environmental impact."]
    )
    company_ticker: Optional[str] = Field(
        None,
        description="Company stock ticker (e.g. AAPL) for cross-source validation",
        examples=["AAPL"]
    )
    report_year: int = Field(
        2023,
        description="Year of the source ESG report",
        ge=2015, le=2030
    )
    include_shap: bool = Field(
        False,
        description="Include SHAP feature attributions in response (slower)"
    )

    @field_validator("text")
    @classmethod
    def strip_text(cls, v: str) -> str:
        return v.strip()


class BatchClaimRequest(BaseModel):
    claims: list[ClaimRequest] = Field(
        ...,
        description="List of ESG claims to analyse (max 50)",
        min_length=1,
        max_length=50
    )


class CompanyRequest(BaseModel):
    ticker: str = Field(..., description="Company stock ticker", examples=["NKE"])
    name: str   = Field(..., description="Company name", examples=["Nike Inc."])
    year: int   = Field(2023, description="Report year", ge=2015, le=2030)
    claims: list[str] = Field(..., description="List of ESG claim texts from the company report",
                              min_length=1, max_length=30)


class OntologyFeatures(BaseModel):
    vagueness_score:               float
    specificity_score:             float
    has_quantified_target:         bool
    has_temporal_target:           bool
    has_third_party_verification:  bool
    vagueness_signal:              str
    pillar:                        str
    sub_category:                  str


class SHAPAttribution(BaseModel):
    feature:   str
    shap_value:float
    direction: str
    type:      str


class ClaimResponse(BaseModel):
    text:            str
    label:           str
    confidence:      float
    probabilities:   dict[str, float]
    ontology:        OntologyFeatures
    shap_top:        Optional[list[SHAPAttribution]] = None
    risk_drivers:    Optional[list[str]]             = None
    inference_ms:    int


class FlagSummary(BaseModel):
    flag_id:            str
    inconsistency_type: str
    severity:           str
    explanation:        str
    evidence_url:       str


class CompanyResponse(BaseModel):
    ticker:                    str
    name:                      str
    report_year:               int
    greenwashing_risk_score:   float
    risk_band:                 str
    total_flags:               int
    critical_flags:            int
    medium_flags:              int
    flags:                     list[FlagSummary]
    claim_results:             list[ClaimResponse]
    analysis_ms:               int


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"])
async def health():
    """Health check — returns API version and model status."""
    try:
        clf = _get_clf()
        return {
            "status":  "healthy",
            "version": "0.6.0",
            "model":   "greenwashing_clf_sprint6",
            "classes": clf.training_metrics.get("classes", []),
            "uptime":  "ok",
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Model not loaded: {e}")


@app.get("/model/info", tags=["System"])
async def model_info():
    """Return model metadata, training statistics, and feature configuration."""
    clf = _get_clf()
    return {
        "model_version":  "0.6.0",
        "sprint":         6,
        "classifier":     "Logistic Regression (L2, balanced class weights, Platt calibration)",
        "n_features":     clf.training_metrics.get("n_features"),
        "training_size":  clf.training_metrics.get("n_train"),
        "classes":        clf.training_metrics.get("classes"),
        "feature_groups": [
            "TF-IDF (3000 features, bigrams, sublinear_tf)",
            "ESG ontology (12: vagueness, specificity, binary flags, pillar)",
            "Keyword groups (8: commitment, verified_standards, quantified, superlative, ...)",
            "Structural (13: word_count, has_year, parenthetical_count, ...)",
        ],
        "eval_metrics": {
            "f1_macro":   clf.training_metrics.get("eval", {}).get("f1_macro"),
            "f1_weighted":clf.training_metrics.get("eval", {}).get("f1_weighted"),
            "cohen_kappa":clf.training_metrics.get("eval", {}).get("cohen_kappa"),
        },
        "hf_model_info": {
            "explanation_provider": "HuggingFace Inference API",
            "primary_model":        "mistralai/Mistral-7B-Instruct-v0.3",
            "fallback_models":      ["HuggingFaceH4/zephyr-7b-beta", "microsoft/Phi-3-mini-4k-instruct"],
        }
    }


@app.post("/analyse", response_model=ClaimResponse, tags=["Analysis"])
async def analyse_claim(req: ClaimRequest):
    """
    Analyse a single ESG claim.

    Returns:
      - Greenwashing label (FACTUAL/VAGUE/EXAGGERATED/UNVERIFIED/MISLEADING)
      - Calibrated confidence and class probabilities
      - ESG ontology features (vagueness score, flags)
      - Optional SHAP attributions (set include_shap=true)
    """
    t0 = time.time()
    clf      = _get_clf()
    ontology = _get_ontology()

    # Classification
    pred    = clf.predict_single(req.text)
    ont_res = ontology.analyse(req.text)

    # Optional SHAP
    shap_top   = None
    risk_drivers = None
    if req.include_shap:
        explainer = _get_explainer()
        expl = explainer.explain(req.text)
        shap_top = [
            SHAPAttribution(
                feature   = a.feature_name.replace("token:", ""),
                shap_value= round(a.shap_value, 5),
                direction = a.direction,
                type      = a.feature_type,
            )
            for a in expl.top_attributions[:8]
        ]
        risk_drivers = expl.risk_drivers[:3]

    ms = int((time.time() - t0) * 1000)
    return ClaimResponse(
        text           = req.text,
        label          = pred["label"],
        confidence     = pred["confidence"],
        probabilities  = pred["probabilities"],
        ontology       = OntologyFeatures(
            vagueness_score              = ont_res["vagueness_score"],
            specificity_score            = ont_res["specificity_score"],
            has_quantified_target        = ont_res["has_quantified_target"],
            has_temporal_target          = ont_res["has_temporal_target"],
            has_third_party_verification = ont_res["has_third_party_verification"],
            vagueness_signal             = ont_res["vagueness_signal"],
            pillar                       = ont_res["pillar"],
            sub_category                 = ont_res["sub_category"],
        ),
        shap_top     = shap_top,
        risk_drivers = risk_drivers,
        inference_ms = ms,
    )


@app.post("/analyse/batch", tags=["Analysis"])
async def analyse_batch(req: BatchClaimRequest):
    """
    Analyse a batch of ESG claims (max 50).
    Returns a list of ClaimResponse objects in the same order as the input.
    """
    t0  = time.time()
    clf = _get_clf()
    ont = _get_ontology()

    texts = [c.text for c in req.claims]
    preds = clf.predict_batch(texts)

    results = []
    for claim, pred in zip(req.claims, preds):
        ont_res = ont.analyse(claim.text)
        results.append({
            "text":           claim.text,
            "label":          pred["label"],
            "confidence":     pred["confidence"],
            "probabilities":  pred["probabilities"],
            "ontology": {
                "vagueness_score":              ont_res["vagueness_score"],
                "specificity_score":            ont_res["specificity_score"],
                "has_quantified_target":        ont_res["has_quantified_target"],
                "has_temporal_target":          ont_res["has_temporal_target"],
                "has_third_party_verification": ont_res["has_third_party_verification"],
                "vagueness_signal":             ont_res["vagueness_signal"],
                "pillar":                       ont_res["pillar"],
                "sub_category":                 ont_res["sub_category"],
            },
        })

    total_ms = int((time.time() - t0) * 1000)
    return {
        "n_claims":         len(results),
        "total_ms":         total_ms,
        "avg_ms_per_claim": round(total_ms / len(results), 1),
        "results":          results,
    }


@app.post("/company", response_model=CompanyResponse, tags=["Analysis"])
async def analyse_company(req: CompanyRequest):
    """
    Full company ESG report analysis.

    For each claim:
      - Greenwashing classification
      - Ontology feature extraction

    Plus company-level:
      - Cross-source inconsistency detection (SEC, CDP, Sustainalytics)
      - Greenwashing Risk Score (GRS 0-100)
      - Flag table with severity and evidence
    """
    t0       = time.time()
    clf      = _get_clf()
    ont      = _get_ontology()
    detector = _get_detector()

    # Classify each claim
    preds = clf.predict_batch(req.claims)
    claim_results = []
    for text, pred in zip(req.claims, preds):
        ont_res = ont.analyse(text)
        claim_results.append(ClaimResponse(
            text          = text,
            label         = pred["label"],
            confidence    = pred["confidence"],
            probabilities = pred["probabilities"],
            ontology      = OntologyFeatures(
                vagueness_score              = ont_res["vagueness_score"],
                specificity_score            = ont_res["specificity_score"],
                has_quantified_target        = ont_res["has_quantified_target"],
                has_temporal_target          = ont_res["has_temporal_target"],
                has_third_party_verification = ont_res["has_third_party_verification"],
                vagueness_signal             = ont_res["vagueness_signal"],
                pillar                       = ont_res["pillar"],
                sub_category                 = ont_res["sub_category"],
            ),
            inference_ms  = 0,
        ))

    # Inconsistency detection
    claim_dicts = [{"text": t, "company_ticker": req.ticker, "report_year": req.year}
                   for t in req.claims]
    report = detector.analyse_company(req.ticker, req.name, claim_dicts, req.year)

    flags = [
        FlagSummary(
            flag_id            = f.flag_id,
            inconsistency_type = f.inconsistency_type,
            severity           = f.severity.value,
            explanation        = f.explanation[:300],
            evidence_url       = f.evidence_url,
        )
        for f in report.flags
    ]

    return CompanyResponse(
        ticker                  = req.ticker,
        name                    = req.name,
        report_year             = req.year,
        greenwashing_risk_score = report.greenwashing_risk_score,
        risk_band               = report.risk_band,
        total_flags             = len(report.flags),
        critical_flags          = report.n_critical,
        medium_flags            = report.n_medium,
        flags                   = flags,
        claim_results           = claim_results,
        analysis_ms             = int((time.time() - t0) * 1000),
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
