"""
explainability/evidence_citations.py
──────────────────────────────────────
Evidence citation engine.

For each InconsistencyFlag or PredictionExplanation, produces:
  • EvidenceBundle: source claim sentence + external data point + regulatory reference
  • Citation chain: ordered sequence of evidence pieces with confidence
  • Investor-readable summary of why this specific claim is flagged

The evidence traceability is critical for regulatory use (ESMA, SEC, FCA):
every flag must link back to a verifiable primary source.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from src.inconsistency.detector import InconsistencyFlag, InconsistencyReport
from src.explainability.shap_explainer import PredictionExplanation


# ── Regulatory reference library ─────────────────────────────────────────────
# Maps inconsistency types to the most relevant regulatory guidance
REGULATORY_REFERENCES: dict[str, list[dict]] = {
    "NUMERIC_MISMATCH": [
        {
            "regulator": "ESMA",
            "document":  "Guidelines on funds' names using ESG or sustainability-related terms (2024)",
            "article":   "Section V — Substantiation requirements",
            "relevance": "Requires quantitative claims to be substantiated by verifiable data",
            "url":       "https://www.esma.europa.eu/sites/default/files/2024-05/ESMA34-472-2841_Guidelines_on_fund_names.pdf",
        },
        {
            "regulator": "SEC",
            "document":  "Staff Bulletin on Environmental, Social and Governance Disclosures (2022)",
            "article":   "Section II.B — Accuracy of disclosed metrics",
            "relevance": "Material misrepresentation of ESG metrics may constitute securities fraud",
            "url":       "https://www.sec.gov/corp_fin/staff-bulletin-environmental-social-governance-disclosures",
        },
    ],
    "SCOPE_OMISSION": [
        {
            "regulator": "GRI",
            "document":  "GRI 305: Emissions (2016)",
            "article":   "Disclosure 305-3: Other indirect (Scope 3) GHG emissions",
            "relevance": "Omitting Scope 3 when it is the dominant emission source violates completeness principle",
            "url":       "https://www.globalreporting.org/standards/media/1012/gri-305-emissions-2016.pdf",
        },
        {
            "regulator": "TCFD",
            "document":  "TCFD Recommendations and Guidance (2021)",
            "article":   "Metrics and Targets — Scope 3 disclosure",
            "relevance": "TCFD requires Scope 3 disclosure where material",
            "url":       "https://assets.fsb.org/wp-content/uploads/P291021-1.pdf",
        },
    ],
    "TEMPORAL_ANOMALY": [
        {
            "regulator": "GHG Protocol",
            "document":  "Corporate Standard — Chapter 5: Recalculations",
            "article":   "Section 5.2 — Recalculation policy",
            "relevance": "Sudden large changes require disclosure of recalculation methodology",
            "url":       "https://ghgprotocol.org/corporate-value-chain-scope-3-standard",
        },
    ],
    "VERIFICATION_GAP": [
        {
            "regulator": "ISAE",
            "document":  "ISAE 3000 (Revised) — Assurance Engagements Other than Audits",
            "article":   "Para. 11 — Limited vs reasonable assurance",
            "relevance": "Unverified quantitative ESG claims lack the assurance basis required by institutional investors",
            "url":       "https://www.iaasb.org/standards/isae-3000",
        },
    ],
    "CONTROVERSY_CONTEXT": [
        {
            "regulator": "FCA",
            "document":  "Anti-Greenwashing Rule (PS23/16, effective June 2024)",
            "article":   "PRIN 12 — Sustainability claims must be fair, clear and not misleading",
            "relevance": "Positive ESG claims from companies with documented controversies may mislead",
            "url":       "https://www.fca.org.uk/publications/policy-statements/ps23-16-sustainability-disclosure-requirements-investment-labels",
        },
    ],
}


@dataclass
class EvidencePiece:
    """One piece of evidence supporting a flag or classification."""
    evidence_type:  str        # "claim_text" | "external_data" | "regulatory" | "shap_feature"
    source_label:   str        # human-readable source identifier
    content:        str        # the actual evidence text
    confidence:     float      # 0.0–1.0
    url:            str = ""
    metadata:       dict = field(default_factory=dict)


@dataclass
class EvidenceBundle:
    """Complete evidence chain for one inconsistency flag or classification."""
    flag_id:          str
    company_ticker:   str
    inconsistency_type: str
    severity:         str
    claim_text:       str
    evidence_pieces:  list[EvidencePiece]
    regulatory_refs:  list[dict]
    investor_summary: str          # 2-3 sentence investor-readable explanation
    recommended_action: str

    def to_dict(self) -> dict:
        return {
            "flag_id":             self.flag_id,
            "company_ticker":      self.company_ticker,
            "inconsistency_type":  self.inconsistency_type,
            "severity":            self.severity,
            "claim_text":          self.claim_text[:300],
            "evidence_count":      len(self.evidence_pieces),
            "evidence_pieces":     [
                {
                    "type":       e.evidence_type,
                    "source":     e.source_label,
                    "content":    e.content[:300],
                    "confidence": round(e.confidence, 3),
                    "url":        e.url,
                }
                for e in self.evidence_pieces
            ],
            "regulatory_refs":     self.regulatory_refs[:2],
            "investor_summary":    self.investor_summary,
            "recommended_action":  self.recommended_action,
        }


class EvidenceCitationEngine:
    """
    Builds evidence bundles for all flags in an InconsistencyReport.
    Also integrates SHAP explanations for Sprint 2 classifier decisions.
    """

    def build_bundles(
        self,
        report: InconsistencyReport,
        shap_explanations: Optional[dict[str, PredictionExplanation]] = None,
    ) -> list[EvidenceBundle]:
        """Build evidence bundle for each flag in the report."""
        bundles = []
        for flag in report.flags:
            bundle = self._build_flag_bundle(flag, shap_explanations)
            bundles.append(bundle)
        return bundles

    def _build_flag_bundle(
        self,
        flag: InconsistencyFlag,
        shap_explanations: Optional[dict] = None,
    ) -> EvidenceBundle:
        pieces: list[EvidencePiece] = []

        # Evidence piece 1: the original claim
        pieces.append(EvidencePiece(
            evidence_type="claim_text",
            source_label=f"{flag.company_ticker} ESG Report {flag.reporting_year}",
            content=flag.claim_text,
            confidence=1.0,
            url=flag.evidence_url,
        ))

        # Evidence piece 2: external data point
        if flag.external_value is not None:
            pieces.append(EvidencePiece(
                evidence_type="external_data",
                source_label=flag.external_source,
                content=(
                    f"Verified external value: {flag.external_value:,.2f} "
                    f"(source: {flag.external_source}, year: {flag.reporting_year})"
                ),
                confidence=0.95,
                url=flag.evidence_url,
                metadata={
                    "external_value": flag.external_value,
                    "claim_value":    flag.claim_value,
                    "delta_pct":      flag.delta_pct,
                },
            ))

        # Evidence piece 3: SHAP attribution if available
        if shap_explanations and flag.claim_text in shap_explanations:
            expl = shap_explanations[flag.claim_text]
            top_tokens = [
                a.feature_name.replace("token:", "")
                for a in expl.token_attributions[:4]
            ]
            pieces.append(EvidencePiece(
                evidence_type="shap_feature",
                source_label="Sprint 2 Classifier (SHAP)",
                content=(
                    f"Classifier label: {expl.predicted_label} "
                    f"(conf: {expl.confidence:.0%}). "
                    f"Top signal words: {', '.join(top_tokens)}."
                ),
                confidence=expl.confidence,
                metadata={"top_tokens": top_tokens, "label": expl.predicted_label},
            ))

        # Regulatory references
        reg_refs = REGULATORY_REFERENCES.get(flag.inconsistency_type, [])

        # Build investor summary
        investor_summary = self._build_investor_summary(flag)
        recommended_action = self._build_recommended_action(flag)

        return EvidenceBundle(
            flag_id=flag.flag_id,
            company_ticker=flag.company_ticker,
            inconsistency_type=flag.inconsistency_type,
            severity=flag.severity.value,
            claim_text=flag.claim_text,
            evidence_pieces=pieces,
            regulatory_refs=reg_refs,
            investor_summary=investor_summary,
            recommended_action=recommended_action,
        )

    def _build_investor_summary(self, flag: InconsistencyFlag) -> str:
        templates = {
            "NUMERIC_MISMATCH": (
                f"{flag.company_ticker}'s ESG report states a value that diverges from "
                f"independently verified external data by {abs(flag.delta_pct or 0):.0f}%. "
                f"This discrepancy ({flag.external_source} data) may indicate a methodology "
                f"difference, a reporting error, or deliberate selective presentation. "
                f"Investors should request explicit reconciliation before relying on this figure."
            ),
            "SCOPE_OMISSION": (
                f"{flag.company_ticker}'s disclosed emissions claims focus on Scope 1/2 "
                f"while Scope 3 supply chain emissions — estimated at "
                f"{abs(flag.delta_pct or 0):.0f}x the disclosed figure — remain unaddressed. "
                f"For most consumer and technology companies, Scope 3 represents 80-95% "
                f"of the total climate impact. Omitting it creates a materially incomplete picture."
            ),
            "TEMPORAL_ANOMALY": (
                f"{flag.company_ticker} reported a {abs(flag.delta_pct or 0):.0f}% "
                f"year-on-year change in emissions that exceeds typical operational improvement rates. "
                f"This may reflect asset disposals, boundary changes, or methodology restatement "
                f"rather than genuine decarbonisation — which would overstate the company's "
                f"actual climate progress."
            ),
            "VERIFICATION_GAP": (
                f"{flag.company_ticker} makes multiple specific quantitative ESG claims "
                f"without third-party verification. Unverified ESG metrics carry significantly "
                f"higher greenwashing risk and should not be treated as equivalent to "
                f"independently assured disclosures by institutional investors or regulators."
            ),
            "CONTROVERSY_CONTEXT": (
                f"Sustainalytics rates {flag.company_ticker} at Level "
                f"{int(flag.external_value or 0)}/5 on their controversy scale, "
                f"indicating significant documented ESG incidents. Positive sustainability "
                f"claims should be evaluated against this track record of controversies "
                f"before being accepted at face value."
            ),
        }
        return templates.get(
            flag.inconsistency_type,
            f"{flag.company_ticker}: {flag.explanation[:200]}"
        )

    def _build_recommended_action(self, flag: InconsistencyFlag) -> str:
        actions = {
            "NUMERIC_MISMATCH": (
                "Request the company provide a written reconciliation between the "
                "reported figure and the externally verified value, specifying any "
                "methodology or boundary differences."
            ),
            "SCOPE_OMISSION": (
                "Require Scope 3 category-level disclosure as a minimum condition "
                "for ESG investment labelling. Prioritise Categories 1, 11 and 15."
            ),
            "TEMPORAL_ANOMALY": (
                "Request confirmation of whether reduction reflects genuine efficiency "
                "improvement or asset disposal. Require prior-year restatement per "
                "GHG Protocol recalculation policy if methodology changed."
            ),
            "VERIFICATION_GAP": (
                "Require at minimum limited assurance (ISO 14064-3 or AA1000AS) "
                "for all reported Scope 1, 2, and 3 figures before including in "
                "ESG scoring or green finance frameworks."
            ),
            "CONTROVERSY_CONTEXT": (
                "Commission an independent review of the specific controversy categories "
                "flagged by Sustainalytics before accepting positive sustainability claims. "
                "Require the company to disclose and address each documented incident."
            ),
        }
        return actions.get(flag.inconsistency_type, flag.recommendation)

    def save(self, bundles: list[EvidenceBundle], output_dir: Path) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / "evidence_citations.json"
        with open(path, "w") as f:
            json.dump([b.to_dict() for b in bundles], f, indent=2)
        return path
