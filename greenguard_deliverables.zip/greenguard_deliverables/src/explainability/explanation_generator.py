"""
explainability/explanation_generator.py
─────────────────────────────────────────
Natural-language explanation generator for greenwashing flags.

Uses HuggingFace Inference API (https://api-inference.huggingface.co) with
open-weight instruction-following models. No proprietary API required.

Model priority order (all free-tier on HuggingFace):
  1. mistralai/Mistral-7B-Instruct-v0.3   -- best balance: quality + speed
  2. HuggingFaceH4/zephyr-7b-beta         -- strong instruction following
  3. microsoft/Phi-3-mini-4k-instruct     -- fast, low memory

Authentication:
  Set env var HF_API_TOKEN=hf_xxxx  (or pass token= to ExplanationGenerator).
  Free token at https://huggingface.co/settings/tokens

Fallback chain:
  HuggingFace API -> template generator (always works, no API needed)
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from src.inconsistency.detector import InconsistencyFlag, InconsistencyReport
from src.explainability.evidence_citations import EvidenceBundle


HF_BASE_URL = "https://api-inference.huggingface.co/models"

HF_MODELS = [
    "mistralai/Mistral-7B-Instruct-v0.3",
    "HuggingFaceH4/zephyr-7b-beta",
    "microsoft/Phi-3-mini-4k-instruct",
]

_CHAT_TEMPLATES = {
    "mistral": "[INST] <<SYS>>\n{system}\n<</SYS>>\n\n{user} [/INST]",
    "zephyr":  "<|system|>\n{system}\n<|user|>\n{user}\n<|assistant|>",
    "phi":     "<|system|>{system}<|end|><|user|>{user}<|end|><|assistant|>",
    "default": "### System:\n{system}\n\n### User:\n{user}\n\n### Assistant:",
}

def _get_template(model_id: str) -> str:
    lower = model_id.lower()
    if "mistral" in lower: return _CHAT_TEMPLATES["mistral"]
    if "zephyr"  in lower: return _CHAT_TEMPLATES["zephyr"]
    if "phi"     in lower: return _CHAT_TEMPLATES["phi"]
    return _CHAT_TEMPLATES["default"]


SYSTEM_PROMPT = (
    "You are an ESG analyst AI explaining potential greenwashing flags to institutional "
    "investors and regulators. You will be given structured evidence about an ESG "
    "disclosure inconsistency and must produce a clear, accurate explanation.\n\n"
    "CRITICAL RULES:\n"
    "1. Only use the evidence provided - do not add facts, numbers, or context not given to you.\n"
    "2. Write in professional, neutral language suitable for investor reports.\n"
    "3. Be specific: reference the exact values, sources, and discrepancies given.\n"
    "4. Never make definitive conclusions - say 'may indicate', 'warrants verification'.\n"
    "5. Respond ONLY with a valid JSON object - no markdown fences, no preamble."
)


@dataclass
class GeneratedExplanation:
    flag_id:            str
    company_ticker:     str
    inconsistency_type: str
    severity:           str
    explanation_short:  str
    explanation_full:   str
    action_item:        str
    confidence_note:    str
    generated_by:       str   # "hf:{model_id}" | "template"
    generation_time_ms: int
    model_used:         str = ""

    def to_dict(self) -> dict:
        return {
            "flag_id":            self.flag_id,
            "company_ticker":     self.company_ticker,
            "inconsistency_type": self.inconsistency_type,
            "severity":           self.severity,
            "explanation_short":  self.explanation_short,
            "explanation_full":   self.explanation_full,
            "action_item":        self.action_item,
            "confidence_note":    self.confidence_note,
            "generated_by":       self.generated_by,
            "model_used":         self.model_used,
            "generation_time_ms": self.generation_time_ms,
        }


class ExplanationGenerator:
    """
    Generates natural-language greenwashing flag explanations.

    Uses HuggingFace Inference API with open-weight models.
    Falls back to template generation if API unavailable.

    Usage:
        gen = ExplanationGenerator(token="hf_xxxx")   # explicit token
        gen = ExplanationGenerator()                   # uses HF_API_TOKEN env var
        gen = ExplanationGenerator(use_api=False)      # template only
    """

    REQUEST_TIMEOUT = 25
    MAX_NEW_TOKENS  = 380
    TEMPERATURE     = 0.2
    TOP_P           = 0.85

    def __init__(
        self,
        token:   Optional[str] = None,
        use_api: bool          = True,
        models:  list[str]     = HF_MODELS,
    ):
        self.use_api = use_api
        self.models  = models
        self._token  = token or os.getenv("HF_API_TOKEN", "")
        self._working_model: Optional[str] = None
        self._api_available = self._probe_api() if use_api else False

    # ── Public ────────────────────────────────────────────────────────────────

    def generate(self, flag: InconsistencyFlag, bundle: EvidenceBundle) -> GeneratedExplanation:
        t0 = int(time.time() * 1000)
        if self.use_api and self._api_available:
            result, model_used = self._generate_with_hf(flag, bundle)
            method = f"hf:{model_used}" if model_used else "template"
        else:
            result, model_used = self._generate_from_template(flag, bundle), ""
            method = "template"
        return GeneratedExplanation(
            flag_id=flag.flag_id, company_ticker=flag.company_ticker,
            inconsistency_type=flag.inconsistency_type, severity=flag.severity.value,
            explanation_short=result["short"], explanation_full=result["full"],
            action_item=result["action"], confidence_note=result["caveat"],
            generated_by=method, generation_time_ms=int(time.time()*1000)-t0,
            model_used=model_used,
        )

    def generate_batch(self, report: InconsistencyReport, bundles: list[EvidenceBundle]) -> list[GeneratedExplanation]:
        flag_map = {f.flag_id: f for f in report.flags}
        return [self.generate(flag_map[b.flag_id], b) for b in bundles if b.flag_id in flag_map]

    def save(self, explanations: list[GeneratedExplanation], output_dir: Path) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / "generated_explanations.json"
        with open(path, "w") as f:
            json.dump([e.to_dict() for e in explanations], f, indent=2)
        return path

    @property
    def api_status(self) -> dict:
        return {
            "provider":      "HuggingFace Inference API",
            "available":     self._api_available,
            "token_set":     bool(self._token),
            "working_model": self._working_model,
            "models_tried":  self.models,
            "hf_token_url":  "https://huggingface.co/settings/tokens",
        }

    # ── HuggingFace call ──────────────────────────────────────────────────────

    def _generate_with_hf(self, flag: InconsistencyFlag, bundle: EvidenceBundle) -> tuple[dict, str]:
        user_prompt = self._build_user_prompt(flag, bundle)
        models_to_try = (
            [self._working_model] + [m for m in self.models if m != self._working_model]
            if self._working_model else self.models
        )
        for model_id in models_to_try:
            try:
                raw    = self._call_hf(model_id, user_prompt)
                parsed = self._parse_json_response(raw)
                if parsed:
                    self._working_model = model_id
                    return parsed, model_id
            except Exception:
                continue
        return self._generate_from_template(flag, bundle), ""

    def _call_hf(self, model_id: str, user_prompt: str) -> str:
        template    = _get_template(model_id)
        full_prompt = template.format(system=SYSTEM_PROMPT, user=user_prompt)
        payload = json.dumps({
            "inputs": full_prompt,
            "parameters": {
                "max_new_tokens":   self.MAX_NEW_TOKENS,
                "temperature":      self.TEMPERATURE,
                "top_p":            self.TOP_P,
                "return_full_text": False,
                "do_sample":        True,
            },
            "options": {"wait_for_model": True, "use_cache": False},
        }).encode()
        headers = {
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {self._token}" if self._token else "",
            "User-Agent":    "ESG-Greenwashing-Research/0.4.0",
        }
        req = urllib.request.Request(
            f"{HF_BASE_URL}/{model_id}", data=payload, headers=headers, method="POST"
        )
        with urllib.request.urlopen(req, timeout=self.REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read())
        if isinstance(data, list) and data:
            return data[0].get("generated_text", "")
        if isinstance(data, dict):
            return data.get("generated_text", "")
        return str(data)

    def _parse_json_response(self, raw: str) -> Optional[dict]:
        if not raw or not raw.strip():
            return None
        text = raw.strip()
        # Strip markdown fences
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.MULTILINE)
        text = re.sub(r"\s*```\s*$",       "", text, flags=re.MULTILINE)
        text = text.strip()
        # Attempt 1: direct parse
        try:
            return self._validate_dict(json.loads(text))
        except json.JSONDecodeError:
            pass
        # Attempt 2: find first {...} block
        m = re.search(r"(\{.*?\})", text, re.DOTALL)
        if m:
            try:
                return self._validate_dict(json.loads(m.group(1)))
            except json.JSONDecodeError:
                pass
        # Attempt 3: greedy {...} block
        m2 = re.search(r"(\{.*\})", text, re.DOTALL)
        if m2:
            try:
                return self._validate_dict(json.loads(m2.group(1)))
            except json.JSONDecodeError:
                pass
        return None

    @staticmethod
    def _validate_dict(d: dict) -> Optional[dict]:
        required = {"short", "full", "action", "caveat"}
        if not isinstance(d, dict) or not required.issubset(d.keys()):
            return None
        if not all(isinstance(d[k], str) and d[k].strip() for k in required):
            return None
        return {k: d[k].strip() for k in required}

    def _build_user_prompt(self, flag: InconsistencyFlag, bundle: EvidenceBundle) -> str:
        evidence_lines = "\n".join(
            f"  [{e.source_label}]: {e.content[:200]}"
            for e in bundle.evidence_pieces
        )
        reg_ref = ""
        if bundle.regulatory_refs:
            r = bundle.regulatory_refs[0]
            reg_ref = f"\nRegulatory reference: {r['regulator']} - {r['document']} - {r['relevance']}"
        return (
            f"Generate an ESG greenwashing flag explanation for an investor report.\n\n"
            f"Company: {flag.company_ticker}\n"
            f"Flag type: {flag.inconsistency_type}\n"
            f"Severity: {flag.severity.value}\n"
            f"Claim text: \"{flag.claim_text[:280]}\"\n\n"
            f"Evidence (use ONLY these facts):\n{evidence_lines}"
            f"{reg_ref}\n\n"
            f"Respond with ONLY a JSON object with exactly these four keys:\n"
            f"  \"short\":  1-sentence summary, max 25 words\n"
            f"  \"full\":   3-sentence investor explanation using only the evidence above\n"
            f"  \"action\": 1-sentence specific recommended action\n"
            f"  \"caveat\": 1-sentence confidence limitation\n\n"
            f"Example: {{\"short\": \"...\", \"full\": \"...\", \"action\": \"...\", \"caveat\": \"...\"}}"
        )

    # ── Template fallback ─────────────────────────────────────────────────────

    def _generate_from_template(self, flag: InconsistencyFlag, bundle: EvidenceBundle) -> dict:
        delta   = abs(flag.delta_pct or 0)
        ext_val = flag.external_value
        ext_src = flag.external_source or "external source"
        short_map = {
            "NUMERIC_MISMATCH":    f"{flag.company_ticker} reported value diverges {delta:.0f}% from {ext_src}-verified data.",
            "SCOPE_OMISSION":      f"{flag.company_ticker} omits Scope 3 emissions that are {delta:.0f}x larger than disclosed Scope 1 figures.",
            "TEMPORAL_ANOMALY":    f"{flag.company_ticker} reported an implausible {delta:.0f}% year-on-year emissions change.",
            "VERIFICATION_GAP":    f"{flag.company_ticker} makes quantified ESG claims without independent third-party assurance.",
            "CONTROVERSY_CONTEXT": f"{flag.company_ticker} carries a Level {int(ext_val or 0)}/5 Sustainalytics controversy rating.",
        }
        caveat_map = {
            "NUMERIC_MISMATCH":    "This comparison may not account for all methodological differences between reporting frameworks.",
            "SCOPE_OMISSION":      "Scope 3 estimates carry inherent uncertainty; the absence of disclosure itself is the primary concern.",
            "TEMPORAL_ANOMALY":    "Rapid changes may reflect legitimate operational or boundary changes; context from the company is required.",
            "VERIFICATION_GAP":    "Absence of assurance does not mean claims are inaccurate; it means they cannot be independently verified.",
            "CONTROVERSY_CONTEXT": "Controversy ratings may not capture subsequent remediation actions taken by the company.",
        }
        return {
            "short":  short_map.get(flag.inconsistency_type, flag.explanation[:100]),
            "full":   bundle.investor_summary,
            "action": bundle.recommended_action,
            "caveat": caveat_map.get(flag.inconsistency_type, "Assessment based on available evidence only."),
        }

    # ── API probe ─────────────────────────────────────────────────────────────

    def _probe_api(self) -> bool:
        try:
            req = urllib.request.Request(
                f"{HF_BASE_URL}/mistralai/Mistral-7B-Instruct-v0.3",
                headers={
                    "Authorization": f"Bearer {self._token}" if self._token else "",
                    "User-Agent":    "ESG-Greenwashing-Research/0.4.0",
                },
                method="HEAD",
            )
            urllib.request.urlopen(req, timeout=5)
            return True
        except urllib.error.HTTPError as e:
            return e.code in (200, 401, 403, 503)
        except Exception:
            return False
