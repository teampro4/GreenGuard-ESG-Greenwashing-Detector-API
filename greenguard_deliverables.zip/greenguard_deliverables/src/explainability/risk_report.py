"""
explainability/risk_report.py
──────────────────────────────
Composite ESG Greenwashing Risk Report generator.

Produces a PDF report per company containing:
  • Cover page with GRS gauge
  • Executive summary
  • Flag-by-flag breakdown with evidence citations
  • SHAP attribution table
  • Temporal trend data
  • Regulatory references
  • Recommended investor actions

Uses ReportLab (pure Python, no network required).
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT


# ── Color palette ──────────────────────────────────────────────────────────────
C_PURPLE  = colors.HexColor("#6C3483")
C_PURPLE_L= colors.HexColor("#D7BDE2")
C_PURPLE_BG=colors.HexColor("#F5EEF8")
C_CRITICAL= colors.HexColor("#7B241C")
C_CRITICAL_BG=colors.HexColor("#FDEDEC")
C_HIGH    = colors.HexColor("#784212")
C_HIGH_BG = colors.HexColor("#FEF9E7")
C_MEDIUM  = colors.HexColor("#1A5276")
C_MEDIUM_BG=colors.HexColor("#EBF5FB")
C_LOW     = colors.HexColor("#145A32")
C_LOW_BG  = colors.HexColor("#EAFAF1")
C_DARK    = colors.HexColor("#1C2833")
C_MUTED   = colors.HexColor("#566573")
C_BORDER  = colors.HexColor("#CCCCCC")

SEVERITY_COLORS = {
    "CRITICAL": (C_CRITICAL, C_CRITICAL_BG),
    "HIGH":     (C_HIGH,     C_HIGH_BG),
    "MEDIUM":   (C_MEDIUM,   C_MEDIUM_BG),
    "LOW":      (C_LOW,      C_LOW_BG),
}

RISK_BAND_COLORS = {
    "CRITICAL": C_CRITICAL,
    "HIGH":     C_HIGH,
    "MEDIUM":   C_MEDIUM,
    "LOW":      C_LOW,
}


def _styles():
    base = getSampleStyleSheet()
    custom = {
        "h1": ParagraphStyle("H1", fontName="Helvetica-Bold", fontSize=18,
                             textColor=C_PURPLE, spaceAfter=6, spaceBefore=12),
        "h2": ParagraphStyle("H2", fontName="Helvetica-Bold", fontSize=13,
                             textColor=C_PURPLE, spaceAfter=4, spaceBefore=8),
        "h3": ParagraphStyle("H3", fontName="Helvetica-Bold", fontSize=11,
                             textColor=C_DARK, spaceAfter=3, spaceBefore=6),
        "body": ParagraphStyle("Body", fontName="Helvetica", fontSize=9,
                               textColor=C_DARK, spaceAfter=3, leading=14),
        "small": ParagraphStyle("Small", fontName="Helvetica", fontSize=8,
                                textColor=C_MUTED, spaceAfter=2, leading=12),
        "caption": ParagraphStyle("Caption", fontName="Helvetica-Oblique", fontSize=8,
                                  textColor=C_MUTED),
        "code": ParagraphStyle("Code", fontName="Courier", fontSize=8,
                               textColor=C_DARK, leading=12,
                               backColor=colors.HexColor("#F2F3F4")),
        "label": ParagraphStyle("Label", fontName="Helvetica-Bold", fontSize=8,
                                textColor=C_MUTED),
        "center": ParagraphStyle("Center", fontName="Helvetica", fontSize=9,
                                 alignment=TA_CENTER, textColor=C_DARK),
    }
    return custom


def _grs_table(grs: float, risk_band: str, n_flags: int, n_critical: int) -> Table:
    """Build a compact GRS summary table."""
    band_color, band_bg = SEVERITY_COLORS.get(risk_band, (C_MEDIUM, C_MEDIUM_BG))
    data = [
        ["Greenwashing Risk Score", "Risk Band", "Total Flags", "Critical Flags"],
        [
            Paragraph(f"<b>{grs:.1f}</b> / 100", ParagraphStyle("", fontName="Helvetica-Bold",
                      fontSize=20, textColor=band_color, alignment=TA_CENTER)),
            Paragraph(f"<b>{risk_band}</b>", ParagraphStyle("", fontName="Helvetica-Bold",
                      fontSize=14, textColor=band_color, alignment=TA_CENTER)),
            Paragraph(str(n_flags), ParagraphStyle("", fontName="Helvetica-Bold",
                      fontSize=16, textColor=C_DARK, alignment=TA_CENTER)),
            Paragraph(str(n_critical), ParagraphStyle("", fontName="Helvetica-Bold",
                      fontSize=16, textColor=C_CRITICAL if n_critical>0 else C_LOW,
                      alignment=TA_CENTER)),
        ],
    ]
    t = Table(data, colWidths=[45*mm, 45*mm, 35*mm, 35*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), C_PURPLE),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, 0), 9),
        ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("ROWHEIGHT",  (0, 0), (-1, 0), 14),
        ("ROWHEIGHT",  (0, 1), (-1, 1), 28),
        ("BACKGROUND", (0, 1), (1, 1), band_bg),
        ("BACKGROUND", (2, 1), (-1, 1), colors.HexColor("#F2F3F4")),
        ("GRID",       (0, 0), (-1, -1), 0.5, C_BORDER),
        ("TOPPADDING",  (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def _flag_table(flag_dict: dict, explanation_dict: Optional[dict] = None) -> list:
    """Build flowable blocks for one flag."""
    s = _styles()
    sev = flag_dict.get("severity", "MEDIUM")
    sev_color, sev_bg = SEVERITY_COLORS.get(sev, (C_MEDIUM, C_MEDIUM_BG))
    ftype = flag_dict.get("inconsistency_type", "")

    elems = []

    # Flag header
    header_data = [[
        Paragraph(f"<b>{sev}</b>", ParagraphStyle("", fontName="Helvetica-Bold",
                  fontSize=9, textColor=sev_color)),
        Paragraph(f"<b>{ftype}</b>", ParagraphStyle("", fontName="Helvetica-Bold",
                  fontSize=9, textColor=C_DARK)),
        Paragraph(f"Flag ID: {flag_dict.get('flag_id','')}", s["small"]),
    ]]
    ht = Table(header_data, colWidths=[28*mm, 80*mm, 52*mm])
    ht.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), sev_bg),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LINEBELOW", (0, 0), (-1, 0), 1, sev_color),
    ]))
    elems.append(ht)
    elems.append(Spacer(1, 2*mm))

    # Evidence and explanation
    if explanation_dict:
        elems.append(Paragraph(
            f"<b>Summary:</b> {explanation_dict.get('explanation_short','')}",
            s["body"]
        ))
        elems.append(Paragraph(
            explanation_dict.get("explanation_full", flag_dict.get("explanation", "")),
            s["body"]
        ))
        elems.append(Spacer(1, 1*mm))
        elems.append(Paragraph(
            f"<b>Recommended Action:</b> {explanation_dict.get('action_item','')}",
            ParagraphStyle("", fontName="Helvetica", fontSize=9, textColor=C_DARK,
                           leftIndent=5, borderPad=3)
        ))
        elems.append(Paragraph(
            f"<i>Confidence note:</i> {explanation_dict.get('confidence_note','')}",
            s["caption"]
        ))
    else:
        elems.append(Paragraph(flag_dict.get("explanation", "")[:400], s["body"]))

    # Numeric evidence
    cv = flag_dict.get("claim_value")
    ev = flag_dict.get("external_value")
    src = flag_dict.get("external_source", "")
    dp = flag_dict.get("delta_pct")
    if cv is not None and ev is not None:
        num_data = [
            ["", "Claimed Value", "External Value", "Source", "Delta"],
            ["", f"{cv:,.2f}" if isinstance(cv, float) else str(cv),
             f"{ev:,.2f}" if isinstance(ev, float) else str(ev),
             src, f"{dp:+.1f}%" if dp is not None else "N/A"],
        ]
        nt = Table(num_data, colWidths=[8*mm, 38*mm, 38*mm, 38*mm, 38*mm])
        nt.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), C_PURPLE),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, -1), 8),
            ("ALIGN",      (1, 0), (-1, -1), "CENTER"),
            ("GRID",       (0, 0), (-1, -1), 0.5, C_BORDER),
            ("TOPPADDING",  (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        elems.append(Spacer(1, 1*mm))
        elems.append(nt)

    elems.append(Spacer(1, 4*mm))
    elems.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    elems.append(Spacer(1, 3*mm))
    return elems


def generate_company_report(
    company_ticker:   str,
    company_name:     str,
    report_year:      int,
    grs:              float,
    risk_band:        str,
    flags:            list[dict],
    explanations:     list[dict],
    evidence_bundles: list[dict],
    shap_summary:     Optional[dict],
    temporal_insights: list[dict],
    output_path:      Path,
) -> Path:
    """
    Generate a full PDF risk report for one company.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    s = _styles()

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        rightMargin=20*mm, leftMargin=20*mm,
        topMargin=18*mm, bottomMargin=20*mm,
        title=f"ESG Greenwashing Risk Report — {company_ticker} {report_year}",
    )

    story = []

    # ── Cover ─────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 8*mm))
    story.append(Paragraph("ESG GREENWASHING RISK REPORT", ParagraphStyle(
        "", fontName="Helvetica-Bold", fontSize=10, textColor=C_PURPLE_L,
        alignment=TA_CENTER)))
    story.append(Paragraph(company_name, ParagraphStyle(
        "", fontName="Helvetica-Bold", fontSize=22, textColor=C_PURPLE,
        alignment=TA_CENTER, spaceAfter=2)))
    story.append(Paragraph(f"{company_ticker}  |  FY{report_year}  |  ESG Authenticity Verification",
        ParagraphStyle("", fontName="Helvetica", fontSize=10, textColor=C_MUTED,
                       alignment=TA_CENTER, spaceAfter=10)))
    story.append(HRFlowable(width="100%", thickness=2, color=C_PURPLE))
    story.append(Spacer(1, 5*mm))

    # GRS gauge
    story.append(_grs_table(grs, risk_band, len(flags),
                             sum(1 for f in flags if f.get("severity")=="CRITICAL")))
    story.append(Spacer(1, 5*mm))

    # Generated date
    story.append(Paragraph(
        f"Report generated: {time.strftime('%d %B %Y')}  |  "
        f"System: ESG Greenwashing Detector v0.4.0  |  "
        f"Classification: CONFIDENTIAL — Research Use Only",
        s["caption"]
    ))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    story.append(Spacer(1, 6*mm))

    # ── Executive summary ─────────────────────────────────────────────────────
    story.append(Paragraph("Executive Summary", s["h1"]))

    n_crit = sum(1 for f in flags if f.get("severity") == "CRITICAL")
    n_med  = sum(1 for f in flags if f.get("severity") == "MEDIUM")
    n_temp = len(temporal_insights)

    story.append(Paragraph(
        f"The automated ESG authenticity analysis of {company_name}'s {report_year} "
        f"sustainability disclosures identified <b>{len(flags)} inconsistency flag(s)</b> "
        f"across five detection categories, yielding a Greenwashing Risk Score of "
        f"<b>{grs:.1f}/100 ({risk_band} band)</b>. "
        f"Of these, {n_crit} flag(s) are rated CRITICAL and {n_med} MEDIUM, requiring "
        f"immediate investor attention. Additionally, {n_temp} temporal trajectory alert(s) "
        f"were identified from year-on-year emissions trend analysis.",
        s["body"]
    ))
    story.append(Spacer(1, 3*mm))

    # Flag summary table
    if flags:
        summary_data = [["Flag Type", "Severity", "Key Finding"]]
        for f in flags:
            summary_data.append([
                f.get("inconsistency_type", ""),
                f.get("severity", ""),
                f.get("explanation", "")[:80] + "...",
            ])
        st = Table(summary_data, colWidths=[45*mm, 25*mm, 90*mm])
        st.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), C_PURPLE),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, -1), 8),
            ("ALIGN",      (0, 0), (-1, -1), "LEFT"),
            ("VALIGN",     (0, 0), (-1, -1), "TOP"),
            ("GRID",       (0, 0), (-1, -1), 0.5, C_BORDER),
            ("TOPPADDING",  (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PURPLE_BG, colors.white]),
        ]))
        story.append(st)

    story.append(PageBreak())

    # ── Flag details ──────────────────────────────────────────────────────────
    story.append(Paragraph("Inconsistency Flag Details", s["h1"]))
    expl_map = {e.get("flag_id"): e for e in explanations}

    for flag in flags:
        flag_expl = expl_map.get(flag.get("flag_id"))
        story.extend(_flag_table(flag, flag_expl))

    # ── Temporal insights ─────────────────────────────────────────────────────
    if temporal_insights:
        story.append(Spacer(1, 3*mm))
        story.append(Paragraph("Temporal Consistency Alerts", s["h2"]))
        for ins in temporal_insights:
            sev = ins.get("severity", "MEDIUM")
            sev_color, sev_bg = SEVERITY_COLORS.get(sev, (C_MEDIUM, C_MEDIUM_BG))
            ins_data = [[
                Paragraph(f"<b>{ins.get('insight_type','')}</b>",
                          ParagraphStyle("", fontName="Helvetica-Bold", fontSize=9,
                                         textColor=sev_color)),
                Paragraph(ins.get("description", "")[:350], s["body"]),
            ]]
            it = Table(ins_data, colWidths=[45*mm, 115*mm])
            it.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), sev_bg),
                ("LINEBELOW", (0, 0), (-1, 0), 0.5, sev_color),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
            story.append(it)
            story.append(Spacer(1, 2*mm))

    story.append(PageBreak())

    # ── SHAP attribution ─────────────────────────────────────────────────────
    story.append(Paragraph("Classifier Attribution (SHAP)", s["h1"]))
    story.append(Paragraph(
        "The table below shows the top features driving the Sprint 2 classifier's "
        "greenwashing label for this company's claims. Positive SHAP values increase "
        "greenwashing probability; negative values reduce it.",
        s["body"]
    ))
    story.append(Spacer(1, 3*mm))

    if shap_summary:
        shap_data = [["Feature", "Type", "Mean |SHAP|", "Direction", "Interpretation"]]
        for row in shap_summary.get("top_features", [])[:12]:
            shap_data.append([
                row.get("feature", "")[:35],
                row.get("type", ""),
                f"{row.get('mean_abs_shap', 0):.4f}",
                row.get("direction", ""),
                row.get("interpretation", "")[:50],
            ])
        shapT = Table(shap_data, colWidths=[50*mm, 20*mm, 22*mm, 22*mm, 46*mm])
        shapT.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), C_PURPLE),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, -1), 7.5),
            ("GRID",       (0, 0), (-1, -1), 0.5, C_BORDER),
            ("TOPPADDING",  (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PURPLE_BG, colors.white]),
        ]))
        story.append(shapT)
    else:
        story.append(Paragraph("SHAP data not available for this report.", s["body"]))

    story.append(Spacer(1, 5*mm))

    # ── GRS formula explanation ───────────────────────────────────────────────
    story.append(Paragraph("Greenwashing Risk Score Methodology", s["h2"]))
    grs_data = [
        ["Severity Level", "Points per Flag", "Flags Detected", "Contribution"],
        ["CRITICAL",       "8.0",             str(n_crit),       f"{n_crit * 8.0:.1f}"],
        ["MEDIUM",         "3.0",             str(n_med),        f"{n_med * 3.0:.1f}"],
        ["LOW",            "1.0",             str(len(flags)-n_crit-n_med), f"{(len(flags)-n_crit-n_med) * 1.0:.1f}"],
        ["TOTAL",          "",                str(len(flags)),   f"Raw={n_crit*8+n_med*3+(len(flags)-n_crit-n_med):.1f} → GRS={grs:.1f}"],
    ]
    grsT = Table(grs_data, colWidths=[45*mm, 40*mm, 35*mm, 40*mm])
    grsT.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), C_PURPLE),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME",   (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), C_PURPLE_BG),
        ("FONTSIZE",   (0, 0), (-1, -1), 8.5),
        ("GRID",       (0, 0), (-1, -1), 0.5, C_BORDER),
        ("ALIGN",      (1, 0), (-1, -1), "CENTER"),
        ("TOPPADDING",  (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(grsT)

    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(
        "<b>Disclaimer:</b> This report is generated by an automated AI system for "
        "research purposes. It should not be used as the sole basis for investment "
        "decisions. All flags require human expert validation before regulatory "
        "or investment action.",
        ParagraphStyle("", fontName="Helvetica-Oblique", fontSize=8,
                       textColor=C_MUTED, leading=11)
    ))

    doc.build(story)
    return output_path
