"""
explainability/shap_explainer.py
─────────────────────────────────
Feature attribution for the Sprint 2 Logistic Regression classifier.

For Logistic Regression, exact SHAP values are computed analytically:
  SHAP_i = coef_i * (x_i - E[x_i])

This gives exact, additive attributions that sum to (prediction - base_rate),
unlike approximate SHAP methods needed for tree or neural models.

The explainer outputs:
  • Per-feature SHAP values (which features pushed the prediction most)
  • Top-K attribution table (human-readable: feature name + contribution)
  • Token-level attributions for TF-IDF features (which words drove the decision)
  • Claim-level attribution narrative (text description of key drivers)
"""

from __future__ import annotations

import json
import pickle
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


@dataclass
class FeatureAttribution:
    """SHAP attribution for one feature in one prediction."""
    feature_name:  str
    feature_value: float
    shap_value:    float          # contribution to log-odds
    abs_shap:      float          # |shap_value| for ranking
    direction:     str            # "increases_risk" | "decreases_risk" | "neutral"
    feature_type:  str            # "tfidf_token" | "ontology" | "keyword" | "structural"


@dataclass
class PredictionExplanation:
    """Full SHAP explanation for one claim prediction."""
    claim_text:         str
    predicted_label:    str
    confidence:         float
    base_probability:   float       # class prior
    top_attributions:   list[FeatureAttribution]
    token_attributions: list[FeatureAttribution]  # TF-IDF tokens only
    ontology_attributions: list[FeatureAttribution]
    narrative:          str          # human-readable summary
    risk_drivers:       list[str]    # plain-English top drivers

    def to_dict(self) -> dict:
        return {
            "claim_text":      self.claim_text[:300],
            "predicted_label": self.predicted_label,
            "confidence":      self.confidence,
            "base_probability": self.base_probability,
            "top_attributions": [
                {"feature": a.feature_name, "shap": round(a.shap_value, 4),
                 "direction": a.direction, "type": a.feature_type}
                for a in self.top_attributions[:10]
            ],
            "token_attributions": [
                {"token": a.feature_name, "shap": round(a.shap_value, 4)}
                for a in self.token_attributions[:8]
            ],
            "narrative":     self.narrative,
            "risk_drivers":  self.risk_drivers,
        }


class LRSHAPExplainer:
    """
    Exact SHAP values for a CalibratedClassifierCV wrapping LogisticRegression.

    For each class c and feature i:
        SHAP_i(c) = coef_c_i * (x_i - mean_train_i)

    This is exact (not approximate) because LR is a linear model.
    The calibration wrapper does not change the feature weights directly,
    so we extract coefficients from the base estimator.
    """

    # Mapping from dense feature index to human-readable name
    DENSE_FEATURE_NAMES = [
        # Ontology (12)
        "vagueness_score", "specificity_score", "has_quantified_target",
        "has_temporal_target", "has_third_party_verification", "label_confidence",
        "vagueness_signal_high", "vagueness_signal_medium", "vagueness_signal_low",
        "vagueness_signal_none", "pillar_environmental", "pillar_social",
        # Keyword groups (7)
        "kw_commitment_language", "kw_vague_temporal", "kw_verified_standards",
        "kw_quantified", "kw_selective_disclosure", "kw_awards_best_in_class",
        "kw_offset_heavy",
        "kw_superlative",
        # Structural (13)
        "word_count", "char_count", "avg_word_length", "num_sentences",
        "avg_sentence_length", "num_numbers", "has_percentage", "has_year",
        "has_dollar_amount", "exclamation_count", "uppercase_ratio",
        "parenthetical_count", "semicolon_count",
    ]

    def __init__(self, classifier_path: Path):
        with open(classifier_path, "rb") as f:
            self.clf = pickle.load(f)

        # Extract the base LR from the calibrated wrapper
        # CalibratedClassifierCV has calibrated_classifiers_ attribute
        try:
            # Get average coefficients across calibration folds
            base_estimators = self.clf.clf.calibrated_classifiers_
            coef_list = [est.estimator.coef_ for est in base_estimators]
            self._coef = np.mean(coef_list, axis=0)  # (n_classes, n_features)
            self._intercept = np.mean(
                [est.estimator.intercept_ for est in base_estimators], axis=0
            )
        except AttributeError:
            # Fallback: try to access directly
            self._coef = self.clf.clf.estimator.coef_
            self._intercept = self.clf.clf.estimator.intercept_

        self._classes = list(self.clf.label_encoder.classes_)
        self._fe = self.clf.feature_extractor
        self._tfidf_vocab = {
            v: k for k, v in self._fe.tfidf.vocabulary_.items()
        }
        self._n_tfidf = len(self._fe.tfidf.vocabulary_)

        # Compute training feature means for SHAP baseline
        self._feature_means: Optional[np.ndarray] = None

    def fit_baseline(self, train_texts: list[str]) -> None:
        """Compute feature means on training set (required for SHAP values)."""
        X = self._fe.transform(train_texts)
        self._feature_means = X.mean(axis=0)

    def explain(
        self,
        text: str,
        label: Optional[str] = None,
        top_k: int = 15,
    ) -> PredictionExplanation:
        """
        Compute SHAP explanation for a single claim text.

        Args:
            text:  ESG claim sentence
            label: If given, explain this class. If None, explain predicted class.
            top_k: Number of top features to include.
        """
        X = self._fe.transform([text])  # (1, n_features)
        x = X[0]

        pred_encoded = self.clf.clf.predict(X)[0]
        probs = self.clf.clf.predict_proba(X)[0]
        predicted_label = self._classes[pred_encoded]

        target_class = label or predicted_label
        class_idx = self._classes.index(target_class)

        # SHAP = coef * (x - mean)
        coef = self._coef[class_idx]  # (n_features,)
        if self._feature_means is not None:
            baseline = self._feature_means
        else:
            baseline = np.zeros_like(x)

        shap_values = coef * (x - baseline)  # (n_features,)

        # Build attribution objects
        all_attributions = []
        feature_names = self._build_feature_names()

        for i, (name, shap_val, feat_val) in enumerate(
            zip(feature_names, shap_values, x)
        ):
            feat_type = self._get_feature_type(i)
            all_attributions.append(FeatureAttribution(
                feature_name=name,
                feature_value=float(feat_val),
                shap_value=float(shap_val),
                abs_shap=abs(float(shap_val)),
                direction=(
                    "increases_risk" if shap_val > 0.001
                    else "decreases_risk" if shap_val < -0.001
                    else "neutral"
                ),
                feature_type=feat_type,
            ))

        # Sort by |SHAP|
        sorted_attr = sorted(all_attributions, key=lambda a: -a.abs_shap)
        top_attributions = sorted_attr[:top_k]

        # Separate token vs ontology
        token_attr = [a for a in sorted_attr if a.feature_type == "tfidf_token"][:10]
        ont_attr   = [a for a in sorted_attr if a.feature_type in ("ontology", "keyword")][:8]

        # Base probability (class prior)
        class_counts = {c: 0 for c in self._classes}
        base_prob = 1.0 / len(self._classes)

        narrative, drivers = self._build_narrative(
            text, predicted_label, target_class,
            float(probs[class_idx]), top_attributions
        )

        return PredictionExplanation(
            claim_text=text,
            predicted_label=predicted_label,
            confidence=float(probs[pred_encoded]),
            base_probability=base_prob,
            top_attributions=top_attributions,
            token_attributions=token_attr,
            ontology_attributions=ont_attr,
            narrative=narrative,
            risk_drivers=drivers,
        )

    def explain_batch(
        self, texts: list[str], labels: Optional[list[str]] = None
    ) -> list[PredictionExplanation]:
        """Explain a batch of claims."""
        return [
            self.explain(text, label=(labels[i] if labels else None))
            for i, text in enumerate(texts)
        ]

    def _build_feature_names(self) -> list[str]:
        """Build full feature name list (TF-IDF tokens + dense features)."""
        tfidf_names = [f"token:{self._tfidf_vocab[i]}" for i in range(self._n_tfidf)]
        return tfidf_names + self.DENSE_FEATURE_NAMES

    def _get_feature_type(self, idx: int) -> str:
        if idx < self._n_tfidf:
            return "tfidf_token"
        dense_idx = idx - self._n_tfidf
        if dense_idx < 12:
            return "ontology"
        if dense_idx < 19:
            return "keyword"
        return "structural"

    def _build_narrative(
        self,
        text: str,
        predicted_label: str,
        target_class: str,
        confidence: float,
        top_attr: list[FeatureAttribution],
    ) -> tuple[str, list[str]]:
        """Generate a plain-English narrative for the top attributions."""

        # Identify the most influential drivers
        risk_drivers = []
        for attr in top_attr[:6]:
            if attr.abs_shap < 0.002:
                continue
            if attr.feature_type == "tfidf_token":
                token = attr.feature_name.replace("token:", "")
                if attr.direction == "increases_risk":
                    risk_drivers.append(
                        f'Presence of term "{token}" is associated with {target_class} claims'
                    )
            elif attr.feature_type == "ontology":
                name = attr.feature_name.replace("_", " ")
                if "vagueness_score" in attr.feature_name and attr.direction == "increases_risk":
                    risk_drivers.append(
                        "High vagueness score — claim uses ambiguous language without measurable targets"
                    )
                elif "has_quantified" in attr.feature_name and attr.direction == "decreases_risk":
                    risk_drivers.append(
                        "Presence of quantified target reduces greenwashing likelihood"
                    )
                elif "has_third_party" in attr.feature_name and attr.direction == "decreases_risk":
                    risk_drivers.append(
                        "Third-party verification cited reduces VAGUE/UNVERIFIED probability"
                    )
                elif "kw_verified" in attr.feature_name and attr.direction == "decreases_risk":
                    risk_drivers.append(
                        "Verified standards keywords (SBTi, ISO, assurance) present"
                    )
                elif "kw_commitment" in attr.feature_name and attr.direction == "increases_risk":
                    risk_drivers.append(
                        "Commitment/pledge language detected (high VAGUE signal)"
                    )

        if not risk_drivers:
            risk_drivers = [f"Claim classified as {predicted_label} with {confidence:.0%} confidence"]

        label_descriptions = {
            "VAGUE":       "uses ambiguous language with no measurable commitment",
            "UNVERIFIED":  "makes specific claims that cannot be cross-referenced to external data",
            "FACTUAL":     "contains specific, verifiable, time-bound assertions",
            "EXAGGERATED": "makes disproportionate claims relative to supporting evidence",
            "MISLEADING":  "is technically accurate but omits material context",
        }
        desc = label_descriptions.get(target_class, "")

        top_tokens = [
            a.feature_name.replace("token:", "")
            for a in top_attr if a.feature_type == "tfidf_token"
        ][:4]
        token_str = f' Key signal words: {", ".join(top_tokens)}.' if top_tokens else ""

        narrative = (
            f"The claim is classified as {predicted_label} ({confidence:.0%} confidence) "
            f"because it {desc}.{token_str} "
            f"The {len([a for a in top_attr if a.direction=='increases_risk'])} "
            f"features increasing greenwashing risk outweigh the "
            f"{len([a for a in top_attr if a.direction=='decreases_risk'])} "
            f"mitigating features."
        )
        return narrative, risk_drivers[:4]

    def feature_importance_global(
        self, texts: list[str], labels: list[str], top_k: int = 20
    ) -> pd.DataFrame:
        """
        Global feature importance across a dataset.
        Returns mean |SHAP| per feature, grouped by class.
        """
        X = self._fe.transform(texts)
        le = self.clf.label_encoder
        feature_names = self._build_feature_names()
        rows = []
        for class_idx, class_name in enumerate(self._classes):
            coef = self._coef[class_idx]
            baseline = self._feature_means if self._feature_means is not None else np.zeros(X.shape[1])
            shap_matrix = coef * (X - baseline)  # (n_samples, n_features)
            mean_abs_shap = np.abs(shap_matrix).mean(axis=0)
            for i, name in enumerate(feature_names):
                rows.append({
                    "class":         class_name,
                    "feature":       name,
                    "mean_abs_shap": float(mean_abs_shap[i]),
                    "feature_type":  self._get_feature_type(i),
                })
        df = pd.DataFrame(rows)
        # Return top-k per class
        return (
            df.sort_values("mean_abs_shap", ascending=False)
              .groupby("class")
              .head(top_k)
              .reset_index(drop=True)
        )
