"""
classification/greenwashing_classifier.py
──────────────────────────────────────────
Sprint 2 ML greenwashing classifier.

Architecture:
  • TF-IDF (3000 features, unigrams + bigrams, sublinear_tf) +
    ESG ontology scores + keyword flags + structural features
  → Logistic Regression (L2 regularisation, C=1.0, max_iter=1000)
  → Platt scaling calibration (CalibratedClassifierCV, cv=3)

This is the Sprint 2 baseline. Sprint 3 replaces with fine-tuned FinBERT.

Also includes:
  • SemanticIndex — cosine similarity index for claim deduplication and
    nearest-neighbour retrieval (replaces FAISS, which requires network download)
"""

from __future__ import annotations

import json
import pickle
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder

from src.classification.feature_engineering import ESGFeatureExtractor

LABELS = ["FACTUAL", "VAGUE", "EXAGGERATED", "UNVERIFIED", "MISLEADING"]


class GreenwashingClassifier:
    """
    5-class greenwashing claim classifier with probability calibration.

    Training:
        clf = GreenwashingClassifier()
        clf.fit(texts, labels)

    Inference:
        result = clf.predict_single("We are committed to a greener future.")
        # {"label": "VAGUE", "confidence": 0.83, "probabilities": {...}}
    """

    def __init__(self, C: float = 1.0, max_iter: int = 1000):
        self.C = C
        self.max_iter = max_iter
        self.feature_extractor = ESGFeatureExtractor(tfidf_max_features=3000)
        self.label_encoder = LabelEncoder()
        self._base_clf = LogisticRegression(
            C=C,
            max_iter=max_iter,
            solver="lbfgs",
            class_weight="balanced",   # handles class imbalance
            random_state=42,
        )
        self.clf = CalibratedClassifierCV(self._base_clf, cv=3, method="sigmoid")
        self._trained = False
        self.training_metrics: dict = {}

    # ── Training ──────────────────────────────────────────────────────────────

    def fit(self, texts: list[str], labels: list[str]) -> "GreenwashingClassifier":
        """Fit on full training set."""
        t0 = time.time()
        X = self.feature_extractor.fit_transform(texts)
        y = self.label_encoder.fit_transform(labels)
        self.clf.fit(X, y)
        self._trained = True
        self.training_metrics["fit_time_s"] = round(time.time() - t0, 3)
        self.training_metrics["n_train"] = len(texts)
        self.training_metrics["n_features"] = X.shape[1]
        self.training_metrics["classes"] = list(self.label_encoder.classes_)
        return self

    # ── Evaluation ────────────────────────────────────────────────────────────

    def evaluate(
        self,
        X_test_texts: list[str],
        y_test_labels: list[str],
    ) -> dict:
        """
        Full evaluation suite on a held-out test set.
        Returns dict with all metrics (stored as training_metrics["eval"]).
        """
        X_test = self.feature_extractor.transform(X_test_texts)
        y_true = self.label_encoder.transform(y_test_labels)
        y_pred = self.clf.predict(X_test)
        y_prob = self.clf.predict_proba(X_test)

        pred_labels = self.label_encoder.inverse_transform(y_pred)
        classes = list(self.label_encoder.classes_)

        report = classification_report(
            y_test_labels, pred_labels,
            labels=classes, output_dict=True, zero_division=0
        )

        f1_macro = f1_score(y_true, y_pred, average="macro", zero_division=0)
        f1_weighted = f1_score(y_true, y_pred, average="weighted", zero_division=0)
        kappa = cohen_kappa_score(y_true, y_pred)

        # Per-class AUC (one-vs-rest)
        auc_scores = {}
        for i, cls in enumerate(classes):
            binary_true = (y_true == i).astype(int)
            if binary_true.sum() > 0:
                auc_scores[cls] = round(
                    roc_auc_score(binary_true, y_prob[:, i]), 4
                )

        cm = confusion_matrix(y_true, y_pred).tolist()

        eval_metrics = {
            "n_test": len(y_test_labels),
            "f1_macro": round(f1_macro, 4),
            "f1_weighted": round(f1_weighted, 4),
            "cohen_kappa": round(kappa, 4),
            "auc_per_class": auc_scores,
            "per_class_report": {
                cls: {
                    "precision": round(report[cls]["precision"], 4),
                    "recall": round(report[cls]["recall"], 4),
                    "f1": round(report[cls]["f1-score"], 4),
                    "support": int(report[cls]["support"]),
                }
                for cls in classes if cls in report
            },
            "confusion_matrix": cm,
            "class_order": classes,
        }
        self.training_metrics["eval"] = eval_metrics
        return eval_metrics

    def cross_validate(self, texts: list[str], labels: list[str], cv: int = 5) -> dict:
        """Stratified k-fold cross-validation on the full dataset."""
        X = self.feature_extractor.fit_transform(texts)
        y = self.label_encoder.fit_transform(labels)
        self._trained = True

        skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
        scores = cross_val_score(self.clf, X, y, cv=skf, scoring="f1_macro", n_jobs=-1)

        cv_results = {
            "cv_folds": cv,
            "f1_macro_scores": [round(s, 4) for s in scores],
            "f1_macro_mean": round(scores.mean(), 4),
            "f1_macro_std": round(scores.std(), 4),
        }
        self.training_metrics["cross_validation"] = cv_results
        return cv_results

    # ── Inference ─────────────────────────────────────────────────────────────

    def predict_single(self, text: str) -> dict:
        """Predict label + calibrated probabilities for one claim."""
        if not self._trained:
            raise RuntimeError("Model not trained. Call fit() first.")
        X = self.feature_extractor.transform([text])
        pred_encoded = self.clf.predict(X)[0]
        probs = self.clf.predict_proba(X)[0]
        label = self.label_encoder.inverse_transform([pred_encoded])[0]
        classes = list(self.label_encoder.classes_)
        return {
            "label": label,
            "confidence": round(float(probs.max()), 4),
            "probabilities": {cls: round(float(p), 4) for cls, p in zip(classes, probs)},
        }

    def predict_batch(self, texts: list[str]) -> list[dict]:
        """Predict labels for a list of texts."""
        if not self._trained:
            raise RuntimeError("Model not trained.")
        X = self.feature_extractor.transform(texts)
        preds = self.clf.predict(X)
        probs_matrix = self.clf.predict_proba(X)
        classes = list(self.label_encoder.classes_)
        results = []
        for pred, probs in zip(preds, probs_matrix):
            label = self.label_encoder.inverse_transform([pred])[0]
            results.append({
                "label": label,
                "confidence": round(float(probs.max()), 4),
                "probabilities": {cls: round(float(p), 4) for cls, p in zip(classes, probs)},
            })
        return results

    # ── Persistence ───────────────────────────────────────────────────────────

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, path: Path) -> "GreenwashingClassifier":
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_metrics(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.training_metrics, f, indent=2)


# ══════════════════════════════════════════════════════════════════════════════
# Semantic Similarity Index (cosine-based, replaces FAISS for Sprint 2)
# ══════════════════════════════════════════════════════════════════════════════

class SemanticIndex:
    """
    TF-IDF cosine similarity index for:
      1. Claim deduplication (identify near-duplicates before annotation)
      2. Nearest-neighbour retrieval (find similar claims for consistency checks)

    Sprint 3 will replace TF-IDF vectors with sentence-transformer embeddings
    (all-MiniLM-L6-v2) and FAISS ANN for scale.
    """

    def __init__(self, max_features: int = 5000):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=(1, 2),
            sublinear_tf=True,
        )
        self._index_texts: list[str] = []
        self._index_labels: list[str] = []
        self._index_matrix: np.ndarray | None = None
        self._fitted = False

    def build(self, texts: list[str], labels: list[str]) -> "SemanticIndex":
        """Build index from a list of (text, label) pairs."""
        self._index_texts = texts
        self._index_labels = labels
        self._index_matrix = self.vectorizer.fit_transform(texts).toarray()
        self._fitted = True
        return self

    def find_similar(
        self,
        query: str,
        top_k: int = 5,
        threshold: float = 0.3,
    ) -> list[dict]:
        """Return top-k most similar indexed claims."""
        if not self._fitted:
            raise RuntimeError("Call build() first.")
        q_vec = self.vectorizer.transform([query]).toarray()
        sims = cosine_similarity(q_vec, self._index_matrix)[0]
        top_indices = sims.argsort()[::-1][:top_k]
        results = []
        for idx in top_indices:
            if sims[idx] >= threshold:
                results.append({
                    "text": self._index_texts[idx],
                    "label": self._index_labels[idx],
                    "similarity": round(float(sims[idx]), 4),
                    "rank": len(results) + 1,
                })
        return results

    def find_duplicates(self, threshold: float = 0.85) -> list[tuple[int, int, float]]:
        """Identify near-duplicate claim pairs (similarity >= threshold)."""
        if not self._fitted:
            raise RuntimeError("Call build() first.")
        sim_matrix = cosine_similarity(self._index_matrix)
        np.fill_diagonal(sim_matrix, 0)
        pairs = []
        seen = set()
        rows, cols = np.where(sim_matrix >= threshold)
        for r, c in zip(rows, cols):
            key = tuple(sorted((r, c)))
            if key not in seen:
                seen.add(key)
                pairs.append((int(r), int(c), round(float(sim_matrix[r, c]), 4)))
        return sorted(pairs, key=lambda x: -x[2])

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, path: Path) -> "SemanticIndex":
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_index_stats(self, path: Path) -> None:
        stats = {
            "n_indexed_claims": len(self._index_texts),
            "vocabulary_size": len(self.vectorizer.vocabulary_),
            "label_distribution": {
                lbl: self._index_labels.count(lbl)
                for lbl in set(self._index_labels)
            },
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(stats, f, indent=2)
