"""
classification/feature_engineering.py
──────────────────────────────────────
Builds the feature matrix for the greenwashing classifier.

Feature groups (Sprint 2):
  Group A — TF-IDF bag-of-words (bigrams, 3000 features)
  Group B — ESG ontology heuristic scores (vagueness, specificity, binary flags)
  Group C — Structural features (word count, sentence length, punctuation)
  Group D — ESG keyword presence (sector-specific term flags)

Total: ~3012 features. Sprint 3 will add contextual BERT embeddings.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import pickle

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from src.schema.esg_ontology import ESGOntology


# ── ESG keyword group flags ────────────────────────────────────────────────────
KEYWORD_GROUPS = {
    "kw_commitment_language": [
        "committed", "commitment", "pledge", "promise", "strive", "striving",
        "working towards", "aim to", "aiming", "aspire", "aspiring",
    ],
    "kw_vague_temporal": [
        "near term", "in due course", "going forward", "over time",
        "in the coming years", "eventually", "progressively",
    ],
    "kw_verified_standards": [
        "sbti", "science based target", "tcfd", "gri", "sasb", "iso 14064",
        "iso 50001", "aa1000", "limited assurance", "reasonable assurance",
        "independently verified", "externally assured", "third-party",
        "bureau veritas", "kpmg", "pwc", "ey ", "deloitte", "dnv", "sgs",
    ],
    "kw_quantified": [
        "tco2e", "kgco2", "mtco2", "scope 1", "scope 2", "scope 3",
        "percent", "%", "million", "billion", "tonnes", "kwh", "mwh",
        "m3", "ltifr", "frequency rate",
    ],
    "kw_selective_disclosure": [
        "direct operations", "own operations", "headquarters",
        "not include", "exclud", "scope 3 not", "remainder",
        "primarily", "driven by closure", "driven by divestment",
    ],
    "kw_awards_best_in_class": [
        "leader", "pioneer", "first", "best-in-class", "most sustainable",
        "greenest", "award", "recognised", "ranked number one",
        "industry leading",
    ],
    "kw_offset_heavy": [
        "carbon offset", "offset programme", "carbon neutral",
        "net zero today", "fully offset", "offset all",
        "carbon negative", "carbon positive", "net positive",
    ],
    "kw_superlative": [
        "global leader", "market leader", "undisputed", "most sustainable",
        "best-in-class", "first company", "first in history", "only company",
        "most ambitious", "most comprehensive", "fastest", "boldest",
        "definitive", "unmatched", "gold standard", "pioneering",
        "world\'s first", "industry-leading", "unrivalled",
    ],
}


def extract_keyword_features(text: str) -> dict[str, float]:
    """Binary flags for each keyword group (1.0 if any keyword matches)."""
    lower = text.lower()
    return {
        group: float(any(kw in lower for kw in kws))
        for group, kws in KEYWORD_GROUPS.items()
    }


def extract_structural_features(text: str) -> dict[str, float]:
    """Sentence-level structural features."""
    words = text.split()
    sentences = re.split(r"[.!?]+", text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 3]

    return {
        "word_count": len(words),
        "char_count": len(text),
        "avg_word_length": np.mean([len(w) for w in words]) if words else 0.0,
        "num_sentences": len(sentences),
        "avg_sentence_length": np.mean([len(s.split()) for s in sentences]) if sentences else 0.0,
        "num_numbers": len(re.findall(r"\b\d+(?:\.\d+)?(?:%|m|bn|k)?\b", text)),
        "has_percentage": float(bool(re.search(r"\d+(?:\.\d+)?\s*%", text))),
        "has_year": float(bool(re.search(r"\b20[2-9]\d\b", text))),
        "has_dollar_amount": float(bool(re.search(r"\$[\d,.]+\s*(?:m|bn|billion|million)?", text, re.I))),
        "exclamation_count": text.count("!"),
        "uppercase_ratio": sum(1 for c in text if c.isupper()) / max(len(text), 1),
        "parenthetical_count": text.count("("),
        "semicolon_count": text.count(";"),
    }


class ESGFeatureExtractor:
    """
    Builds the full feature matrix for a list of ESG claim texts.

    Feature matrix layout:
      [0:3000]   TF-IDF (unigrams + bigrams)
      [3000:3012] Ontology scores (vagueness, specificity, flags)
      [3012:3019] Keyword group flags (7 groups)
      [3019:3032] Structural features (13 features)
    """

    def __init__(
        self,
        tfidf_max_features: int = 3000,
        tfidf_ngram_range: tuple = (1, 2),
    ):
        self.ontology = ESGOntology()
        self.tfidf = TfidfVectorizer(
            max_features=tfidf_max_features,
            ngram_range=tfidf_ngram_range,
            sublinear_tf=True,
            min_df=2,
            strip_accents="unicode",
            token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z0-9+\-\.]*\b",
        )
        self.scaler = StandardScaler()
        self._fitted = False

    def fit(self, texts: list[str]) -> "ESGFeatureExtractor":
        """Fit TF-IDF and scaler on training texts."""
        self.tfidf.fit(texts)
        # Fit scaler on combined feature matrix
        dense = self._build_dense(texts)
        self.scaler.fit(dense)
        self._fitted = True
        return self

    def transform(self, texts: list[str]) -> np.ndarray:
        """Transform texts to feature matrix (n_samples x n_features)."""
        if not self._fitted:
            raise RuntimeError("Call fit() before transform()")
        tfidf_mat = self.tfidf.transform(texts).toarray()
        dense_mat = self._build_dense(texts)
        dense_scaled = self.scaler.transform(dense_mat)
        return np.hstack([tfidf_mat, dense_scaled])

    def fit_transform(self, texts: list[str]) -> np.ndarray:
        """Fit then transform in one step."""
        self.tfidf.fit(texts)
        dense = self._build_dense(texts)
        self.scaler.fit(dense)
        self._fitted = True
        tfidf_mat = self.tfidf.transform(texts).toarray()
        dense_scaled = self.scaler.transform(dense)
        return np.hstack([tfidf_mat, dense_scaled])

    def _build_dense(self, texts: list[str]) -> np.ndarray:
        """Build dense feature block (ontology + keywords + structural)."""
        rows = []
        for text in texts:
            ont = self.ontology.analyse(text)
            kw = extract_keyword_features(text)
            struct = extract_structural_features(text)

            row = [
                # Ontology (12 features)
                ont["vagueness_score"],
                ont["specificity_score"],
                float(ont["has_quantified_target"]),
                float(ont["has_temporal_target"]),
                float(ont["has_third_party_verification"]),
                ont["label_confidence"],
                float(ont["vagueness_signal"] == "high"),
                float(ont["vagueness_signal"] == "medium"),
                float(ont["vagueness_signal"] == "low"),
                float(ont["vagueness_signal"] == "none"),
                float(ont["pillar"] == "E"),
                float(ont["pillar"] == "S"),
                # Keyword groups (7 features)
                *kw.values(),
                # Structural (13 features)
                *struct.values(),
            ]
            rows.append(row)
        return np.array(rows, dtype=np.float64)

    @property
    def n_features(self) -> int:
        if not self._fitted:
            return -1
        return self.tfidf.max_features + 32  # approx dense features

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, path: Path) -> "ESGFeatureExtractor":
        with open(path, "rb") as f:
            return pickle.load(f)
