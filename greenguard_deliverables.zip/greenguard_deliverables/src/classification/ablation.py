"""
classification/ablation.py
───────────────────────────
Ablation study: measures the contribution of each feature group
to classification performance.

Ablations run:
  A) Full feature set (baseline)
  B) TF-IDF only (no ESG features)
  C) ESG ontology only (no TF-IDF)
  D) No keyword features
  E) No structural features
  F) Balanced vs imbalanced class weights

Results quantify the marginal value of the ESG-specific feature engineering.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold, cross_val_score

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from src.classification.feature_engineering import (
    ESGFeatureExtractor,
    extract_keyword_features,
    extract_structural_features,
)
from src.schema.esg_ontology import ESGOntology


def _make_clf(C: float = 1.0, balanced: bool = True) -> CalibratedClassifierCV:
    base = LogisticRegression(
        C=C, max_iter=1000, solver="lbfgs",
        class_weight="balanced" if balanced else None, random_state=42
    )
    return CalibratedClassifierCV(base, cv=3, method="sigmoid")


def run_ablation(texts: list[str], labels: list[str], cv: int = 5) -> pd.DataFrame:
    """
    Run full ablation study. Returns a DataFrame with one row per ablation variant.
    """
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.preprocessing import LabelEncoder, StandardScaler

    le = LabelEncoder()
    y = le.fit_transform(labels)
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)

    def score(X: np.ndarray, name: str, balanced: bool = True) -> dict:
        clf = _make_clf(balanced=balanced)
        t0 = time.time()
        scores = cross_val_score(clf, X, y, cv=skf, scoring="f1_macro", n_jobs=-1)
        return {
            "ablation": name,
            "f1_macro_mean": round(scores.mean(), 4),
            "f1_macro_std": round(scores.std(), 4),
            "runtime_s": round(time.time() - t0, 2),
        }

    ontology = ESGOntology()

    # Pre-build feature blocks
    tfidf = TfidfVectorizer(max_features=3000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    X_tfidf = tfidf.fit_transform(texts).toarray()

    ont_rows, kw_rows, struct_rows = [], [], []
    for t in texts:
        ont = ontology.analyse(t)
        ont_rows.append([
            ont["vagueness_score"], ont["specificity_score"],
            float(ont["has_quantified_target"]), float(ont["has_temporal_target"]),
            float(ont["has_third_party_verification"]), ont["label_confidence"],
            float(ont["vagueness_signal"] == "high"), float(ont["vagueness_signal"] == "medium"),
            float(ont["vagueness_signal"] == "low"), float(ont["vagueness_signal"] == "none"),
            float(ont["pillar"] == "E"), float(ont["pillar"] == "S"),
        ])
        kw_rows.append(list(extract_keyword_features(t).values()))
        struct_rows.append(list(extract_structural_features(t).values()))

    X_ont = StandardScaler().fit_transform(np.array(ont_rows))
    X_kw = np.array(kw_rows)
    X_struct = StandardScaler().fit_transform(np.array(struct_rows))
    X_dense = np.hstack([X_ont, X_kw, X_struct])
    X_full = np.hstack([X_tfidf, X_dense])

    results = [
        score(X_full,                              "A: Full feature set (TF-IDF + ESG + KW + Struct)"),
        score(X_tfidf,                             "B: TF-IDF only"),
        score(X_ont,                               "C: ESG ontology features only"),
        score(np.hstack([X_tfidf, X_ont]),         "D: TF-IDF + Ontology (no KW, no Struct)"),
        score(np.hstack([X_tfidf, X_ont, X_kw]),   "E: No structural features"),
        score(np.hstack([X_tfidf, X_ont, X_struct]),"F: No keyword group features"),
        score(X_full,                              "G: Full features, no class balancing", balanced=False),
    ]

    df = pd.DataFrame(results)
    df["delta_vs_tfidf_only"] = (df["f1_macro_mean"] - df.loc[df["ablation"].str.startswith("B"), "f1_macro_mean"].values[0]).round(4)
    return df
