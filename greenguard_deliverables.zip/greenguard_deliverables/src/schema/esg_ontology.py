"""
schema/esg_ontology.py
──────────────────────
Defines the ESG claim ontology used throughout the pipeline.

The ontology covers:
  • ESG pillar taxonomy (E, S, G sub-categories)
  • Claim type taxonomy (factual / vague / exaggerated / unverified / misleading)
  • Linguistic vagueness patterns (regex-based heuristics for Sprint 1)
  • Data schema for the annotated claims corpus (Pandas-compatible)

Usage:
    from src.schema.esg_ontology import ESGOntology, ClaimRecord, GreenwashingLabel

    ontology = ESGOntology()
    label = ontology.classify_vagueness("We are committed to a greener future.")
    print(label)  # VaguenessSignal.HIGH
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional
import pandas as pd


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  TAXONOMIES
# ═══════════════════════════════════════════════════════════════════════════════

class ESGPillar(str, Enum):
    ENVIRONMENTAL = "E"
    SOCIAL = "S"
    GOVERNANCE = "G"
    CROSS_PILLAR = "X"     # Claims spanning multiple pillars


class EnvironmentalSubCategory(str, Enum):
    CLIMATE_CHANGE = "climate_change"
    CARBON_EMISSIONS = "carbon_emissions"
    ENERGY_USE = "energy_use"
    RENEWABLE_ENERGY = "renewable_energy"
    WATER_MANAGEMENT = "water_management"
    WASTE_MANAGEMENT = "waste_management"
    BIODIVERSITY = "biodiversity"
    SUPPLY_CHAIN_ENV = "supply_chain_env"
    CIRCULAR_ECONOMY = "circular_economy"


class SocialSubCategory(str, Enum):
    LABOUR_STANDARDS = "labour_standards"
    HUMAN_RIGHTS = "human_rights"
    COMMUNITY_IMPACT = "community_impact"
    DIVERSITY_INCLUSION = "diversity_inclusion"
    HEALTH_SAFETY = "health_safety"
    DATA_PRIVACY = "data_privacy"
    SUPPLY_CHAIN_SOC = "supply_chain_soc"


class GovernanceSubCategory(str, Enum):
    BOARD_COMPOSITION = "board_composition"
    EXECUTIVE_PAY = "executive_pay"
    ANTI_CORRUPTION = "anti_corruption"
    TRANSPARENCY = "transparency"
    RISK_MANAGEMENT = "risk_management"
    SHAREHOLDER_RIGHTS = "shareholder_rights"


class GreenwashingLabel(str, Enum):
    FACTUAL = "FACTUAL"           # Specific, quantified, verifiable
    VAGUE = "VAGUE"               # Generic language, no measurable target
    EXAGGERATED = "EXAGGERATED"   # Disproportionate relative to evidence
    UNVERIFIED = "UNVERIFIED"     # Cannot be cross-referenced to external data
    MISLEADING = "MISLEADING"     # Technically true but contextually deceptive


class VaguenessSignal(str, Enum):
    NONE = "none"        # Clear, specific language
    LOW = "low"          # Minor hedging detected
    MEDIUM = "medium"    # Significant vagueness
    HIGH = "high"        # Strong greenwashing language pattern


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  LINGUISTIC PATTERNS  (Sprint 1 rule-based baseline)
# ═══════════════════════════════════════════════════════════════════════════════

# High-signal vagueness terms identified from academic greenwashing literature
# (Lyon & Montgomery 2015; Bowen 2014; Marquis et al. 2016)
VAGUE_PATTERNS: dict[VaguenessSignal, list[str]] = {
    VaguenessSignal.HIGH: [
        r"\bcommitt?ed to\b",
        r"\bstriving\s+(?:to|towards?)\b",
        r"\bwork(?:ing)?\s+towards?\b",
        r"\bgreener\s+(?:future|tomorrow|world|planet)\b",
        r"\bsustainable\s+(?:future|tomorrow|growth|world)\b",
        r"\bresponsible\s+(?:steward|company|corporate)\b",
        r"\bas\s+(?:much|little)\s+as\s+possible\b",
        r"\bminimis(?:e|ing|ed)\s+(?:our|its)\s+(?:impact|footprint|effect)\b",
        r"\beco[\-\s]?friendly\b",
        r"\benvironmentally\s+(?:conscious|aware|responsible)\b",
        r"\bcarbon[\-\s]?neutral\b(?!\s+by\s+\d{4})",  # "carbon neutral" with no date = vague
        r"\bnet[\-\s]?zero\b(?!\s+by\s+\d{4})",        # "net zero" with no date = vague
        r"\bgreen\s+(?:initiatives?|efforts?|programs?)\b",
    ],
    VaguenessSignal.MEDIUM: [
        r"\baim(?:s|ing)?\s+to\b",
        r"\bgoal\s+(?:is|to)\b",
        r"\btarget(?:ing)?\s+(?:to|a)\b",
        r"\bplan(?:ning|s)?\s+to\b",
        r"\bwe\s+believe\b",
        r"\bour\s+(?:commitment|pledge|promise)\b",
        r"\bsignificant(?:ly)?\s+(?:reduc|improv)\w+\b",
        r"\bsubstantial(?:ly)?\s+(?:reduc|improv)\w+\b",
        r"\b(?:fully|deeply|truly)\s+committed\b",
        r"\bpassionate\s+about\b",
        r"\bprioritiz\w+\b",
    ],
    VaguenessSignal.LOW: [
        r"\binitiativ\w+\b",
        r"\beffort\w+\b",
        r"\bprogress\w+\b",
        r"\bstep\w+\s+(?:toward|in)\b",
        r"\bjourney\b",
    ],
}

# Specificity markers that REDUCE vagueness score
SPECIFICITY_PATTERNS: list[str] = [
    r"\b\d{1,3}(?:,\d{3})*(?:\.\d+)?\s*(?:metric\s+)?(?:ton(?:ne)?s?|tco2e?|ktco2|mtco2)\b",
    r"\b\d+(?:\.\d+)?\s*%\s*(?:reduc|decreas|lower|cut|declin)\w+\b",
    r"\bby\s+(?:20[2-9]\d|2[1-9]\d{2})\b",                  # "by 2030", "by 2050" etc.
    r"\b(?:20[2-9]\d)\s+(?:baseline|base\s+year)\b",
    r"\b(?:science[\-\s]?based\s+target|SBTi)\b",
    r"\bISO\s+\d{4,5}\b",
    r"\bGRI\s+\d{3}[\-:]\d+\b",
    r"\bTCFD[\-\s]?aligned\b",
    r"\bthird[\-\s]?party\s+(?:verified|audited|certified)\b",
    r"\bpeer[\-\s]?reviewed\b",
]


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  CLAIM RECORD SCHEMA
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ClaimRecord:
    """
    Atomic unit of the annotated corpus.
    One ClaimRecord = one ESG claim sentence extracted from a source document.
    """
    # Identity
    claim_id: str                          # UUID
    source_doc_id: str                     # Parent document ID
    source_url: str                        # Original URL / file path
    company_ticker: str                    # Stock ticker or "UNKNOWN"
    company_name: str
    report_year: int
    report_type: str                       # "10-K", "sustainability_report", "proxy", etc.

    # Content
    raw_text: str                          # Original claim sentence
    normalised_text: str                   # After cleaning & normalisation
    section_title: str                     # Section heading context
    page_number: Optional[int] = None

    # ESG Classification
    pillar: ESGPillar = ESGPillar.ENVIRONMENTAL
    sub_category: str = ""                 # ESG sub-category string

    # Annotation (populated later)
    label: Optional[GreenwashingLabel] = None
    label_confidence: float = 0.0
    vagueness_signal: VaguenessSignal = VaguenessSignal.NONE
    has_quantified_target: bool = False
    has_temporal_target: bool = False
    has_third_party_verification: bool = False

    # Heuristic scores (Sprint 1 rule-based)
    vagueness_score: float = 0.0           # 0.0–1.0
    specificity_score: float = 0.0        # 0.0–1.0

    # Metadata
    annotator_id: str = ""
    annotation_timestamp: str = ""
    notes: str = ""

    def to_dict(self) -> dict:
        return {
            "claim_id": self.claim_id,
            "source_doc_id": self.source_doc_id,
            "source_url": self.source_url,
            "company_ticker": self.company_ticker,
            "company_name": self.company_name,
            "report_year": self.report_year,
            "report_type": self.report_type,
            "raw_text": self.raw_text,
            "normalised_text": self.normalised_text,
            "section_title": self.section_title,
            "page_number": self.page_number,
            "pillar": self.pillar.value,
            "sub_category": self.sub_category,
            "label": self.label.value if self.label else None,
            "label_confidence": self.label_confidence,
            "vagueness_signal": self.vagueness_signal.value,
            "has_quantified_target": self.has_quantified_target,
            "has_temporal_target": self.has_temporal_target,
            "has_third_party_verification": self.has_third_party_verification,
            "vagueness_score": self.vagueness_score,
            "specificity_score": self.specificity_score,
            "annotator_id": self.annotator_id,
            "annotation_timestamp": self.annotation_timestamp,
            "notes": self.notes,
        }

    @classmethod
    def schema_as_dataframe(cls) -> pd.DataFrame:
        """Return empty DataFrame with correct column types for schema reference."""
        return pd.DataFrame(columns=list(cls.__dataclass_fields__.keys()))


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  ONTOLOGY ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class ESGOntology:
    """
    Rule-based ESG claim analyser for Sprint 1.
    Provides:
      • Vagueness scoring (0.0–1.0)
      • Specificity scoring (0.0–1.0)
      • ESG pillar classification via keyword matching
      • Sub-category tagging
    """

    # Keyword lookup tables for pillar classification
    PILLAR_KEYWORDS: dict[ESGPillar, list[str]] = {
        ESGPillar.ENVIRONMENTAL: [
            "carbon", "emission", "climate", "greenhouse", "co2", "ghg",
            "energy", "renewable", "solar", "wind", "fossil", "biodiversity",
            "deforestation", "water", "waste", "recycle", "sustainable",
            "net zero", "carbon neutral", "scope 1", "scope 2", "scope 3",
            "tcfd", "gri 300", "paris agreement", "1.5 degree",
        ],
        ESGPillar.SOCIAL: [
            "workforce", "employee", "worker", "labour", "labor", "safety",
            "health", "diversity", "inclusion", "gender", "human rights",
            "supply chain", "community", "indigenous", "living wage",
            "modern slavery", "gri 400", "sa8000",
        ],
        ESGPillar.GOVERNANCE: [
            "board", "director", "executive", "ceo", "compensation",
            "audit", "compliance", "anti-corruption", "bribery", "lobbying",
            "transparency", "disclosure", "shareholder", "gri 200",
            "sox", "whistleblower", "risk management",
        ],
    }

    SUB_CATEGORY_KEYWORDS: dict[str, list[str]] = {
        "carbon_emissions": ["emission", "ghg", "co2", "scope 1", "scope 2", "scope 3", "tco2e"],
        "renewable_energy": ["solar", "wind", "renewable", "clean energy", "green power"],
        "water_management": ["water", "wastewater", "freshwater", "water stress"],
        "waste_management": ["waste", "recycle", "landfill", "circular", "packaging"],
        "biodiversity": ["biodiversity", "ecosystem", "species", "deforestation", "land use"],
        "climate_change": ["climate", "net zero", "paris", "1.5", "tcfd", "physical risk"],
        "energy_use": ["energy consumption", "energy intensity", "kwh", "mwh"],
        "labour_standards": ["worker", "labour", "labor", "wage", "overtime", "ilo"],
        "diversity_inclusion": ["diversity", "inclusion", "gender pay", "representation"],
        "health_safety": ["safety", "injury", "fatality", "ltifr", "health"],
        "human_rights": ["human rights", "modern slavery", "child labour", "forced labour"],
        "board_composition": ["board", "director", "independent", "committee"],
        "anti_corruption": ["corruption", "bribery", "anti-bribery", "fcpa"],
        "transparency": ["disclosure", "transparency", "reporting", "gri", "sasb"],
    }

    def __init__(self) -> None:
        # Pre-compile all patterns for performance
        self._vague_compiled: dict[VaguenessSignal, list[re.Pattern]] = {
            level: [re.compile(p, re.IGNORECASE) for p in patterns]
            for level, patterns in VAGUE_PATTERNS.items()
        }
        self._specific_compiled: list[re.Pattern] = [
            re.compile(p, re.IGNORECASE) for p in SPECIFICITY_PATTERNS
        ]

    # ── Vagueness ────────────────────────────────────────────────────────────

    def get_vagueness_signal(self, text: str) -> VaguenessSignal:
        """Return the strongest vagueness signal found in text."""
        for level in (VaguenessSignal.HIGH, VaguenessSignal.MEDIUM, VaguenessSignal.LOW):
            if any(p.search(text) for p in self._vague_compiled[level]):
                return level
        return VaguenessSignal.NONE

    def compute_vagueness_score(self, text: str) -> float:
        """
        0.0 = fully specific, 1.0 = maximally vague.
        Weighted: HIGH=1.0, MEDIUM=0.6, LOW=0.3 per match, capped at 1.0.
        Specificity markers subtract from the raw score.
        """
        weights = {
            VaguenessSignal.HIGH: 1.0,
            VaguenessSignal.MEDIUM: 0.6,
            VaguenessSignal.LOW: 0.3,
        }
        raw = 0.0
        for level, patterns in self._vague_compiled.items():
            hits = sum(1 for p in patterns if p.search(text))
            raw += hits * weights[level]

        specificity_hits = sum(1 for p in self._specific_compiled if p.search(text))
        adjusted = raw - (specificity_hits * 0.5)
        return min(max(adjusted, 0.0), 1.0)

    def compute_specificity_score(self, text: str) -> float:
        """0.0 = no specificity markers, 1.0 = highly specific."""
        hits = sum(1 for p in self._specific_compiled if p.search(text))
        return min(hits * 0.25, 1.0)

    # ── Binary flags ─────────────────────────────────────────────────────────

    def has_quantified_target(self, text: str) -> bool:
        """True if text contains a numerical target (%, absolute value)."""
        return bool(re.search(
            r"\b\d+(?:\.\d+)?\s*(?:%|percent|ton(?:ne)?s?|tco2|kwh|mwh|m3)\b",
            text, re.IGNORECASE
        ))

    def has_temporal_target(self, text: str) -> bool:
        """True if text references a target year."""
        return bool(re.search(r"\bby\s+20[2-9]\d\b|\b20[2-9]\d\s+target\b", text, re.IGNORECASE))

    def has_third_party_verification(self, text: str) -> bool:
        """True if text mentions external verification."""
        return bool(re.search(
            r"\b(?:third[\-\s]?party|independent(?:ly)?|externally?\s+(?:verified|audited|assured)"
            r"|limited\s+assurance|reasonable\s+assurance|ISO\s+\d{4,5}|SBTi[\-\s]?validated)\b",
            text, re.IGNORECASE
        ))

    # ── Classification ───────────────────────────────────────────────────────

    def classify_pillar(self, text: str) -> ESGPillar:
        """Classify text into E/S/G pillar by keyword frequency."""
        lower = text.lower()
        scores: dict[ESGPillar, int] = {pillar: 0 for pillar in ESGPillar}
        for pillar, keywords in self.PILLAR_KEYWORDS.items():
            scores[pillar] = sum(1 for kw in keywords if kw in lower)

        best = max((p for p in [ESGPillar.ENVIRONMENTAL, ESGPillar.SOCIAL, ESGPillar.GOVERNANCE]),
                   key=lambda p: scores[p])
        if scores[best] == 0:
            return ESGPillar.ENVIRONMENTAL  # default to E for ambiguous
        return best

    def classify_sub_category(self, text: str) -> str:
        """Return the best-matching sub-category or 'other'."""
        lower = text.lower()
        best_cat, best_count = "other", 0
        for cat, keywords in self.SUB_CATEGORY_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in lower)
            if count > best_count:
                best_count, best_cat = count, cat
        return best_cat

    def heuristic_label(self, text: str) -> tuple[GreenwashingLabel, float]:
        """
        Sprint 1 rule-based label assignment.
        Returns (label, confidence).
        NOTE: This is a heuristic baseline — ML model (Sprint 3) will supersede it.
        """
        vscore = self.compute_vagueness_score(text)
        sscore = self.compute_specificity_score(text)
        has_q = self.has_quantified_target(text)
        has_t = self.has_temporal_target(text)
        has_v = self.has_third_party_verification(text)

        if sscore >= 0.5 and has_q and has_t and has_v:
            return GreenwashingLabel.FACTUAL, 0.85

        if sscore >= 0.25 and has_q and has_t:
            return GreenwashingLabel.FACTUAL, 0.70

        if vscore >= 0.8:
            return GreenwashingLabel.VAGUE, 0.80

        if vscore >= 0.5 and not has_q:
            return GreenwashingLabel.VAGUE, 0.65

        if vscore >= 0.3 and has_q and not has_t:
            return GreenwashingLabel.UNVERIFIED, 0.60

        # Default: unverified if insufficient specificity
        confidence = max(0.40, 0.5 - vscore * 0.2 + sscore * 0.3)
        return GreenwashingLabel.UNVERIFIED, round(confidence, 3)

    def analyse(self, text: str) -> dict:
        """Run full heuristic analysis on a single claim text. Returns a dict."""
        label, confidence = self.heuristic_label(text)
        return {
            "vagueness_score": round(self.compute_vagueness_score(text), 4),
            "specificity_score": round(self.compute_specificity_score(text), 4),
            "vagueness_signal": self.get_vagueness_signal(text).value,
            "has_quantified_target": self.has_quantified_target(text),
            "has_temporal_target": self.has_temporal_target(text),
            "has_third_party_verification": self.has_third_party_verification(text),
            "pillar": self.classify_pillar(text).value,
            "sub_category": self.classify_sub_category(text),
            "label": label.value,
            "label_confidence": confidence,
        }


if __name__ == "__main__":
    # Quick smoke test
    ontology = ESGOntology()
    samples = [
        "We are deeply committed to a greener future and strive to minimize our environmental impact.",
        "We reduced Scope 1 and Scope 2 GHG emissions by 42% against a 2019 baseline, "
        "independently verified by Bureau Veritas to a limited assurance standard.",
        "By 2030, we target a 50% absolute reduction in Scope 1+2 emissions versus 2020, "
        "aligned with a 1.5°C science-based pathway validated by SBTi.",
        "Our sustainability initiatives continue to drive progress across our operations.",
    ]
    for s in samples:
        result = ontology.analyse(s)
        print(f"\n[{result['label']} | conf={result['label_confidence']:.2f} | "
              f"vague={result['vagueness_score']:.2f}]")
        print(f"  {s[:90]}{'...' if len(s) > 90 else ''}")
