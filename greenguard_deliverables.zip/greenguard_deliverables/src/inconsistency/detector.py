"""
inconsistency/detector.py
──────────────────────────
Contradiction detection and inconsistency scoring engine.

Detects four categories of inconsistency:

  1. NUMERIC_MISMATCH   — claim value diverges from external verified data by > threshold
  2. TEMPORAL_ANOMALY   — year-over-year delta is implausibly large or direction is wrong
  3. SCOPE_OMISSION     — Scope 1+2 claimed but Scope 3 is disproportionately larger and unmentioned
  4. VERIFICATION_GAP   — claim lacks third-party verification when equivalent claims from
                          the same company in other disclosures are verified

Each inconsistency is tagged with a severity: LOW / MEDIUM / CRITICAL.

The engine outputs:
  • InconsistencyFlag per detected issue
  • InconsistencyReport aggregating all flags for one company/report
  • Composite GRS (Greenwashing Risk Score) 0–100
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from src.connectors.external_data import ExternalDataPoint, ExternalDataRegistry
from src.inconsistency.alignment import AlignmentResult, ClaimAligner


# ── Severity enum ──────────────────────────────────────────────────────────────

class Severity(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    CRITICAL = "CRITICAL"


SEVERITY_WEIGHTS = {
    Severity.LOW:      1.0,
    Severity.MEDIUM:   3.0,
    Severity.CRITICAL: 8.0,
}


# ── Inconsistency flag ─────────────────────────────────────────────────────────

@dataclass
class InconsistencyFlag:
    flag_id:          str
    company_ticker:   str
    inconsistency_type: str       # "NUMERIC_MISMATCH" | "TEMPORAL_ANOMALY" | etc.
    severity:         Severity
    claim_text:       str
    claim_value:      Optional[float]
    external_value:   Optional[float]
    external_source:  str
    delta_pct:        Optional[float]
    explanation:      str
    recommendation:   str
    evidence_url:     str = ""
    reporting_year:   int = 2023

    def to_dict(self) -> dict:
        return {
            "flag_id":            self.flag_id,
            "company_ticker":     self.company_ticker,
            "inconsistency_type": self.inconsistency_type,
            "severity":           self.severity.value,
            "claim_text":         self.claim_text[:200],
            "claim_value":        self.claim_value,
            "external_value":     self.external_value,
            "external_source":    self.external_source,
            "delta_pct":          self.delta_pct,
            "explanation":        self.explanation,
            "recommendation":     self.recommendation,
            "evidence_url":       self.evidence_url,
            "reporting_year":     self.reporting_year,
        }


# ── Inconsistency report ──────────────────────────────────────────────────────

@dataclass
class InconsistencyReport:
    company_ticker: str
    company_name:   str
    report_year:    int
    flags:          list[InconsistencyFlag] = field(default_factory=list)

    @property
    def n_critical(self) -> int:
        return sum(1 for f in self.flags if f.severity == Severity.CRITICAL)

    @property
    def n_medium(self) -> int:
        return sum(1 for f in self.flags if f.severity == Severity.MEDIUM)

    @property
    def n_low(self) -> int:
        return sum(1 for f in self.flags if f.severity == Severity.LOW)

    @property
    def greenwashing_risk_score(self) -> float:
        """
        Composite Greenwashing Risk Score (GRS), 0–100.

        Formula:
          raw = sum(weight[severity] for each flag)
          GRS = min(raw / normalisation_factor * 100, 100)

        Calibrated so that 3 CRITICAL flags → GRS ~75,
        5 MEDIUM flags → GRS ~50, 10 LOW flags → GRS ~25.
        """
        raw = sum(SEVERITY_WEIGHTS[f.severity] for f in self.flags)
        # Normalise: 32 raw points = 100 GRS
        return round(min(raw / 32 * 100, 100), 1)

    @property
    def risk_band(self) -> str:
        grs = self.greenwashing_risk_score
        if grs >= 75: return "CRITICAL"
        if grs >= 45: return "HIGH"
        if grs >= 20: return "MEDIUM"
        return "LOW"

    def summary(self) -> dict:
        return {
            "company_ticker":         self.company_ticker,
            "company_name":           self.company_name,
            "report_year":            self.report_year,
            "total_flags":            len(self.flags),
            "critical_flags":         self.n_critical,
            "medium_flags":           self.n_medium,
            "low_flags":              self.n_low,
            "greenwashing_risk_score": self.greenwashing_risk_score,
            "risk_band":              self.risk_band,
        }

    def to_dict(self) -> dict:
        return {
            **self.summary(),
            "flags": [f.to_dict() for f in self.flags],
        }


# ══════════════════════════════════════════════════════════════════════════════
# Core detector
# ══════════════════════════════════════════════════════════════════════════════

class InconsistencyDetector:
    """
    Cross-source ESG inconsistency detector.

    For each claim:
      1. Align to external data (via ClaimAligner)
      2. Check for numeric mismatch (claim vs external source)
      3. Run temporal consistency check (YoY deltas)
      4. Check for scope omission (Scope 1/2 claim but Scope 3 unaddressed)
      5. Check for verification gaps
    """

    # Thresholds
    NUMERIC_MISMATCH_THRESHOLD_PCT = 20.0   # >20% divergence = flag
    NUMERIC_CRITICAL_THRESHOLD_PCT = 50.0   # >50% divergence = CRITICAL
    TEMPORAL_IMPLAUSIBLE_DROP_PCT  = 30.0   # >30% YoY drop = suspicious
    TEMPORAL_IMPLAUSIBLE_RISE_PCT  = 50.0   # >50% YoY rise = suspicious
    SCOPE_OMISSION_RATIO           = 5.0    # Scope3 > 5x (Scope1+2) = flag

    def __init__(self, registry: ExternalDataRegistry):
        self.registry = registry
        self.aligner  = ClaimAligner(registry)
        self._flag_counter = 0

    def _next_flag_id(self, ticker: str) -> str:
        self._flag_counter += 1
        return f"FLAG_{ticker}_{self._flag_counter:04d}"

    def analyse_company(
        self,
        ticker:       str,
        company_name: str,
        claims:       list[dict],
        report_year:  int = 2023,
    ) -> InconsistencyReport:
        """
        Run full inconsistency analysis for one company's ESG claims.
        Returns an InconsistencyReport with all detected flags.
        """
        report = InconsistencyReport(
            company_ticker=ticker,
            company_name=company_name,
            report_year=report_year,
        )
        # Align all claims to external data
        alignments = self.aligner.align_batch(claims)

        # Check 1: Numeric mismatches
        for ar in alignments:
            if ar.is_aligned() and ar.numeric_delta_pct is not None:
                self._check_numeric_mismatch(ar, report)

        # Check 2: Temporal anomalies
        self._check_temporal_anomalies(ticker, report)

        # Check 3: Scope omission
        self._check_scope_omission(ticker, report_year, claims, report)

        # Check 4: Verification gaps
        self._check_verification_gaps(ticker, report_year, alignments, report)

        # Check 5: Controversy context
        self._check_controversy_context(ticker, report_year, report)

        return report

    def analyse_portfolio(
        self,
        companies: list[dict],
    ) -> list[InconsistencyReport]:
        """Analyse a list of companies. Each dict: {ticker, name, claims, year}."""
        return [
            self.analyse_company(
                ticker=c["ticker"],
                company_name=c["name"],
                claims=c["claims"],
                report_year=c.get("year", 2023),
            )
            for c in companies
        ]

    # ── Check methods ─────────────────────────────────────────────────────────

    def _check_numeric_mismatch(
        self, ar: AlignmentResult, report: InconsistencyReport
    ) -> None:
        dp = ar.matched_dp
        delta_pct = abs(ar.numeric_delta_pct or 0)

        if delta_pct < self.NUMERIC_MISMATCH_THRESHOLD_PCT:
            return

        severity = (
            Severity.CRITICAL if delta_pct >= self.NUMERIC_CRITICAL_THRESHOLD_PCT
            else Severity.MEDIUM
        )
        direction = "understates" if (ar.numeric_delta or 0) > 0 else "overstates"

        flag = InconsistencyFlag(
            flag_id=self._next_flag_id(ar.claim_ticker),
            company_ticker=ar.claim_ticker,
            inconsistency_type="NUMERIC_MISMATCH",
            severity=severity,
            claim_text=ar.claim_text,
            claim_value=ar.extracted_nums[0].value if ar.extracted_nums else None,
            external_value=dp.metric_value if dp else None,
            external_source=dp.source if dp else "",
            delta_pct=ar.numeric_delta_pct,
            explanation=(
                f"Claim {direction} {dp.metric_name} by {delta_pct:.1f}%. "
                f"Claimed: {ar.extracted_nums[0].value if ar.extracted_nums else 'N/A'} "
                f"{ar.extracted_nums[0].unit if ar.extracted_nums else ''}. "
                f"External ({dp.source}): {dp.metric_value:,.1f} {dp.metric_unit} "
                f"[{dp.reporting_year}, {dp.assurance_level} assurance]."
            ),
            recommendation=(
                "Verify raw data against primary filing. "
                "If discrepancy is due to methodology differences (e.g. market-based vs location-based), "
                "ensure the methodology is clearly disclosed in the report."
            ),
            evidence_url=dp.source_url if dp else "",
            reporting_year=dp.reporting_year if dp else report.report_year,
        )
        report.flags.append(flag)

    def _check_temporal_anomalies(
        self, ticker: str, report: InconsistencyReport
    ) -> None:
        """Flag implausible year-over-year changes in Scope 1 emissions."""
        emission_metrics = [
            "scope_1_emissions_tco2e",
            "scope_2_mb_emissions_tco2e",
        ]
        for metric in emission_metrics:
            # Collect last 3 years of data
            yearly = {}
            for yr in [2021, 2022, 2023]:
                dp = self.registry.get_metric(ticker, metric, yr)
                if dp:
                    yearly[yr] = dp

            if len(yearly) < 2:
                continue

            years_sorted = sorted(yearly.keys())
            for i in range(1, len(years_sorted)):
                prev_yr = years_sorted[i-1]
                curr_yr = years_sorted[i]
                prev_val = yearly[prev_yr].metric_value
                curr_val = yearly[curr_yr].metric_value

                if prev_val == 0:
                    continue

                change_pct = (curr_val - prev_val) / prev_val * 100

                # Flag implausibly large single-year drop (could be methodology change)
                if change_pct <= -self.TEMPORAL_IMPLAUSIBLE_DROP_PCT:
                    severity = Severity.CRITICAL if change_pct <= -50 else Severity.MEDIUM
                    flag = InconsistencyFlag(
                        flag_id=self._next_flag_id(ticker),
                        company_ticker=ticker,
                        inconsistency_type="TEMPORAL_ANOMALY",
                        severity=severity,
                        claim_text=f"[Temporal check] {metric}: {prev_val:,.0f} ({prev_yr}) → {curr_val:,.0f} ({curr_yr})",
                        claim_value=curr_val,
                        external_value=prev_val,
                        external_source=yearly[curr_yr].source,
                        delta_pct=round(change_pct, 2),
                        explanation=(
                            f"{metric} dropped {abs(change_pct):.1f}% YoY "
                            f"({prev_yr}: {prev_val:,.0f} → {curr_yr}: {curr_val:,.0f} {yearly[curr_yr].metric_unit}). "
                            f"This rate of change exceeds typical operational improvement and may indicate "
                            f"asset divestiture, boundary change, or methodology restatement."
                        ),
                        recommendation=(
                            "Confirm whether reduction reflects genuine efficiency improvement "
                            "or asset disposal/boundary change. Require explicit disclosure of "
                            "any restatement methodology per GHG Protocol guidance."
                        ),
                        evidence_url=yearly[curr_yr].source_url,
                        reporting_year=curr_yr,
                    )
                    report.flags.append(flag)

                # Flag implausibly large single-year rise
                elif change_pct >= self.TEMPORAL_IMPLAUSIBLE_RISE_PCT:
                    flag = InconsistencyFlag(
                        flag_id=self._next_flag_id(ticker),
                        company_ticker=ticker,
                        inconsistency_type="TEMPORAL_ANOMALY",
                        severity=Severity.MEDIUM,
                        claim_text=f"[Temporal check] {metric}: {prev_val:,.0f} ({prev_yr}) → {curr_val:,.0f} ({curr_yr})",
                        claim_value=curr_val,
                        external_value=prev_val,
                        external_source=yearly[curr_yr].source,
                        delta_pct=round(change_pct, 2),
                        explanation=(
                            f"{metric} rose {change_pct:.1f}% YoY "
                            f"({prev_yr}: {prev_val:,.0f} → {curr_yr}: {curr_val:,.0f} {yearly[curr_yr].metric_unit}). "
                            f"Rapid increase may indicate scope expansion or data quality issues."
                        ),
                        recommendation=(
                            "Request explanation for emissions increase. "
                            "Verify whether boundary or methodology changes drove the rise."
                        ),
                        evidence_url=yearly[curr_yr].source_url,
                        reporting_year=curr_yr,
                    )
                    report.flags.append(flag)

    def _check_scope_omission(
        self,
        ticker:      str,
        report_year: int,
        claims:      list[dict],
        report:      InconsistencyReport,
    ) -> None:
        """
        Flag selective Scope disclosure:
        Company reports Scope 1+2 but Scope 3 >> Scope 1+2 and is not disclosed.
        """
        all_texts = " ".join(c.get("text", c.get("raw_text", "")) for c in claims).lower()
        mentions_s3 = "scope 3" in all_texts or "value chain" in all_texts

        s1 = self.registry.get_metric(ticker, "scope_1_emissions_tco2e", report_year)
        s3 = self.registry.get_metric(ticker, "scope_3_emissions_tco2e", report_year)

        if not (s1 and s3):
            return

        ratio = s3.metric_value / max(s1.metric_value, 1)

        if ratio > self.SCOPE_OMISSION_RATIO and not mentions_s3:
            severity = Severity.CRITICAL if ratio > 20 else Severity.MEDIUM
            flag = InconsistencyFlag(
                flag_id=self._next_flag_id(ticker),
                company_ticker=ticker,
                inconsistency_type="SCOPE_OMISSION",
                severity=severity,
                claim_text="[Scope omission] Claims focus on Scope 1+2 without disclosing Scope 3.",
                claim_value=s1.metric_value,
                external_value=s3.metric_value,
                external_source=s3.source,
                delta_pct=round(ratio, 1),
                explanation=(
                    f"Scope 3 emissions ({s3.metric_value/1e6:.1f} Mt CO2e) are {ratio:.0f}x "
                    f"larger than Scope 1 ({s1.metric_value/1e6:.2f} Mt CO2e) but Scope 3 is "
                    f"not mentioned in the analysed claims. Scope 1+2-only reporting creates a "
                    f"materially incomplete emissions picture for stakeholders."
                ),
                recommendation=(
                    "Require disclosure of Scope 3 Category-level estimates, particularly "
                    "categories 1 (purchased goods), 11 (use of sold products), and 15 "
                    "(investments) which typically dominate for this sector."
                ),
                evidence_url=s3.source_url,
                reporting_year=report_year,
            )
            report.flags.append(flag)

    def _check_verification_gaps(
        self,
        ticker:      str,
        report_year: int,
        alignments:  list[AlignmentResult],
        report:      InconsistencyReport,
    ) -> None:
        """Flag claims making quantitative assertions without third-party verification."""
        unverified_quantified = [
            ar for ar in alignments
            if ar.extracted_nums and (ar.matched_dp is None or not ar.matched_dp.is_verified)
            and ar.claim_metric not in ("unknown",)
        ]
        if len(unverified_quantified) >= 3:
            flag = InconsistencyFlag(
                flag_id=self._next_flag_id(ticker),
                company_ticker=ticker,
                inconsistency_type="VERIFICATION_GAP",
                severity=Severity.MEDIUM,
                claim_text=f"[Verification gap] {len(unverified_quantified)} quantified claims lack external verification.",
                claim_value=float(len(unverified_quantified)),
                external_value=None,
                external_source="CROSS_SOURCE_ANALYSIS",
                delta_pct=None,
                explanation=(
                    f"{len(unverified_quantified)} claims contain specific numeric values but "
                    f"no independently assured external data point was found to corroborate them. "
                    f"Unverified quantitative claims are a primary ESMA greenwashing risk indicator."
                ),
                recommendation=(
                    "Obtain at minimum limited assurance (ISO 14064-3 or AA1000AS) "
                    "for all Scope 1, 2 and 3 emissions claims. "
                    "Priority targets: " + ", ".join(
                        ar.claim_metric for ar in unverified_quantified[:3]
                    )
                ),
                evidence_url="",
                reporting_year=report_year,
            )
            report.flags.append(flag)

    def _check_controversy_context(
        self,
        ticker:      str,
        report_year: int,
        report:      InconsistencyReport,
    ) -> None:
        """Flag high Sustainalytics controversy scores that contradict positive ESG claims."""
        controversy = self.registry.sust.get_controversy_level(ticker, report_year)
        esg_risk    = self.registry.sust.get_esg_risk_score(ticker, report_year)

        if controversy is not None and controversy >= 4:
            flag = InconsistencyFlag(
                flag_id=self._next_flag_id(ticker),
                company_ticker=ticker,
                inconsistency_type="CONTROVERSY_CONTEXT",
                severity=Severity.CRITICAL if controversy == 5 else Severity.MEDIUM,
                claim_text="[Controversy context] Sustainalytics controversy level 4-5 vs positive ESG claims.",
                claim_value=None,
                external_value=float(controversy),
                external_source="SUSTAINALYTICS",
                delta_pct=None,
                explanation=(
                    f"Sustainalytics assigns a Level {controversy}/5 controversy rating to {ticker} "
                    f"(ESG Risk Score: {esg_risk}), indicating significant documented ESG incidents. "
                    f"Positive sustainability claims should be interpreted against this backdrop."
                ),
                recommendation=(
                    "Review Sustainalytics controversy report for specific incident categories. "
                    "Require company to address or disclose the specific controversies "
                    "flagged before accepting sustainability claims at face value."
                ),
                evidence_url=f"https://www.sustainalytics.com/esg-ratings/{ticker.lower()}",
                reporting_year=report_year,
            )
            report.flags.append(flag)

    def save_reports(
        self, reports: list[InconsistencyReport], output_dir: Path
    ) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / "inconsistency_reports.json"
        with open(path, "w") as f:
            json.dump([r.to_dict() for r in reports], f, indent=2)
        return path

    def save_summary(
        self, reports: list[InconsistencyReport], output_dir: Path
    ) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / "inconsistency_summary.json"
        summaries = [r.summary() for r in reports]
        with open(path, "w") as f:
            json.dump(summaries, f, indent=2)
        return path
