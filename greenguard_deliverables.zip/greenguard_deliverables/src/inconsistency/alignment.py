"""
inconsistency/alignment.py
───────────────────────────
Claim-to-datapoint alignment module.

Given an ESG claim sentence, this module:
  1. Extracts any numeric assertions (values, percentages, years)
  2. Identifies which ESG metric the claim is about (metric classification)
  3. Attempts to align the claim to an ExternalDataPoint from the registry
  4. Returns an AlignmentResult with match quality and evidence

Architecture (Sprint 3):
  • Metric classifier: keyword-based ontology lookup (fast, interpretable)
  • Numeric extraction: regex patterns for ESG-specific quantities
  • Alignment: cosine similarity on metric names + numeric proximity scoring

Sprint 4 will add DeBERTa-NLI entailment scoring as a confidence layer on top.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from src.connectors.external_data import ExternalDataPoint, ExternalDataRegistry


# ── Metric classification lookup ──────────────────────────────────────────────

METRIC_PATTERNS: dict[str, list[str]] = {
    "scope_1_emissions_tco2e": [
        r"scope\s*1", r"direct\s+emission", r"own\s+operation.*emission",
        r"fuel\s+combustion.*emission",
    ],
    "scope_2_mb_emissions_tco2e": [
        r"scope\s*2", r"market.based.*emission", r"indirect.*electricity.*emission",
        r"purchased\s+electricity.*emission",
    ],
    "scope_3_emissions_tco2e": [
        r"scope\s*3", r"value\s+chain.*emission", r"upstream.*emission",
        r"supply\s+chain.*emission", r"financed\s+emission", r"category\s+\d+",
    ],
    "renewable_electricity_pct": [
        r"renewable\s+electricity", r"clean\s+energy\s+(\d+)%",
        r"(\d+)%.*renewable", r"green\s+power", r"100%.*renewable",
    ],
    "emissions_reduction_target_pct": [
        r"reduc.*emission.*(\d+)%", r"(\d+)%.*reduc.*emission",
        r"emission.*target", r"ghg.*target", r"net\s+zero.*by",
        r"carbon\s+neutral.*by", r"scope.*reduc",
    ],
    "methane_emissions_intensity": [
        r"methane", r"ch4", r"flaring", r"venting",
    ],
    "renewable_capex_bn_usd": [
        r"capex.*low.carbon", r"clean\s+energy.*invest",
        r"renewable.*capital", r"green.*investment",
    ],
    "esg_risk_score": [
        r"esg\s+risk", r"sustainalytics", r"esg\s+rating", r"esg\s+score",
    ],
    "cdp_climate_score": [
        r"cdp\s+score", r"cdp\s+climate", r"cdp.*\bA\b", r"cdp.*rating",
    ],
    "controversy_level": [
        r"controversy", r"allegation", r"violation", r"sanction",
    ],
}

# Numeric extraction patterns for ESG values
NUMERIC_PATTERNS = [
    # Percentage: "42%", "42 percent", "42.5%"
    (re.compile(r"(\d+(?:\.\d+)?)\s*(?:%|percent)", re.I), "%"),
    # Mass (tCO2e): "142,000 tCO2e", "1.2 million tCO2e", "106 Mt CO2"
    (re.compile(r"(\d[\d,]*(?:\.\d+)?)\s*(?:million\s+)?(?:metric\s+)?(?:ton(?:ne)?s?\s+of\s+co2|tco2e?|mtco2|ktco2)", re.I), "tCO2e"),
    # Billion USD: "$8.2 billion", "USD 3.2B"
    (re.compile(r"\$?\s*(\d+(?:\.\d+)?)\s*(?:billion|bn)\s*(?:usd|dollars?)?", re.I), "Bn USD"),
    # Year: "by 2030", "2050 target"
    (re.compile(r"\bby\s+(20[2-9]\d)\b|\b(20[2-9]\d)\s+target\b", re.I), "year"),
]


@dataclass
class NumericExtraction:
    """A number extracted from a claim sentence."""
    raw_text:   str
    value:      float
    unit:       str
    context:    str       # surrounding words


@dataclass
class AlignmentResult:
    """Result of aligning one ESG claim to external data."""
    claim_text:      str
    claim_metric:    str          # identified metric (or "unknown")
    claim_ticker:    str          # identified company ticker (or "")
    extracted_nums:  list[NumericExtraction]

    matched_dp:      Optional[ExternalDataPoint] = None
    alignment_score: float = 0.0      # 0.0–1.0 confidence in alignment
    numeric_match:   Optional[bool]  = None   # True/False/None (not applicable)
    numeric_delta:   Optional[float] = None   # actual - claimed value
    numeric_delta_pct: Optional[float] = None # relative delta

    evidence_text:   str = ""
    needs_verification: bool = False

    def is_aligned(self) -> bool:
        return self.matched_dp is not None and self.alignment_score >= 0.4


class ClaimAligner:
    """
    Aligns ESG claim sentences to external data points.

    Steps:
      1. Classify the metric being claimed (regex ontology)
      2. Identify the company ticker from context
      3. Extract numeric values from the claim
      4. Lookup matching ExternalDataPoint
      5. Score alignment quality and numeric agreement
    """

    TICKER_PATTERNS: dict[str, list[str]] = {
        "AAPL": ["apple", "aapl"],
        "MSFT": ["microsoft", "msft"],
        "XOM":  ["exxon", "exxonmobil", "xom"],
        "BP":   [r"\bbp\b", "british petroleum"],
        "NKE":  ["nike", "nke"],
        "GOOGL":["alphabet", "google", "googl"],
        "AMZN": ["amazon", "amzn"],
        "TSLA": ["tesla", "tsla"],
        "CVX":  ["chevron", "cvx"],
        "SHEL": ["shell", "shel"],
        # Demo companies from Sprint 1/2
        "DEMO_CO_A": ["acmecorp", "acme corp"],
        "DEMO_CO_D": ["renewpower", "renew power"],
        "DEMO_CO_G": ["bankglobal", "bank global"],
    }

    def __init__(self, registry: ExternalDataRegistry):
        self.registry = registry
        self._metric_compiled = {
            metric: [re.compile(p, re.I) for p in patterns]
            for metric, patterns in METRIC_PATTERNS.items()
        }
        self._ticker_compiled = {
            ticker: [re.compile(p, re.I) for p in patterns]
            for ticker, patterns in self.TICKER_PATTERNS.items()
        }

    def align(
        self,
        claim_text: str,
        company_ticker: str = "",
        reporting_year: int = 2023,
    ) -> AlignmentResult:
        """Align a claim to the best matching external data point."""

        # Step 1: Classify metric
        metric = self._classify_metric(claim_text)

        # Step 2: Identify ticker
        ticker = company_ticker or self._identify_ticker(claim_text)

        # Step 3: Extract numerics
        nums = self._extract_numerics(claim_text)

        result = AlignmentResult(
            claim_text=claim_text,
            claim_metric=metric,
            claim_ticker=ticker,
            extracted_nums=nums,
        )

        # Step 4: Look up external data point
        if not ticker or metric == "unknown":
            result.needs_verification = len(nums) > 0
            return result

        dp = self.registry.get_metric(ticker, metric, reporting_year)
        if dp is None:
            # Try adjacent years
            for yr in [reporting_year - 1, reporting_year + 1]:
                dp = self.registry.get_metric(ticker, metric, yr)
                if dp:
                    break

        if dp is None:
            result.needs_verification = len(nums) > 0
            return result

        result.matched_dp = dp
        result.alignment_score = self._score_alignment(claim_text, dp)

        # Step 5: Numeric comparison
        if nums:
            claim_val = self._best_numeric_for_metric(nums, metric)
            if claim_val is not None:
                actual = dp.metric_value
                delta = actual - claim_val
                delta_pct = (delta / actual * 100) if actual != 0 else None
                result.numeric_match = abs(delta_pct or 0) < 15
                result.numeric_delta = round(delta, 2)
                result.numeric_delta_pct = round(delta_pct, 2) if delta_pct is not None else None

        result.evidence_text = (
            f"External source ({dp.source}): {dp.metric_name} = "
            f"{dp.metric_value:,.1f} {dp.metric_unit} "
            f"[{dp.reporting_year}, {dp.assurance_level} assurance]"
        )
        result.needs_verification = (
            result.numeric_match is False or not dp.is_verified
        )
        return result

    def align_batch(
        self,
        claims: list[dict],
    ) -> list[AlignmentResult]:
        """Align a batch of claim dicts."""
        results = []
        for c in claims:
            r = self.align(
                claim_text=c.get("text", c.get("raw_text", "")),
                company_ticker=c.get("company_ticker", ""),
                reporting_year=int(c.get("report_year", 2023)),
            )
            results.append(r)
        return results

    # ── Private helpers ───────────────────────────────────────────────────────

    def _classify_metric(self, text: str) -> str:
        """Return best-matching metric name for a claim text."""
        lower = text.lower()
        scores: dict[str, int] = {}
        for metric, patterns in self._metric_compiled.items():
            scores[metric] = sum(1 for p in patterns if p.search(lower))
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 else "unknown"

    def _identify_ticker(self, text: str) -> str:
        """Identify company ticker from claim text."""
        lower = text.lower()
        for ticker, patterns in self._ticker_compiled.items():
            if any(p.search(lower) for p in patterns):
                return ticker
        return ""

    def _extract_numerics(self, text: str) -> list[NumericExtraction]:
        """Extract all numeric values from a claim."""
        results = []
        for pattern, unit in NUMERIC_PATTERNS:
            for match in pattern.finditer(text):
                # Get first non-None group
                val_str = next((g for g in match.groups() if g), None)
                if not val_str:
                    continue
                val_str = val_str.replace(",", "")
                try:
                    value = float(val_str)
                except ValueError:
                    continue
                start = max(0, match.start() - 30)
                end = min(len(text), match.end() + 30)
                results.append(NumericExtraction(
                    raw_text=match.group(),
                    value=value,
                    unit=unit,
                    context=text[start:end],
                ))
        return results

    def _best_numeric_for_metric(
        self, nums: list[NumericExtraction], metric: str
    ) -> Optional[float]:
        """Pick the numeric value most relevant for the given metric."""
        unit_preference = {
            "scope_1_emissions_tco2e":    "tCO2e",
            "scope_2_mb_emissions_tco2e": "tCO2e",
            "scope_3_emissions_tco2e":    "tCO2e",
            "renewable_electricity_pct":  "%",
            "emissions_reduction_target_pct": "%",
            "methane_emissions_intensity": "%",
            "renewable_capex_bn_usd":     "Bn USD",
        }
        preferred_unit = unit_preference.get(metric, "")
        # Filter by preferred unit first
        filtered = [n for n in nums if n.unit == preferred_unit]
        if filtered:
            return filtered[0].value
        # Fall back to any numeric
        return nums[0].value if nums else None

    def _score_alignment(self, text: str, dp: ExternalDataPoint) -> float:
        """Score how confident we are that this claim is about this data point."""
        lower = text.lower()
        # Metric name keywords match
        metric_keywords = dp.metric_name.replace("_", " ").split()
        keyword_hits = sum(1 for kw in metric_keywords if kw in lower)
        score = min(keyword_hits / max(len(metric_keywords), 1), 1.0) * 0.6
        # Year match
        if str(dp.reporting_year) in text:
            score += 0.2
        # Source standard mention
        methodology_kws = dp.methodology.lower().split()[:3]
        if any(kw in lower for kw in methodology_kws):
            score += 0.2
        return round(min(score, 1.0), 3)
