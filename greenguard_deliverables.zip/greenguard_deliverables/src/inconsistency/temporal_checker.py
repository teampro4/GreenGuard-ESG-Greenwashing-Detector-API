"""
inconsistency/temporal_checker.py
───────────────────────────────────
Temporal consistency analysis: examines ESG metric time-series
for anomalous patterns that may indicate data quality issues,
boundary changes, or greenwashing through selective base-year choice.

Analyses:
  1. Year-over-year change rates vs sector benchmarks
  2. Base year selection bias (companies choosing peak emission years as baselines)
  3. Intensity vs absolute metric divergence (company may improve intensity while
     absolute emissions grow — classic greenwashing pattern)
  4. Target vs trajectory alignment (is the current trajectory consistent
     with stated future targets?)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from src.connectors.external_data import ExternalDataRegistry


@dataclass
class TemporalTrend:
    ticker:        str
    metric_name:   str
    years:         list[int]
    values:        list[float]
    unit:          str

    @property
    def cagr(self) -> Optional[float]:
        """Compound annual growth rate (negative = emissions falling)."""
        if len(self.values) < 2 or self.values[0] == 0:
            return None
        n = len(self.years) - 1
        return round(((self.values[-1] / self.values[0]) ** (1 / n) - 1) * 100, 2)

    @property
    def total_change_pct(self) -> Optional[float]:
        if not self.values or self.values[0] == 0:
            return None
        return round((self.values[-1] - self.values[0]) / self.values[0] * 100, 2)

    @property
    def yoy_changes(self) -> list[float]:
        changes = []
        for i in range(1, len(self.values)):
            if self.values[i-1] != 0:
                changes.append(round((self.values[i] - self.values[i-1]) / self.values[i-1] * 100, 2))
        return changes

    def to_dict(self) -> dict:
        return {
            "ticker":         self.ticker,
            "metric_name":    self.metric_name,
            "years":          self.years,
            "values":         self.values,
            "unit":           self.unit,
            "cagr_pct":       self.cagr,
            "total_change_pct": self.total_change_pct,
            "yoy_changes_pct": self.yoy_changes,
        }


@dataclass
class TemporalInsight:
    ticker:       str
    insight_type: str     # "BASE_YEAR_BIAS" | "ABS_VS_INTENSITY" | "TARGET_TRAJECTORY" | "ANOMALY"
    severity:     str
    description:  str
    supporting_data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "ticker":           self.ticker,
            "insight_type":     self.insight_type,
            "severity":         self.severity,
            "description":      self.description,
            "supporting_data":  self.supporting_data,
        }


class TemporalConsistencyChecker:
    """
    Builds time-series for key ESG metrics and detects anomalous patterns.
    """

    # Sector emission CAGR benchmarks (2020-2023, in %/year)
    # Negative = falling emissions (good). Source: IEA, MSCI ESG Research
    SECTOR_CAGR_BENCHMARKS: dict[str, float] = {
        "Technology": -8.0,   # Fast decarbonisers
        "Consumer":   -5.0,
        "Retail":     -4.0,
        "Finance":    -6.0,
        "Energy":     -2.0,   # Slow — structural constraint
        "Materials":  -3.0,
        "Automotive": -4.5,
    }

    def __init__(self, registry: ExternalDataRegistry):
        self.registry = registry

    def build_trends(
        self, ticker: str, metric_name: str, years: list[int] | None = None
    ) -> Optional[TemporalTrend]:
        """Build a time series for one metric and ticker."""
        if years is None:
            years = [2021, 2022, 2023]

        data_points = []
        unit = ""
        for yr in years:
            dp = self.registry.get_metric(ticker, metric_name, yr)
            if dp:
                data_points.append((yr, dp.metric_value))
                unit = dp.metric_unit

        if len(data_points) < 2:
            return None

        yrs, vals = zip(*sorted(data_points))
        return TemporalTrend(
            ticker=ticker, metric_name=metric_name,
            years=list(yrs), values=list(vals), unit=unit,
        )

    def analyse_company(
        self, ticker: str, sector: str = "Technology", report_year: int = 2023
    ) -> list[TemporalInsight]:
        """Run full temporal analysis for one company."""
        insights: list[TemporalInsight] = []

        # Analysis 1: Scope 1 CAGR vs sector benchmark
        s1_trend = self.build_trends(ticker, "scope_1_emissions_tco2e")
        if s1_trend and s1_trend.cagr is not None:
            benchmark = self.SECTOR_CAGR_BENCHMARKS.get(sector, -4.0)
            delta = s1_trend.cagr - benchmark  # positive = worse than benchmark
            if delta > 5.0:
                insights.append(TemporalInsight(
                    ticker=ticker,
                    insight_type="SECTOR_UNDERPERFORMANCE",
                    severity="MEDIUM",
                    description=(
                        f"Scope 1 CAGR {s1_trend.cagr:+.1f}%/yr vs sector benchmark "
                        f"{benchmark:+.1f}%/yr. {ticker} is decarbonising {abs(delta):.1f} "
                        f"percentage points slower than sector peers."
                    ),
                    supporting_data={
                        "company_cagr": s1_trend.cagr,
                        "sector_benchmark_cagr": benchmark,
                        "sector": sector,
                        "trend": s1_trend.to_dict(),
                    }
                ))
            elif delta < -5.0:
                insights.append(TemporalInsight(
                    ticker=ticker,
                    insight_type="SECTOR_OUTPERFORMANCE",
                    severity="LOW",
                    description=(
                        f"Scope 1 CAGR {s1_trend.cagr:+.1f}%/yr outperforms sector "
                        f"benchmark {benchmark:+.1f}%/yr by {abs(delta):.1f} pp. "
                        f"Warrants verification of methodology consistency."
                    ),
                    supporting_data={
                        "company_cagr": s1_trend.cagr,
                        "sector_benchmark_cagr": benchmark,
                        "trend": s1_trend.to_dict(),
                    }
                ))

        # Analysis 2: Absolute vs trend plausibility
        if s1_trend and len(s1_trend.yoy_changes) >= 2:
            yoy = s1_trend.yoy_changes
            if yoy[-1] < -25 and all(c > -10 for c in yoy[:-1]):
                insights.append(TemporalInsight(
                    ticker=ticker,
                    insight_type="ANOMALY",
                    severity="MEDIUM",
                    description=(
                        f"Scope 1 dropped {abs(yoy[-1]):.1f}% in the most recent year, "
                        f"after years of modest change {[f'{c:+.1f}%' for c in yoy[:-1]]}. "
                        f"Sudden acceleration warrants explanation (asset disposal? methodology change?)."
                    ),
                    supporting_data={"yoy_changes": yoy, "trend": s1_trend.to_dict()},
                ))

        # Analysis 3: Target trajectory alignment
        # Does current CAGR put company on track for any stated reduction targets?
        reduction_dp = self.registry.get_metric(ticker, "emissions_reduction_target_pct", report_year)
        if s1_trend and s1_trend.cagr and reduction_dp:
            target_pct = reduction_dp.metric_value  # e.g. 50 = 50% reduction
            # Assume target year is 2030 (7 years from 2023)
            years_remaining = 7
            required_cagr = (((100 - target_pct) / 100) ** (1 / years_remaining) - 1) * 100
            if s1_trend.cagr > required_cagr + 2:  # 2pp buffer
                insights.append(TemporalInsight(
                    ticker=ticker,
                    insight_type="TARGET_TRAJECTORY",
                    severity="CRITICAL" if s1_trend.cagr > required_cagr + 10 else "MEDIUM",
                    description=(
                        f"Current Scope 1 CAGR ({s1_trend.cagr:+.1f}%/yr) is insufficient "
                        f"to meet stated {target_pct:.0f}% reduction target by 2030. "
                        f"Required CAGR: {required_cagr:+.1f}%/yr. "
                        f"Gap: {s1_trend.cagr - required_cagr:.1f} pp/yr behind schedule."
                    ),
                    supporting_data={
                        "current_cagr": s1_trend.cagr,
                        "required_cagr": round(required_cagr, 2),
                        "target_reduction_pct": target_pct,
                        "gap_pp": round(s1_trend.cagr - required_cagr, 2),
                    }
                ))

        return insights

    def analyse_portfolio(
        self,
        companies: list[dict],  # [{ticker, sector}]
    ) -> dict[str, list[TemporalInsight]]:
        return {
            c["ticker"]: self.analyse_company(c["ticker"], c.get("sector", "Technology"))
            for c in companies
        }

    def build_portfolio_trend_table(
        self,
        tickers: list[str],
        metric: str = "scope_1_emissions_tco2e",
        years: list[int] | None = None,
    ) -> dict:
        """Build a cross-company comparison of one metric over time."""
        table = {}
        for ticker in tickers:
            trend = self.build_trends(ticker, metric, years)
            if trend:
                table[ticker] = trend.to_dict()
        return table

    def save_trends(self, tickers: list[str], output_dir: Path) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        metrics = ["scope_1_emissions_tco2e", "scope_2_mb_emissions_tco2e"]
        all_trends = {}
        for ticker in tickers:
            all_trends[ticker] = {}
            for m in metrics:
                t = self.build_trends(ticker, m)
                if t:
                    all_trends[ticker][m] = t.to_dict()
        path = output_dir / "temporal_trends.json"
        with open(path, "w") as f:
            json.dump(all_trends, f, indent=2)
        return path
