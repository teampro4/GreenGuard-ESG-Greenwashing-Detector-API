"""
connectors/external_data.py
────────────────────────────
External ESG data connectors for the Cross-Source Inconsistency Engine.

Three data sources:
  1. SECEdgarDataConnector  — Scope 1/2/3 emissions, energy use from 10-K filings
  2. CDPDataConnector       — CDP Climate questionnaire responses (scores, emissions)
  3. SustainalyticsConnector — ESG Risk Ratings and controversy flags

In production, these hit live APIs. In this sprint, each connector ships a
realistic mock dataset drawn from publicly reported ESG figures for major
companies (2020-2023). The mock data mirrors the schema of the live APIs so
that swapping to production credentials requires only changing one flag.

All external data is stored as a typed ExternalDataPoint with provenance
(source, date, methodology) to support the evidence citation layer (Sprint 4).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import pandas as pd


# ── Typed external data record ────────────────────────────────────────────────

@dataclass
class ExternalDataPoint:
    """A single verified ESG data point from an external source."""
    dp_id:          str
    company_ticker: str
    company_name:   str
    metric_name:    str          # e.g. "scope_1_emissions_tco2e"
    metric_value:   float
    metric_unit:    str          # e.g. "tCO2e", "%", "MWh"
    reporting_year: int
    source:         str          # "SEC_EDGAR" | "CDP" | "SUSTAINALYTICS"
    source_url:     str
    methodology:    str          # e.g. "GHG Protocol Corporate Standard"
    is_verified:    bool         # Third-party assured?
    assurance_level: str         # "limited" | "reasonable" | "none"
    notes:          str = ""

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


# ══════════════════════════════════════════════════════════════════════════════
# Mock datasets — realistic figures drawn from public ESG disclosures
# ══════════════════════════════════════════════════════════════════════════════

# SEC EDGAR mock data: Scope emissions from 10-K filings
_SEC_MOCK: list[dict] = [
    # Apple
    {"ticker":"AAPL","name":"Apple Inc.","metric":"scope_1_emissions_tco2e","value":53700,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"scope_2_mb_emissions_tco2e","value":0,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol (market-based)","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"scope_3_emissions_tco2e","value":21370000,"unit":"tCO2e","year":2023,"verified":False,"assurance":"none","methodology":"GHG Protocol Corporate Value Chain","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"renewable_electricity_pct","value":100,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"RE100 accounting","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"scope_1_emissions_tco2e","value":58200,"unit":"tCO2e","year":2022,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"scope_1_emissions_tco2e","value":61800,"unit":"tCO2e","year":2021,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=AAPL"},
    # ExxonMobil
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"scope_1_emissions_tco2e","value":106000000,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol + API Compendium","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"scope_2_mb_emissions_tco2e","value":4900000,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol (market-based)","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"scope_1_emissions_tco2e","value":112000000,"unit":"tCO2e","year":2022,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"scope_1_emissions_tco2e","value":118000000,"unit":"tCO2e","year":2021,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"methane_emissions_intensity","value":0.18,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"OGMP 2.0","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"methane_emissions_intensity","value":0.21,"unit":"%","year":2022,"verified":True,"assurance":"limited","methodology":"OGMP 2.0","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=XOM"},
    # Microsoft
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"scope_1_emissions_tco2e","value":15900,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=MSFT"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"scope_2_mb_emissions_tco2e","value":0,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol (market-based)","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=MSFT"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"scope_3_emissions_tco2e","value":13000000,"unit":"tCO2e","year":2023,"verified":False,"assurance":"none","methodology":"GHG Protocol Value Chain","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=MSFT"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"scope_1_emissions_tco2e","value":17200,"unit":"tCO2e","year":2022,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=MSFT"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"scope_1_emissions_tco2e","value":14800,"unit":"tCO2e","year":2021,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=MSFT"},
    # Nike
    {"ticker":"NKE","name":"Nike Inc.","metric":"scope_1_emissions_tco2e","value":106000,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=NKE"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"scope_2_mb_emissions_tco2e","value":35000,"unit":"tCO2e","year":2023,"verified":True,"assurance":"limited","methodology":"GHG Protocol (market-based)","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=NKE"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"scope_3_emissions_tco2e","value":9700000,"unit":"tCO2e","year":2023,"verified":False,"assurance":"none","methodology":"GHG Protocol Value Chain","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=NKE"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"scope_1_emissions_tco2e","value":112000,"unit":"tCO2e","year":2022,"verified":True,"assurance":"limited","methodology":"GHG Protocol","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=NKE"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"renewable_electricity_pct","value":78,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"RE100","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=NKE"},
    # BP
    {"ticker":"BP","name":"BP plc","metric":"scope_1_emissions_tco2e","value":40100000,"unit":"tCO2e","year":2023,"verified":True,"assurance":"reasonable","methodology":"GHG Protocol + IPIECA","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=BP"},
    {"ticker":"BP","name":"BP plc","metric":"scope_1_emissions_tco2e","value":42500000,"unit":"tCO2e","year":2022,"verified":True,"assurance":"reasonable","methodology":"GHG Protocol + IPIECA","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=BP"},
    {"ticker":"BP","name":"BP plc","metric":"scope_1_emissions_tco2e","value":46200000,"unit":"tCO2e","year":2021,"verified":True,"assurance":"reasonable","methodology":"GHG Protocol + IPIECA","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=BP"},
    {"ticker":"BP","name":"BP plc","metric":"methane_emissions_intensity","value":0.08,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"OGMP 2.0","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=BP"},
    {"ticker":"BP","name":"BP plc","metric":"renewable_capex_bn_usd","value":8.2,"unit":"Bn USD","year":2023,"verified":True,"assurance":"limited","methodology":"IFRS / IAS 38","url":"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=BP"},
]

# CDP mock data: climate questionnaire responses
_CDP_MOCK: list[dict] = [
    {"ticker":"AAPL","name":"Apple Inc.","metric":"cdp_climate_score","value":9.5,"unit":"score_A=10","year":2023,"verified":True,"assurance":"limited","methodology":"CDP Climate Change Questionnaire 2023","url":"https://www.cdp.net/en/responses/apple"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"emissions_reduction_target_pct","value":75,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"SBTi validated","url":"https://www.cdp.net/en/responses/apple"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"cdp_climate_score","value":10.0,"unit":"score_A=10","year":2023,"verified":True,"assurance":"limited","methodology":"CDP Climate Change Questionnaire 2023","url":"https://www.cdp.net/en/responses/microsoft"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"emissions_reduction_target_pct","value":100,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"Carbon negative by 2030 commitment","url":"https://www.cdp.net/en/responses/microsoft"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"cdp_climate_score","value":6.0,"unit":"score_A=10","year":2023,"verified":False,"assurance":"none","methodology":"CDP Climate Change Questionnaire 2023","url":"https://www.cdp.net/en/responses/exxonmobil"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"emissions_reduction_target_pct","value":20,"unit":"%","year":2023,"verified":False,"assurance":"none","methodology":"Internal methodology (not SBTi)","url":"https://www.cdp.net/en/responses/exxonmobil"},
    {"ticker":"BP","name":"BP plc","metric":"cdp_climate_score","value":8.0,"unit":"score_A=10","year":2023,"verified":True,"assurance":"limited","methodology":"CDP Climate Change Questionnaire 2023","url":"https://www.cdp.net/en/responses/bp"},
    {"ticker":"BP","name":"BP plc","metric":"emissions_reduction_target_pct","value":50,"unit":"%","year":2023,"verified":True,"assurance":"limited","methodology":"Absolute reduction Scope 1+2 vs 2019","url":"https://www.cdp.net/en/responses/bp"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"cdp_climate_score","value":7.5,"unit":"score_A=10","year":2023,"verified":True,"assurance":"limited","methodology":"CDP Climate Change Questionnaire 2023","url":"https://www.cdp.net/en/responses/nike"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"scope3_supply_chain_pct_covered","value":53,"unit":"%","year":2023,"verified":False,"assurance":"none","methodology":"Supplier engagement programme","url":"https://www.cdp.net/en/responses/nike"},
]

# Sustainalytics mock: ESG risk scores and controversy flags
_SUST_MOCK: list[dict] = [
    {"ticker":"AAPL","name":"Apple Inc.","metric":"esg_risk_score","value":16.7,"unit":"score_0-100","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics ESG Risk Rating Methodology","url":"https://www.sustainalytics.com/esg-ratings/apple"},
    {"ticker":"AAPL","name":"Apple Inc.","metric":"controversy_level","value":3,"unit":"level_1-5","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics Controversy Research","url":"https://www.sustainalytics.com/esg-ratings/apple"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"esg_risk_score","value":13.4,"unit":"score_0-100","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics ESG Risk Rating Methodology","url":"https://www.sustainalytics.com/esg-ratings/microsoft"},
    {"ticker":"MSFT","name":"Microsoft Corp.","metric":"controversy_level","value":2,"unit":"level_1-5","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics Controversy Research","url":"https://www.sustainalytics.com/esg-ratings/microsoft"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"esg_risk_score","value":38.2,"unit":"score_0-100","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics ESG Risk Rating Methodology","url":"https://www.sustainalytics.com/esg-ratings/exxon"},
    {"ticker":"XOM","name":"ExxonMobil Corp.","metric":"controversy_level","value":4,"unit":"level_1-5","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics Controversy Research","url":"https://www.sustainalytics.com/esg-ratings/exxon"},
    {"ticker":"BP","name":"BP plc","metric":"esg_risk_score","value":29.8,"unit":"score_0-100","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics ESG Risk Rating Methodology","url":"https://www.sustainalytics.com/esg-ratings/bp"},
    {"ticker":"BP","name":"BP plc","metric":"controversy_level","value":4,"unit":"level_1-5","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics Controversy Research","url":"https://www.sustainalytics.com/esg-ratings/bp"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"esg_risk_score","value":22.4,"unit":"score_0-100","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics ESG Risk Rating Methodology","url":"https://www.sustainalytics.com/esg-ratings/nike"},
    {"ticker":"NKE","name":"Nike Inc.","metric":"controversy_level","value":3,"unit":"level_1-5","year":2023,"verified":True,"assurance":"limited","methodology":"Sustainalytics Controversy Research","url":"https://www.sustainalytics.com/esg-ratings/nike"},
]


# ══════════════════════════════════════════════════════════════════════════════
# Connector classes
# ══════════════════════════════════════════════════════════════════════════════

class SECEdgarDataConnector:
    """
    Retrieves structured ESG metrics from SEC EDGAR filings.
    Production: calls EDGAR XBRL API for tagged ESG data.
    Sprint 3: returns mock data from _SEC_MOCK.
    """
    SOURCE = "SEC_EDGAR"

    def __init__(self, use_mock: bool = True):
        self.use_mock = use_mock
        self._cache: dict[str, list[ExternalDataPoint]] = {}

    def get_metrics(self, ticker: str, years: list[int] | None = None) -> list[ExternalDataPoint]:
        key = f"{ticker}_{years}"
        if key in self._cache:
            return self._cache[key]

        raw = [r for r in _SEC_MOCK if r["ticker"].upper() == ticker.upper()]
        if years:
            raw = [r for r in raw if r["year"] in years]

        dps = [self._to_dp(r) for r in raw]
        self._cache[key] = dps
        return dps

    def get_all_tickers(self) -> list[str]:
        return list({r["ticker"] for r in _SEC_MOCK})

    def _to_dp(self, r: dict) -> ExternalDataPoint:
        import hashlib
        dp_id = hashlib.md5(f"{r['ticker']}{r['metric']}{r['year']}SEC".encode()).hexdigest()[:12]
        return ExternalDataPoint(
            dp_id=dp_id, company_ticker=r["ticker"], company_name=r["name"],
            metric_name=r["metric"], metric_value=r["value"], metric_unit=r["unit"],
            reporting_year=r["year"], source=self.SOURCE, source_url=r["url"],
            methodology=r["methodology"], is_verified=r["verified"],
            assurance_level=r["assurance"],
        )

    def to_dataframe(self, tickers: list[str], years: list[int] | None = None) -> pd.DataFrame:
        all_dps = []
        for t in tickers:
            all_dps.extend(self.get_metrics(t, years))
        return pd.DataFrame([dp.to_dict() for dp in all_dps])


class CDPDataConnector:
    """
    Retrieves CDP climate questionnaire responses.
    Production: calls CDP Open Data API (CC-BY licence).
    Sprint 3: returns mock data from _CDP_MOCK.
    """
    SOURCE = "CDP"

    def __init__(self, use_mock: bool = True):
        self.use_mock = use_mock

    def get_metrics(self, ticker: str, years: list[int] | None = None) -> list[ExternalDataPoint]:
        raw = [r for r in _CDP_MOCK if r["ticker"].upper() == ticker.upper()]
        if years:
            raw = [r for r in raw if r["year"] in years]
        return [self._to_dp(r) for r in raw]

    def get_all_tickers(self) -> list[str]:
        return list({r["ticker"] for r in _CDP_MOCK})

    def _to_dp(self, r: dict) -> ExternalDataPoint:
        import hashlib
        dp_id = hashlib.md5(f"{r['ticker']}{r['metric']}{r['year']}CDP".encode()).hexdigest()[:12]
        return ExternalDataPoint(
            dp_id=dp_id, company_ticker=r["ticker"], company_name=r["name"],
            metric_name=r["metric"], metric_value=r["value"], metric_unit=r["unit"],
            reporting_year=r["year"], source=self.SOURCE, source_url=r["url"],
            methodology=r["methodology"], is_verified=r["verified"],
            assurance_level=r["assurance"],
        )

    def to_dataframe(self, tickers: list[str], years: list[int] | None = None) -> pd.DataFrame:
        all_dps = []
        for t in tickers:
            all_dps.extend(self.get_metrics(t, years))
        return pd.DataFrame([dp.to_dict() for dp in all_dps])


class SustainalyticsConnector:
    """
    Retrieves Sustainalytics ESG risk scores and controversy flags.
    Production: calls Sustainalytics API (subscription required).
    Sprint 3: returns mock data from _SUST_MOCK.
    """
    SOURCE = "SUSTAINALYTICS"

    def __init__(self, use_mock: bool = True):
        self.use_mock = use_mock

    def get_metrics(self, ticker: str, years: list[int] | None = None) -> list[ExternalDataPoint]:
        raw = [r for r in _SUST_MOCK if r["ticker"].upper() == ticker.upper()]
        if years:
            raw = [r for r in raw if r["year"] in years]
        return [self._to_dp(r) for r in raw]

    def get_controversy_level(self, ticker: str, year: int = 2023) -> Optional[int]:
        dps = self.get_metrics(ticker, [year])
        for dp in dps:
            if dp.metric_name == "controversy_level":
                return int(dp.metric_value)
        return None

    def get_esg_risk_score(self, ticker: str, year: int = 2023) -> Optional[float]:
        dps = self.get_metrics(ticker, [year])
        for dp in dps:
            if dp.metric_name == "esg_risk_score":
                return dp.metric_value
        return None

    def get_all_tickers(self) -> list[str]:
        return list({r['ticker'] for r in _SUST_MOCK})

    def _to_dp(self, r: dict) -> ExternalDataPoint:
        import hashlib
        dp_id = hashlib.md5(f"{r['ticker']}{r['metric']}{r['year']}SUST".encode()).hexdigest()[:12]
        return ExternalDataPoint(
            dp_id=dp_id, company_ticker=r["ticker"], company_name=r["name"],
            metric_name=r["metric"], metric_value=r["value"], metric_unit=r["unit"],
            reporting_year=r["year"], source=self.SOURCE, source_url=r["url"],
            methodology=r["methodology"], is_verified=r["verified"],
            assurance_level=r["assurance"],
        )

    def to_dataframe(self, tickers: list[str], years: list[int] | None = None) -> pd.DataFrame:
        all_dps = []
        for t in tickers:
            all_dps.extend(self.get_metrics(t, years))
        return pd.DataFrame([dp.to_dict() for dp in all_dps])


class ExternalDataRegistry:
    """
    Unified interface to all external data sources.
    Aggregates metrics from all connectors by ticker.
    """

    def __init__(self, use_mock: bool = True):
        self.sec    = SECEdgarDataConnector(use_mock=use_mock)
        self.cdp    = CDPDataConnector(use_mock=use_mock)
        self.sust   = SustainalyticsConnector(use_mock=use_mock)
        self._all_connectors = [self.sec, self.cdp, self.sust]

    def get_all_metrics(
        self, ticker: str, years: list[int] | None = None
    ) -> list[ExternalDataPoint]:
        all_dps = []
        for conn in self._all_connectors:
            all_dps.extend(conn.get_metrics(ticker, years))
        return all_dps

    def get_metric(
        self, ticker: str, metric_name: str, year: int
    ) -> Optional[ExternalDataPoint]:
        for dp in self.get_all_metrics(ticker, [year]):
            if dp.metric_name == metric_name:
                return dp
        return None

    def available_tickers(self) -> list[str]:
        tickers = set()
        for conn in self._all_connectors:
            tickers.update(conn.get_all_tickers())
        return sorted(tickers)

    def to_dataframe(self, tickers: list[str], years: list[int] | None = None) -> pd.DataFrame:
        all_dps = []
        for ticker in tickers:
            all_dps.extend(self.get_all_metrics(ticker, years))
        return pd.DataFrame([dp.to_dict() for dp in all_dps])

    def save(self, output_dir: Path) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / "external_data_snapshot.json"
        all_dps = []
        for ticker in self.available_tickers():
            all_dps.extend(self.get_all_metrics(ticker))
        with open(path, "w") as f:
            json.dump([dp.to_dict() for dp in all_dps], f, indent=2)
        return path
