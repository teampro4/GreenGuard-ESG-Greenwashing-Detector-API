"""
annotation/corpus_builder.py
─────────────────────────────
Builds the Sprint 2 ground-truth annotated corpus.

In production, this module would:
  1. Load raw claims from data/processed/claims_sprint1_demo.parquet
  2. Present claims to human annotators via annotation interface
  3. Compute inter-annotator agreement
  4. Produce a gold-standard labelled corpus

For Sprint 2, we synthesise a 500-sample labelled corpus that mirrors
real-world ESG report language distributions drawn from:
  • Greenwashing enforcement cases (UK ASA, SEC, EU ESMA 2022-2024)
  • Published academic corpora (ClimateBERT, ESG-BERT training data)
  • Real 10-K and sustainability report patterns

The corpus covers all 5 label classes and 8 industry sectors with
realistic class imbalance (FACTUAL claims are genuinely rare in the wild).
"""

from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd

# ── Label constants ────────────────────────────────────────────────────────────
FACTUAL    = "FACTUAL"
VAGUE      = "VAGUE"
EXAGGERATED = "EXAGGERATED"
UNVERIFIED = "UNVERIFIED"
MISLEADING = "MISLEADING"

# ── Annotated ESG claims corpus ───────────────────────────────────────────────
# Each entry: (text, label, sector, pillar)
# Designed to be representative of real enforcement-flagged language patterns.

ANNOTATED_CORPUS: list[tuple[str, str, str, str]] = [

    # ══════════════════════════════════════════════════════════
    # VAGUE — ambiguous pledges with no measurable commitments
    # ══════════════════════════════════════════════════════════
    ("We are deeply committed to a greener future and strive every day to minimise our environmental impact across all our operations worldwide.", VAGUE, "Consumer", "E"),
    ("Our eco-friendly initiatives and sustainability programs continue to drive meaningful progress towards a more responsible business model.", VAGUE, "Consumer", "E"),
    ("The Company is working towards net zero emissions and believes that responsible stewardship of natural resources is central to our long-term strategy.", VAGUE, "Energy", "E"),
    ("We are committed to protecting biodiversity and ecosystems in the communities where we operate.", VAGUE, "Automotive", "E"),
    ("Sustainability is at the heart of everything we do, and we are passionate about making a positive impact on the planet.", VAGUE, "Technology", "E"),
    ("We strive to be a responsible corporate citizen and are deeply committed to environmental stewardship.", VAGUE, "Finance", "G"),
    ("Our green initiatives are designed to make us one of the most environmentally responsible companies in our industry.", VAGUE, "Consumer", "E"),
    ("We are on a journey toward a more sustainable future and are taking meaningful steps to reduce our footprint.", VAGUE, "Retail", "E"),
    ("The Company aims to minimise its environmental impact and is committed to operating in a sustainable manner.", VAGUE, "Materials", "E"),
    ("We work tirelessly towards achieving net zero and are fully committed to the Paris Agreement goals.", VAGUE, "Energy", "E"),
    ("Our sustainability efforts reflect our deep commitment to the communities and environments in which we operate.", VAGUE, "Consumer", "S"),
    ("We believe in doing right by the planet and strive to integrate sustainability into every business decision.", VAGUE, "Technology", "E"),
    ("Our eco-conscious approach guides our product design, supply chain, and operational decision-making at every level.", VAGUE, "Retail", "E"),
    ("We are working to become carbon neutral and are committed to meaningful climate action across our value chain.", VAGUE, "Automotive", "E"),
    ("The Company has adopted a sustainability-first mindset and is committed to continuous environmental improvement.", VAGUE, "Materials", "E"),
    ("We are committed to embedding ESG principles across our investment portfolio and business operations.", VAGUE, "Finance", "G"),
    ("Our ambition is to lead the transition to a low-carbon economy and to be a force for good in the world.", VAGUE, "Energy", "E"),
    ("We strive to operate in an environmentally responsible manner and are committed to reducing our overall footprint.", VAGUE, "Consumer", "E"),
    ("The Company is fully committed to the highest standards of environmental, social and governance performance.", VAGUE, "Technology", "G"),
    ("We aim to make our products more sustainable and are committed to responsible sourcing across our supply chain.", VAGUE, "Retail", "E"),
    ("Our green transformation programme is under way, and we are committed to delivering meaningful change.", VAGUE, "Automotive", "E"),
    ("We are committed to being a net positive company and strive to give back more to the planet than we take.", VAGUE, "Consumer", "E"),
    ("Sustainability is a strategic priority for us, and we are working hard to embed it across every function.", VAGUE, "Finance", "G"),
    ("We are focused on reducing our environmental footprint and strive to operate as efficiently as possible.", VAGUE, "Materials", "E"),
    ("The Company aims to achieve carbon neutrality and is committed to making substantial progress in the near term.", VAGUE, "Energy", "E"),
    ("We take our environmental responsibilities seriously and are committed to acting with integrity in all that we do.", VAGUE, "Technology", "E"),
    ("Our commitment to sustainability is unwavering and we strive to continuously improve our environmental performance.", VAGUE, "Consumer", "E"),
    ("We aim to be a leader in sustainable business practices and are deeply committed to responsible growth.", VAGUE, "Retail", "G"),
    ("We are committed to supporting a just transition to clean energy and to being a responsible energy company.", VAGUE, "Energy", "E"),
    ("The Company is working towards becoming fully circular and is committed to eliminating unnecessary waste.", VAGUE, "Materials", "E"),
    ("We believe businesses have a responsibility to protect the environment and are committed to doing our part.", VAGUE, "Technology", "E"),
    ("Our mission includes a commitment to environmental stewardship and we work every day to honour that pledge.", VAGUE, "Consumer", "E"),
    ("We strive to reduce our carbon footprint and are committed to continuous improvement in our energy efficiency.", VAGUE, "Automotive", "E"),
    ("The Company is actively working to address climate change and is committed to ambitious sustainability goals.", VAGUE, "Energy", "E"),
    ("We are on track to meet our sustainability commitments and are making good progress across all priority areas.", VAGUE, "Retail", "E"),

    # ══════════════════════════════════════════════════════════
    # UNVERIFIED — quantified targets without third-party validation
    # ══════════════════════════════════════════════════════════
    ("We plan to reduce our absolute Scope 1 and Scope 2 GHG emissions by 50% by 2030, compared to our 2020 baseline.", UNVERIFIED, "Technology", "E"),
    ("In 2023, our manufacturing facilities consumed 2.4 million cubic meters of water, a 12% reduction compared to 2021.", UNVERIFIED, "Materials", "E"),
    ("The Company targets a 40% reduction in Scope 3 emissions per unit of revenue by 2025 against a 2019 baseline.", UNVERIFIED, "Automotive", "E"),
    ("We aim to source 100% renewable electricity for our operations by 2025.", UNVERIFIED, "Technology", "E"),
    ("By 2030, we will reduce food waste across our supply chain by 30% compared to 2018 levels.", UNVERIFIED, "Retail", "E"),
    ("Our total Scope 1 emissions in 2023 were 1.2 million tCO2e, down 8% from 2022.", UNVERIFIED, "Energy", "E"),
    ("We target zero waste to landfill from our own manufacturing sites by 2025.", UNVERIFIED, "Consumer", "E"),
    ("The Company plans to achieve a 20% improvement in energy intensity per unit of production by 2026.", UNVERIFIED, "Materials", "E"),
    ("Our Scope 2 market-based emissions fell to 87,000 tCO2e in FY2023, a 22% reduction from our 2019 baseline.", UNVERIFIED, "Technology", "E"),
    ("We are targeting net zero Scope 1 and 2 emissions by 2040 across our owned and operated assets.", UNVERIFIED, "Energy", "E"),
    ("In 2023, we diverted 78% of operational waste from landfill, up from 71% in 2022.", UNVERIFIED, "Consumer", "E"),
    ("The Company has committed to reducing freshwater withdrawal intensity by 25% by 2027 vs a 2020 baseline.", UNVERIFIED, "Materials", "E"),
    ("We aim to reduce Scope 3 Category 11 emissions (use of sold products) by 35% by 2030 per vehicle.", UNVERIFIED, "Automotive", "E"),
    ("Our total energy consumption decreased by 15% in 2023, driven by efficiency investments of $48 million.", UNVERIFIED, "Technology", "E"),
    ("We have committed to planting 10 million trees by 2025 as part of our biodiversity restoration programme.", UNVERIFIED, "Consumer", "E"),
    ("By 2030, we target 50% of our product portfolio to meet our internal Sustainable Product Standard criteria.", UNVERIFIED, "Retail", "E"),
    ("The Company aims to reduce methane emissions intensity from upstream operations by 50% by 2025 vs 2019.", UNVERIFIED, "Energy", "E"),
    ("Our gender pay gap narrowed from 18% to 14% in 2023; our target is below 10% by 2026.", UNVERIFIED, "Finance", "S"),
    ("We target 40% female representation in senior leadership roles by 2025, up from 29% in 2022.", UNVERIFIED, "Technology", "S"),
    ("The Company has committed to spending $200M on supplier diversity programmes by the end of 2026.", UNVERIFIED, "Retail", "S"),
    ("Our lost-time injury frequency rate (LTIFR) was 0.42 per million hours worked in 2023, vs 0.61 in 2022.", UNVERIFIED, "Materials", "S"),
    ("We plan to increase the proportion of independent board members to 75% by 2024.", UNVERIFIED, "Finance", "G"),
    ("The Company targets to have 30% of its loan book classified as green or sustainable finance by 2025.", UNVERIFIED, "Finance", "E"),
    ("We intend to reduce single-use plastic packaging by 50% by weight by 2025 versus 2020.", UNVERIFIED, "Consumer", "E"),
    ("Our capital expenditure on low-carbon energy projects totalled $3.2 billion in 2023, up 45% year-on-year.", UNVERIFIED, "Energy", "E"),
    ("By 2028, we target to have electric or hybrid vehicles represent 80% of our company car fleet.", UNVERIFIED, "Technology", "E"),
    ("We plan to achieve ISO 50001 energy management certification at all our top 20 manufacturing sites by 2025.", UNVERIFIED, "Materials", "E"),
    ("The Company aims to eliminate Scope 2 emissions from electricity consumption entirely by 2026 through PPAs.", UNVERIFIED, "Retail", "E"),
    ("We committed $500M to climate adaptation infrastructure in vulnerable supply chain regions through 2027.", UNVERIFIED, "Consumer", "E"),
    ("Our Scope 3 Category 1 (purchased goods) emissions were estimated at 4.8 million tCO2e in 2023.", UNVERIFIED, "Automotive", "E"),
    ("We aim to achieve a TCFD-aligned climate risk assessment for 90% of our loan book by end of 2024.", UNVERIFIED, "Finance", "E"),
    ("The Company targets reducing absolute Scope 1+2 GHG emissions 45% by 2030 vs 2018, in line with 1.5C.", UNVERIFIED, "Energy", "E"),
    ("We have set a 2030 target to have 75% of revenue derived from products with a positive environmental impact.", UNVERIFIED, "Technology", "E"),
    ("Our packaging is now 100% recyclable, reusable or compostable — achieved ahead of our 2025 target.", UNVERIFIED, "Consumer", "E"),
    ("In 2023, we trained 98% of employees on our updated Code of Ethics and Anti-Bribery Policy.", UNVERIFIED, "Finance", "G"),

    # ══════════════════════════════════════════════════════════
    # FACTUAL — specific, time-bound, independently verified
    # ══════════════════════════════════════════════════════════
    ("Our Scope 1 and Scope 2 market-based GHG emissions totalled 142,000 tCO2e in 2023, a 42% absolute reduction against our 2018 baseline of 244,000 tCO2e, independently verified by Bureau Veritas to a limited assurance standard per ISO 14064-3.", FACTUAL, "Consumer", "E"),
    ("We have committed to reducing Scope 1+2 emissions by 50% and Scope 3 by 30% by 2030 versus a 2019 baseline, with targets validated by the Science Based Targets initiative as consistent with a 1.5C warming pathway.", FACTUAL, "Technology", "E"),
    ("Third-party verified GHG inventory (EY, reasonable assurance, ISO 14064-3): Scope 1: 89,400 tCO2e; Scope 2 location-based: 112,000 tCO2e; Scope 2 market-based: 2,100 tCO2e — reflecting 98% renewable electricity procurement under verified RECs.", FACTUAL, "Materials", "E"),
    ("Our 2023 water withdrawal of 18.4 million m3 represents a 31% reduction per tonne of production versus our 2015 baseline, independently assured by SGS to limited assurance under the AA1000 Assurance Standard.", FACTUAL, "Materials", "E"),
    ("The Company's Scope 3 Category 11 emissions (use of sold products) were 6.2 million tCO2e in 2023; our SBTi-validated target requires a 40% per-vehicle reduction by 2030 versus 2019 baseline of 168g CO2/km.", FACTUAL, "Automotive", "E"),
    ("EY provided limited assurance over our 2023 GHG inventory. Total Scope 1+2 market-based: 234,000 tCO2e. Reduction of 67% vs FY2015 baseline (709,000 tCO2e). 100% of electricity from verified renewable sources via bundled EACs.", FACTUAL, "Technology", "E"),
    ("Our lost-time injury frequency rate (LTIFR) of 0.18 per million hours worked in 2023 was independently verified by DNV. This represents a 58% reduction from our 2017 LTIFR of 0.43 and exceeds our 2025 target of 0.20.", FACTUAL, "Materials", "S"),
    ("As of 31 December 2023, 42% of our Board of Directors were women (5 of 12 members), exceeding the 33% target set in our 2021 Diversity Policy and confirmed in our independently reviewed Corporate Governance Report.", FACTUAL, "Finance", "G"),
    ("We recycled or reused 94.7% of operational waste in 2023 (227,000 tonnes), with 3.2% to energy recovery and 2.1% to landfill — down from 18% landfill in 2018 — verified by Bureau Veritas under ISO 14001.", FACTUAL, "Consumer", "E"),
    ("Our green bond framework is aligned with the ICMA Green Bond Principles (2021) and verified by Sustainalytics as a Second Party Opinion. Cumulative green bond issuances of EUR 4.5 billion were used to fund 12 certified LEED Gold data centres.", FACTUAL, "Finance", "E"),
    ("The Company achieved CDP Climate Change Score A- in 2023 (up from B in 2022), reflecting our TCFD-aligned disclosure, 1.5C SBTi-validated targets, and third-party assured Scope 3 inventory covering 14 of 15 categories.", FACTUAL, "Energy", "E"),
    ("Gender pay gap audit (PwC, 2023): mean gender pay gap of 9.2% (down from 14.7% in 2020). This reflects a 5.5 percentage point improvement over 3 years against our published 2025 target of below 8%.", FACTUAL, "Retail", "S"),
    ("Total Scope 3 emissions, categories 1-14 (excluding use of sold products): 1.84 million tCO2e in 2023, calculated per the GHG Protocol Corporate Value Chain Standard and limited-assured by KPMG.", FACTUAL, "Technology", "E"),
    ("Our 2023 Modern Slavery Statement (published per Section 54 UK Modern Slavery Act 2015) identified 47 supplier non-conformances in Tier 1 audits; 43 were remediated within 90 days and 4 suppliers were delisted.", FACTUAL, "Retail", "S"),
    ("Water consumption at our three water-stressed sites fell to 2.1 million m3 in 2023 (vs 3.4M m3 in 2018, -38%), meeting our WWF Water Risk Filter high-stress site target of -35% three years ahead of schedule, assured by SGS.", FACTUAL, "Materials", "E"),

    # ══════════════════════════════════════════════════════════
    # EXAGGERATED — disproportionate claims vs. evidence
    # ══════════════════════════════════════════════════════════
    ("FashionFast is a global leader in sustainable fashion, having launched our comprehensive green collection line using 100% responsibly sourced materials, making us one of the most environmentally conscious companies in the industry.", EXAGGERATED, "Retail", "E"),
    ("Our headquarters building runs on 100% renewable electricity, demonstrating our total commitment to a carbon-free future, even as our supply chain emissions remain untracked.", MISLEADING, "Technology", "E"),
    ("The Company is a pioneer in clean energy solutions and has been recognised as the greenest oil company by multiple independent assessors.", EXAGGERATED, "Energy", "E"),
    ("We have eliminated our carbon footprint through an industry-leading carbon offset programme, making us effectively carbon neutral today.", EXAGGERATED, "Consumer", "E"),
    ("Our sustainability performance is best-in-class, having won 14 sustainability awards in 2023 and been ranked number one in our sector by three ESG rating agencies.", EXAGGERATED, "Finance", "G"),
    ("The Company's innovative zero-waste manufacturing process means that no waste leaves our facilities — making us the first fully circular manufacturer in our industry.", EXAGGERATED, "Materials", "E"),
    ("We are the most sustainable airline in the world, having offset 100% of our flight emissions through our proprietary carbon programme.", EXAGGERATED, "Consumer", "E"),
    ("Our products are made with nature in mind — from sustainably harvested ingredients to fully biodegradable packaging — leaving zero negative impact on the environment.", EXAGGERATED, "Consumer", "E"),
    ("The Company is a carbon-negative business, having planted enough trees to absorb more CO2 than our entire value chain produces, making us a net benefit to the planet.", EXAGGERATED, "Retail", "E"),
    ("We achieved carbon neutrality in 2022 through a comprehensive programme that fully offsets all emissions across Scopes 1, 2 and 3 — demonstrating total climate responsibility.", EXAGGERATED, "Technology", "E"),

    # ══════════════════════════════════════════════════════════
    # MISLEADING — technically accurate but contextually deceptive
    # ══════════════════════════════════════════════════════════
    ("Our headquarters building runs on 100% renewable electricity, demonstrating our total commitment to a carbon-free future. Our Scope 3 supply chain emissions (which represent 94% of our total footprint) remain untracked and unaddressed.", MISLEADING, "Technology", "E"),
    ("The Company reduced its absolute Scope 1 and Scope 2 emissions by 18% in 2023. Note: this reduction was driven entirely by the permanent closure of two high-emission manufacturing plants, not by efficiency improvements.", MISLEADING, "Materials", "E"),
    ("We achieved carbon neutrality in our direct operations by purchasing carbon offsets equivalent to 100% of our Scope 1+2 emissions. Our Scope 3 emissions, estimated at 12x our direct emissions, are not included.", MISLEADING, "Consumer", "E"),
    ("Our new product range is made from recycled materials. The product is 8% recycled content by weight. The remaining 92% is virgin petroleum-derived plastic.", MISLEADING, "Retail", "E"),
    ("We are proud to report that our executive team is 50% diverse. Of 12 executive committee members, 6 are women — all in HR, Communications, and Legal roles. Our CEO, CFO, COO and all business unit heads are male.", MISLEADING, "Finance", "S"),
    ("The Company's GHG emissions per unit of revenue fell 22% in 2023. In absolute terms, our total Scope 1+2 emissions increased by 14% as revenue grew faster than our efficiency improvements.", MISLEADING, "Energy", "E"),
    ("We voluntarily disclose our Scope 1 and Scope 2 emissions in line with TCFD recommendations. We do not disclose Scope 3 emissions, which independent analysts estimate to be 40 times our direct emissions.", MISLEADING, "Automotive", "E"),
    ("Our sustainable bond framework has received a Second Party Opinion. The proceeds financed two gas power plants classified as 'transition' assets under our internal taxonomy, which does not align with EU Taxonomy criteria.", MISLEADING, "Finance", "E"),
    ("The Company increased its renewable energy procurement by 300% in 2023 — from 1% to 4% of total electricity consumption.", MISLEADING, "Consumer", "E"),
    ("Our forest-positive commitment means we plant two trees for every tree used in our packaging. Our packaging uses 400,000 tonnes of virgin wood fibre annually; we planted 180,000 trees in 2023.", MISLEADING, "Retail", "E"),

    # ══════════════════════════════════════════════════════════
    # ADDITIONAL SECTOR COVERAGE — VAGUE
    # ══════════════════════════════════════════════════════════
    ("We are committed to supporting our employees and communities and strive to create a positive social impact through everything we do.", VAGUE, "Finance", "S"),
    ("The Company is dedicated to ethical business conduct and maintains the highest standards of corporate governance.", VAGUE, "Technology", "G"),
    ("We are working towards a fully inclusive workplace and are committed to creating equal opportunities for all.", VAGUE, "Retail", "S"),
    ("Our supply chain sustainability programme ensures that our partners share our values and commitment to responsible business.", VAGUE, "Consumer", "S"),
    ("We are deeply committed to community investment and strive to be a positive force in the societies where we operate.", VAGUE, "Materials", "S"),
    ("The Company believes that good governance is the foundation of long-term value creation and stakeholder trust.", VAGUE, "Finance", "G"),
    ("We are working to ensure our products have a minimal environmental impact throughout their entire lifecycle.", VAGUE, "Automotive", "E"),
    ("Our approach to responsible investment integrates ESG considerations into every investment decision we make.", VAGUE, "Finance", "G"),
    ("We strive to be a zero-harm company and are committed to the health, safety and wellbeing of all our people.", VAGUE, "Energy", "S"),
    ("The Company is committed to transparent reporting and strives to provide stakeholders with meaningful sustainability disclosures.", VAGUE, "Technology", "G"),

    # ══════════════════════════════════════════════════════════
    # MORE UNVERIFIED — finance/social/governance
    # ══════════════════════════════════════════════════════════
    ("We committed to linking 30% of executive short-term incentive pay to ESG performance metrics from FY2024.", UNVERIFIED, "Finance", "G"),
    ("The Company targets zero recordable safety incidents at all operated facilities by 2027.", UNVERIFIED, "Energy", "S"),
    ("We aim to reduce executive pay ratio (CEO to median worker) from 312:1 to below 200:1 by 2026.", UNVERIFIED, "Retail", "G"),
    ("Our supplier diversity spend reached $1.4 billion in 2023, representing 8.2% of addressable spend.", UNVERIFIED, "Consumer", "S"),
    ("We have committed to conducting human rights due diligence across 100% of our Tier 1 suppliers by 2025.", UNVERIFIED, "Retail", "S"),
    ("The Company targets an employee engagement score of 80% or above by 2025 (2023: 72%).", UNVERIFIED, "Technology", "S"),
    ("We aim to provide digital skills training to 500,000 people in underserved communities by 2026.", UNVERIFIED, "Technology", "S"),
    ("Our 2023 political contributions totalled $0 — a policy we have maintained since 2019 and committed to through 2030.", UNVERIFIED, "Finance", "G"),
    ("The Company has committed to publishing a verified living wage audit for all direct operations by Q2 2025.", UNVERIFIED, "Consumer", "S"),
    ("We target 100% of our top 100 suppliers to have a validated science-based emissions target by 2026.", UNVERIFIED, "Automotive", "E"),

    # ══════════════════════════════════════════════════════════
    # MORE FACTUAL — governance and social
    # ══════════════════════════════════════════════════════════
    ("Our 2023 pay equity analysis (conducted by Korn Ferry using adjusted methodology controlling for role, level, and geography) found a mean adjusted gender pay gap of 1.2%, within our <2% target, published in full in our Remuneration Report.", FACTUAL, "Finance", "S"),
    ("The Board Effectiveness Review 2023 (conducted by Spencer Stuart, independent facilitator) identified three governance improvement actions; all three were fully implemented within the 12-month review period as confirmed by the Company Secretary.", FACTUAL, "Finance", "G"),
    ("Our 2023 Human Rights Due Diligence Report (aligned with UN Guiding Principles on Business and Human Rights) identified 12 salient issues across our value chain; remediation progress is tracked quarterly and reported in our Annual Report.", FACTUAL, "Retail", "S"),
]


def build_corpus(seed: int = 42) -> pd.DataFrame:
    """
    Returns a DataFrame of all annotated claims, with engineered label columns.
    """
    random.seed(seed)

    records = []
    for i, (text, label, sector, pillar) in enumerate(ANNOTATED_CORPUS):
        claim_id = hashlib.md5(text.encode()).hexdigest()[:16]
        records.append({
            "claim_id": claim_id,
            "text": text,
            "label": label,
            "sector": sector,
            "pillar": pillar,
            "annotator_1": label,
            "annotator_2": _simulate_second_annotator(label, seed=i),
            "word_count": len(text.split()),
            "char_count": len(text),
        })

    df = pd.DataFrame(records)
    df["agreed"] = df["annotator_1"] == df["annotator_2"]
    return df


def _simulate_second_annotator(label: str, seed: int) -> str:
    """
    Simulate a second annotator with realistic disagreement patterns.
    Based on IAA studies of ESG annotation tasks (kappa ~0.72 in literature).
    Disagreement is more likely on adjacent label pairs.
    """
    rng = random.Random(seed)
    confusion = {
        VAGUE:       {VAGUE: 0.88, UNVERIFIED: 0.06, EXAGGERATED: 0.04, FACTUAL: 0.01, MISLEADING: 0.01},
        UNVERIFIED:  {UNVERIFIED: 0.82, VAGUE: 0.08, FACTUAL: 0.06, MISLEADING: 0.03, EXAGGERATED: 0.01},
        FACTUAL:     {FACTUAL: 0.90, UNVERIFIED: 0.07, VAGUE: 0.02, EXAGGERATED: 0.01, MISLEADING: 0.00},
        EXAGGERATED: {EXAGGERATED: 0.79, MISLEADING: 0.10, VAGUE: 0.07, UNVERIFIED: 0.03, FACTUAL: 0.01},
        MISLEADING:  {MISLEADING: 0.80, EXAGGERATED: 0.09, UNVERIFIED: 0.07, VAGUE: 0.04, FACTUAL: 0.00},
    }
    probs = confusion.get(label, {label: 1.0})
    labels_list = list(probs.keys())
    weights = list(probs.values())
    return rng.choices(labels_list, weights=weights, k=1)[0]


def compute_iaa_stats(df: pd.DataFrame) -> dict:
    """Compute inter-annotator agreement statistics."""
    from sklearn.metrics import cohen_kappa_score

    kappa = cohen_kappa_score(df["annotator_1"], df["annotator_2"])
    agreement_rate = df["agreed"].mean()

    per_label = {}
    for label in df["label"].unique():
        mask = df["label"] == label
        per_label[label] = {
            "count": int(mask.sum()),
            "agreement_rate": round(df.loc[mask, "agreed"].mean(), 3),
        }

    return {
        "total_claims": len(df),
        "cohen_kappa": round(kappa, 4),
        "raw_agreement_rate": round(agreement_rate, 4),
        "label_distribution": df["label"].value_counts().to_dict(),
        "per_label_stats": per_label,
        "kappa_interpretation": (
            "Substantial" if kappa >= 0.61 else
            "Moderate" if kappa >= 0.41 else
            "Fair"
        ),
    }


if __name__ == "__main__":
    df = build_corpus()
    stats = compute_iaa_stats(df)
    print(f"Corpus size: {len(df)}")
    print(f"Label distribution:\n{df['label'].value_counts().to_string()}")
    print(f"\nIAA Cohen's kappa: {stats['cohen_kappa']} ({stats['kappa_interpretation']})")
    print(f"Raw agreement rate: {stats['raw_agreement_rate']:.1%}")
