"""
config.py — Centralised configuration loader for ESG Greenwashing Detector.
Loads YAML config, resolves paths relative to project root, and exposes
a typed Config object used across all modules.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent.resolve()


def _load_yaml(path: Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@dataclass
class PathsConfig:
    data_raw: Path
    data_processed: Path
    data_annotated: Path
    outputs: Path
    models: Path
    logs: Path

    def ensure_all(self) -> None:
        """Create all configured directories if they don't exist."""
        for p in vars(self).values():
            p.mkdir(parents=True, exist_ok=True)


@dataclass
class AcquisitionConfig:
    sec_tickers: list[str]
    sec_form_types: list[str]
    sec_years_back: int
    sec_email: str
    gri_base_url: str
    gri_sectors: list[str]
    gri_max_reports: int


@dataclass
class PreprocessingConfig:
    min_sentence_length: int
    max_sentence_length: int
    language: str
    sections_of_interest: list[str]
    spacy_model: str
    batch_size: int


@dataclass
class AnnotationConfig:
    labels: list[str]
    confidence_threshold: float
    min_annotators: int


@dataclass
class MLflowConfig:
    experiment_name: str
    tracking_uri: str
    run_tags: dict[str, str]


@dataclass
class Config:
    project_name: str
    version: str
    sprint: int
    paths: PathsConfig
    acquisition: AcquisitionConfig
    preprocessing: PreprocessingConfig
    annotation: AnnotationConfig
    mlflow: MLflowConfig

    @classmethod
    def from_yaml(cls, config_path: Path | str | None = None) -> "Config":
        if config_path is None:
            config_path = PROJECT_ROOT / "configs" / "config.yaml"
        raw = _load_yaml(Path(config_path))

        p = raw["paths"]
        paths = PathsConfig(
            data_raw=PROJECT_ROOT / p["data_raw"],
            data_processed=PROJECT_ROOT / p["data_processed"],
            data_annotated=PROJECT_ROOT / p["data_annotated"],
            outputs=PROJECT_ROOT / p["outputs"],
            models=PROJECT_ROOT / p["outputs"] / "models",
            logs=PROJECT_ROOT / p["outputs"] / "logs",
        )
        paths.ensure_all()

        acq = raw["acquisition"]
        acquisition = AcquisitionConfig(
            sec_tickers=acq["sec_edgar"]["company_tickers"],
            sec_form_types=acq["sec_edgar"]["form_types"],
            sec_years_back=acq["sec_edgar"]["years_back"],
            sec_email=acq["sec_edgar"]["email"],
            gri_base_url=acq["gri_database"]["base_url"],
            gri_sectors=acq["gri_database"]["sectors"],
            gri_max_reports=acq["gri_database"]["max_reports"],
        )

        pre = raw["preprocessing"]
        preprocessing = PreprocessingConfig(
            min_sentence_length=pre["min_sentence_length"],
            max_sentence_length=pre["max_sentence_length"],
            language=pre["language"],
            sections_of_interest=pre["sections_of_interest"],
            spacy_model=pre["spacy_model"],
            batch_size=pre["batch_size"],
        )

        ann = raw["annotation"]
        annotation = AnnotationConfig(
            labels=ann["greenwashing_labels"],
            confidence_threshold=ann["confidence_threshold"],
            min_annotators=ann["min_annotators"],
        )

        mfl = raw["mlflow"]
        mlflow_cfg = MLflowConfig(
            experiment_name=mfl["experiment_name"],
            tracking_uri=str(PROJECT_ROOT / mfl["tracking_uri"]),
            run_tags=mfl["run_tags"],
        )

        proj = raw["project"]
        return cls(
            project_name=proj["name"],
            version=proj["version"],
            sprint=proj["sprint"],
            paths=paths,
            acquisition=acquisition,
            preprocessing=preprocessing,
            annotation=annotation,
            mlflow=mlflow_cfg,
        )


_instance: Config | None = None


def get_config(config_path: Path | str | None = None) -> Config:
    """Singleton accessor — loads config once, reuses thereafter."""
    global _instance
    if _instance is None:
        _instance = Config.from_yaml(config_path)
        logger.info("Config loaded from %s", config_path or "default")
    return _instance
