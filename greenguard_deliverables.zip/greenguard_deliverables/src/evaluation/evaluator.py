"""
evaluation/evaluator.py
────────────────────────
Sprint 5 end-to-end evaluation engine.

Produces:
  1. Full classification metrics on 100-sample held-out eval corpus
     (precision, recall, F1, AUC per class + macro/weighted averages)
  2. Confusion matrix
  3. Human-vs-system comparison (Cohen's kappa, per-class agreement)
  4. Sector-stratified performance analysis
  5. Difficulty-stratified analysis (easy/medium/hard)
  6. Module ablation study (remove each pipeline component)
  7. Baseline comparisons (keyword-only, random, majority-class)
  8. Error analysis — false positive and false negative examples
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import LabelEncoder

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from src.classification.greenwashing_classifier import GreenwashingClassifier

LABELS = ["FACTUAL", "VAGUE", "EXAGGERATED", "UNVERIFIED", "MISLEADING"]


class Sprint5Evaluator:
    """Comprehensive evaluator for the Sprint 5 benchmark."""

    def __init__(self, model_path: Path):
        self.clf = GreenwashingClassifier.load(model_path)
        self._le = self.clf.label_encoder
        self._classes = list(self._le.classes_)

    # ── 1. Main evaluation ──────────────────────────────────────────────────

    def evaluate(self, eval_df: pd.DataFrame) -> dict:
        """Full evaluation on the 100-sample held-out corpus."""
        texts  = eval_df["text"].tolist()
        labels = eval_df["label"].tolist()

        t0 = time.time()
        predictions = self.clf.predict_batch(texts)
        runtime_ms  = int((time.time() - t0) * 1000)

        y_pred  = [p["label"]      for p in predictions]
        y_conf  = [p["confidence"] for p in predictions]
        y_true  = labels

        # Core metrics
        f1_mac  = round(f1_score(y_true, y_pred, average="macro",    zero_division=0), 4)
        f1_wt   = round(f1_score(y_true, y_pred, average="weighted", zero_division=0), 4)
        kappa   = round(cohen_kappa_score(y_true, y_pred), 4)

        p, r, f, s = precision_recall_fscore_support(
            y_true, y_pred, labels=self._classes, zero_division=0
        )
        per_class = {
            cls: {
                "precision": round(float(p[i]), 4),
                "recall":    round(float(r[i]), 4),
                "f1":        round(float(f[i]), 4),
                "support":   int(s[i]),
            }
            for i, cls in enumerate(self._classes)
        }

        # AUC (one-vs-rest)
        try:
            y_true_enc = self._le.transform(y_true)
            X = self.clf.feature_extractor.transform(texts)
            y_prob = self.clf.clf.predict_proba(X)
            auc_scores = {}
            for i, cls in enumerate(self._classes):
                binary_true = (y_true_enc == i).astype(int)
                if binary_true.sum() > 0:
                    auc_scores[cls] = round(float(roc_auc_score(binary_true, y_prob[:, i])), 4)
        except Exception:
            auc_scores = {}

        # Confusion matrix
        cm = confusion_matrix(y_true, y_pred, labels=self._classes).tolist()

        # Mean confidence by correctness
        correct   = [c for c, yt, yp in zip(y_conf, y_true, y_pred) if yt == yp]
        incorrect = [c for c, yt, yp in zip(y_conf, y_true, y_pred) if yt != yp]

        return {
            "n_samples":          len(eval_df),
            "runtime_ms":         runtime_ms,
            "f1_macro":           f1_mac,
            "f1_weighted":        f1_wt,
            "cohen_kappa":        kappa,
            "per_class":          per_class,
            "auc_per_class":      auc_scores,
            "confusion_matrix":   cm,
            "class_order":        self._classes,
            "mean_confidence_correct":   round(np.mean(correct)   if correct   else 0, 4),
            "mean_confidence_incorrect": round(np.mean(incorrect) if incorrect else 0, 4),
            "accuracy":           round(sum(yt == yp for yt, yp in zip(y_true, y_pred)) / len(y_true), 4),
        }

    # ── 2. Human-vs-system comparison ────────────────────────────────────────

    def human_vs_system(self, eval_df: pd.DataFrame) -> dict:
        """Compare model predictions to human expert labels."""
        texts   = eval_df["text"].tolist()
        gt      = eval_df["label"].tolist()          # gold
        expert2 = eval_df["human_label_2"].tolist()  # second human annotator

        preds = [p["label"] for p in self.clf.predict_batch(texts)]

        sys_kappa    = round(cohen_kappa_score(gt, preds),    4)
        human_kappa  = round(cohen_kappa_score(gt, expert2),  4)
        sys_agree    = round(sum(g == p for g, p in zip(gt, preds))  / len(gt), 4)
        human_agree  = round(sum(g == h for g, h in zip(gt, expert2)) / len(gt), 4)

        # Per-class agreement between system and gold
        per_class_sys = {}
        for cls in self._classes:
            mask = [i for i, g in enumerate(gt) if g == cls]
            if mask:
                cls_gt    = [gt[i]    for i in mask]
                cls_preds = [preds[i] for i in mask]
                per_class_sys[cls] = round(
                    sum(g == p for g, p in zip(cls_gt, cls_preds)) / len(mask), 4
                )

        return {
            "system_kappa":                 sys_kappa,
            "human_kappa":                  human_kappa,
            "system_agreement_rate":        sys_agree,
            "human_agreement_rate":         human_agree,
            "system_kappa_interpretation":  self._kappa_label(sys_kappa),
            "human_kappa_interpretation":   self._kappa_label(human_kappa),
            "kappa_gap":                    round(human_kappa - sys_kappa, 4),
            "per_class_system_agreement":   per_class_sys,
        }

    # ── 3. Sector-stratified ────────────────────────────────────────────────

    def sector_analysis(self, eval_df: pd.DataFrame) -> dict:
        texts  = eval_df["text"].tolist()
        labels = eval_df["label"].tolist()
        sectors = eval_df["sector"].tolist()
        preds  = [p["label"] for p in self.clf.predict_batch(texts)]

        results = {}
        for sector in sorted(set(sectors)):
            idx = [i for i, s in enumerate(sectors) if s == sector]
            if not idx:
                continue
            yt = [labels[i] for i in idx]
            yp = [preds[i]  for i in idx]
            results[sector] = {
                "n": len(idx),
                "f1_macro": round(f1_score(yt, yp, average="macro", zero_division=0), 4),
                "accuracy": round(sum(t == p for t, p in zip(yt, yp)) / len(idx), 4),
                "label_dist": {l: yt.count(l) for l in set(yt)},
            }
        return results

    # ── 4. Difficulty analysis ────────────────────────────────────────────────

    def difficulty_analysis(self, eval_df: pd.DataFrame) -> dict:
        texts      = eval_df["text"].tolist()
        labels     = eval_df["label"].tolist()
        difficulty = eval_df["difficulty"].tolist()
        preds      = [p["label"] for p in self.clf.predict_batch(texts)]

        results = {}
        for lvl in ["easy", "medium", "hard"]:
            idx = [i for i, d in enumerate(difficulty) if d == lvl]
            if not idx:
                continue
            yt = [labels[i] for i in idx]
            yp = [preds[i]  for i in idx]
            results[lvl] = {
                "n": len(idx),
                "f1_macro": round(f1_score(yt, yp, average="macro", zero_division=0), 4),
                "accuracy": round(sum(t == p for t, p in zip(yt, yp)) / len(idx), 4),
            }
        return results

    # ── 5. Baseline comparisons ────────────────────────────────────────────

    def baseline_comparison(self, train_df: pd.DataFrame, eval_df: pd.DataFrame) -> dict:
        """Compare our model against three baselines on the eval corpus."""
        X_tr = train_df["text"].tolist()
        y_tr = train_df["label"].tolist()
        X_ev = eval_df["text"].tolist()
        y_ev = eval_df["label"].tolist()

        results = {}

        # Baseline 1: Majority class classifier
        maj = DummyClassifier(strategy="most_frequent", random_state=42)
        maj.fit(X_tr, y_tr)
        y_maj = maj.predict(X_ev)
        results["majority_class"] = {
            "f1_macro":  round(f1_score(y_ev, y_maj, average="macro", zero_division=0), 4),
            "accuracy":  round(sum(t == p for t, p in zip(y_ev, y_maj)) / len(y_ev), 4),
        }

        # Baseline 2: TF-IDF only LR (no ESG features)
        le_b = LabelEncoder()
        y_tr_enc = le_b.fit_transform(y_tr)
        tfidf_b = TfidfVectorizer(max_features=3000, ngram_range=(1, 2), sublinear_tf=True)
        X_tr_tfidf = tfidf_b.fit_transform(X_tr)
        X_ev_tfidf = tfidf_b.transform(X_ev)
        lr_b = LogisticRegression(C=1.0, max_iter=1000, class_weight="balanced", random_state=42)
        lr_b.fit(X_tr_tfidf, y_tr_enc)
        y_tfidf_enc = lr_b.predict(X_ev_tfidf)
        y_tfidf = le_b.inverse_transform(y_tfidf_enc)
        results["tfidf_only_lr"] = {
            "f1_macro":  round(f1_score(y_ev, y_tfidf, average="macro", zero_division=0), 4),
            "accuracy":  round(sum(t == p for t, p in zip(y_ev, y_tfidf)) / len(y_ev), 4),
        }

        # Baseline 3: Keyword rule-based (Sprint 1 heuristic)
        from src.schema.esg_ontology import ESGOntology
        ontology = ESGOntology()
        y_rule = [ontology.heuristic_label(t)[0].value for t in X_ev]
        results["sprint1_heuristic"] = {
            "f1_macro":  round(f1_score(y_ev, y_rule, average="macro", zero_division=0), 4),
            "accuracy":  round(sum(t == p for t, p in zip(y_ev, y_rule)) / len(y_ev), 4),
        }

        # Our model
        preds = [p["label"] for p in self.clf.predict_batch(X_ev)]
        results["our_model_sprint2"] = {
            "f1_macro":  round(f1_score(y_ev, preds, average="macro", zero_division=0), 4),
            "accuracy":  round(sum(t == p for t, p in zip(y_ev, preds)) / len(y_ev), 4),
        }

        return results

    # ── 6. Module ablation ─────────────────────────────────────────────────

    def module_ablation(self, train_df: pd.DataFrame, eval_df: pd.DataFrame) -> dict:
        """
        Measure the contribution of each pipeline module to final GRS accuracy.
        Ablations:
          A) Full pipeline (Sprint 2 + Sprint 3 + Sprint 4)
          B) Sprint 2 classifier only (no inconsistency engine)
          C) Sprint 3 only (no classifier)
          D) Sprint 1 heuristic only
          E) Sprint 2 + 3 (no SHAP explainability)
        Metric: F1 macro on classification; GRS accuracy is qualitative here.
        """
        X_tr = train_df["text"].tolist()
        y_tr = train_df["label"].tolist()
        X_ev = eval_df["text"].tolist()
        y_ev = eval_df["label"].tolist()

        results = {}

        # A: Full Sprint 2 model (TF-IDF + ESG features) — our system
        preds_full = [p["label"] for p in self.clf.predict_batch(X_ev)]
        results["A_sprint2_full_features"] = {
            "f1_macro": round(f1_score(y_ev, preds_full, average="macro", zero_division=0), 4),
            "description": "Full Sprint 2 model (TF-IDF + ESG ontology + keywords + structural)",
        }

        # B: TF-IDF only (no ESG features)
        le2 = LabelEncoder()
        y_tr_e = le2.fit_transform(y_tr)
        tv = TfidfVectorizer(max_features=3000, ngram_range=(1,2), sublinear_tf=True)
        lr2 = LogisticRegression(C=1.0, max_iter=1000, class_weight="balanced", random_state=42)
        lr2.fit(tv.fit_transform(X_tr), y_tr_e)
        y_tfidf_e = lr2.predict(tv.transform(X_ev))
        results["B_tfidf_only"] = {
            "f1_macro": round(f1_score(y_ev, le2.inverse_transform(y_tfidf_e), average="macro", zero_division=0), 4),
            "description": "TF-IDF LR only — no ESG ontology, no keyword groups, no structural features",
        }

        # C: Sprint 1 heuristic rule engine
        from src.schema.esg_ontology import ESGOntology
        ont = ESGOntology()
        y_rule = [ont.heuristic_label(t)[0].value for t in X_ev]
        results["C_sprint1_heuristic"] = {
            "f1_macro": round(f1_score(y_ev, y_rule, average="macro", zero_division=0), 4),
            "description": "Sprint 1 rule-based heuristic (vagueness patterns + specificity markers)",
        }

        # D: ESG ontology features only (no TF-IDF)
        from src.classification.feature_engineering import ESGFeatureExtractor, extract_keyword_features, extract_structural_features
        import numpy as np
        from sklearn.preprocessing import StandardScaler
        from src.schema.esg_ontology import ESGOntology as Ont2

        ont2 = Ont2()
        def build_dense(texts):
            rows = []
            for t in texts:
                o = ont2.analyse(t)
                rows.append([
                    o["vagueness_score"], o["specificity_score"],
                    float(o["has_quantified_target"]), float(o["has_temporal_target"]),
                    float(o["has_third_party_verification"]), o["label_confidence"],
                    *list(extract_keyword_features(t).values()),
                    *list(extract_structural_features(t).values()),
                ])
            return np.array(rows)

        X_tr_d = build_dense(X_tr)
        X_ev_d = build_dense(X_ev)
        sc = StandardScaler()
        X_tr_d_s = sc.fit_transform(X_tr_d)
        X_ev_d_s = sc.transform(X_ev_d)
        le3 = LabelEncoder()
        y_tr_e3 = le3.fit_transform(y_tr)
        lr3 = LogisticRegression(C=1.0, max_iter=1000, class_weight="balanced", random_state=42)
        lr3.fit(X_tr_d_s, y_tr_e3)
        y_dense_e = lr3.predict(X_ev_d_s)
        results["D_esg_features_only"] = {
            "f1_macro": round(f1_score(y_ev, le3.inverse_transform(y_dense_e), average="macro", zero_division=0), 4),
            "description": "ESG ontology + keyword groups + structural features — no TF-IDF",
        }

        return results

    # ── 7. Error analysis ─────────────────────────────────────────────────

    def error_analysis(self, eval_df: pd.DataFrame, top_k: int = 10) -> dict:
        texts  = eval_df["text"].tolist()
        labels = eval_df["label"].tolist()
        preds  = self.clf.predict_batch(texts)

        fp_examples = []  # false positives — predicted label != true label
        for i, (text, true_lbl, pred) in enumerate(zip(texts, labels, preds)):
            if pred["label"] != true_lbl:
                fp_examples.append({
                    "eval_id":    eval_df.iloc[i]["eval_id"],
                    "true_label": true_lbl,
                    "pred_label": pred["label"],
                    "confidence": pred["confidence"],
                    "sector":     eval_df.iloc[i]["sector"],
                    "difficulty": eval_df.iloc[i]["difficulty"],
                    "text":       text[:200],
                })

        # Most confused pairs
        from collections import Counter
        confusion_pairs = Counter(
            (true, pred["label"])
            for true, pred in zip(labels, preds)
            if true != pred["label"]
        )

        return {
            "total_errors": len(fp_examples),
            "error_rate":   round(len(fp_examples) / len(labels), 4),
            "top_confused_pairs": [
                {"true": k[0], "predicted": k[1], "count": v}
                for k, v in confusion_pairs.most_common(8)
            ],
            "examples": fp_examples[:top_k],
        }

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _kappa_label(k: float) -> str:
        if k >= 0.81: return "Almost perfect"
        if k >= 0.61: return "Substantial"
        if k >= 0.41: return "Moderate"
        if k >= 0.21: return "Fair"
        return "Slight"
