"""
evaluation/eval_corpus.py
──────────────────────────
Sprint 5 evaluation corpus: 100 labelled ESG claims for end-to-end benchmarking.

This corpus is held-out from Sprint 2 training data — no overlap.
It covers:
  • All 5 label classes
  • 6 industry sectors
  • Edge cases: borderline VAGUE/UNVERIFIED, MISLEADING/EXAGGERATED confusion
  • Real-world enforcement patterns (UK ASA 2022-2024, SEC 2023-2024)
  • Multi-language company names (to test robustness)

Also contains:
  • sector_labels: for sector-stratified performance analysis
  • difficulty: "easy" | "medium" | "hard" (for error analysis)
  • human_label_1, human_label_2: simulated expert annotations for IAA
"""

from __future__ import annotations
import random
import pandas as pd
from sklearn.metrics import cohen_kappa_score

FACTUAL    = "FACTUAL"
VAGUE      = "VAGUE"
EXAGGERATED = "EXAGGERATED"
UNVERIFIED = "UNVERIFIED"
MISLEADING = "MISLEADING"

# (text, label, sector, difficulty)
EVAL_CORPUS = [
    # ── VAGUE (25) ──────────────────────────────────────────────────────────
    ("We are fully committed to protecting the environment and will work tirelessly to reduce our impact.", VAGUE, "Consumer", "easy"),
    ("Our sustainability strategy is designed to deliver positive outcomes for people and planet.", VAGUE, "Technology", "easy"),
    ("We strive to operate responsibly and are committed to continuous environmental improvement.", VAGUE, "Energy", "easy"),
    ("The Company is deeply committed to ESG principles and strives to embed them in everything we do.", VAGUE, "Finance", "easy"),
    ("We are working to become a more sustainable business and aim to make a positive difference.", VAGUE, "Retail", "easy"),
    ("Our green transformation journey continues, with meaningful progress across all sustainability pillars.", VAGUE, "Materials", "medium"),
    ("We are committed to net zero and are actively pursuing climate solutions across our value chain.", VAGUE, "Automotive", "medium"),
    ("Sustainability is core to our identity and we strive to lead by example on environmental responsibility.", VAGUE, "Consumer", "medium"),
    ("The Company aims to minimise its environmental footprint and is working to build a greener future.", VAGUE, "Technology", "medium"),
    ("We believe in responsible growth and are committed to managing our business in a sustainable way.", VAGUE, "Finance", "medium"),
    ("Our eco-conscious product innovation programme is designed to reduce lifecycle environmental impact.", VAGUE, "Consumer", "medium"),
    ("We are on a path towards carbon neutrality and are committed to making substantial near-term progress.", VAGUE, "Energy", "hard"),
    ("Our supply chain sustainability programme aims to drive positive change and minimise harm.", VAGUE, "Retail", "hard"),
    ("We strive to be recognised as a leader in responsible business and are committed to continuous improvement.", VAGUE, "Materials", "hard"),
    ("The Company has made significant progress on its sustainability agenda and is committed to going further.", VAGUE, "Automotive", "hard"),
    ("We work every day to reduce our environmental impact and are committed to doing what is right for the planet.", VAGUE, "Consumer", "easy"),
    ("Our mission includes being a force for good and we strive to create lasting positive impact.", VAGUE, "Finance", "easy"),
    ("We are committed to responsible sourcing and aim to ensure our supply chain meets the highest ESG standards.", VAGUE, "Retail", "medium"),
    ("Sustainability is not just a commitment but a way of doing business at our company.", VAGUE, "Technology", "medium"),
    ("We are working towards a lower-carbon future and are committed to ambitious sustainability targets.", VAGUE, "Energy", "medium"),
    ("Our biodiversity programme is designed to protect and restore nature in the regions where we operate.", VAGUE, "Materials", "hard"),
    ("We aim to be a net positive company and to contribute more to society than we take.", VAGUE, "Consumer", "hard"),
    ("The Company is actively exploring ways to reduce its Scope 3 emissions and is committed to making progress.", VAGUE, "Automotive", "hard"),
    ("We are deeply passionate about climate action and strive to integrate it into our business strategy.", VAGUE, "Finance", "medium"),
    ("Our sustainability vision is to be carbon neutral by the end of the decade, and we are working hard to get there.", VAGUE, "Technology", "hard"),

    # ── UNVERIFIED (25) ─────────────────────────────────────────────────────
    ("We reduced our total energy consumption by 18% in 2023 compared to our 2019 baseline.", UNVERIFIED, "Technology", "easy"),
    ("Our Scope 1 GHG emissions were 1.8 million tCO2e in 2023, down 12% year-on-year.", UNVERIFIED, "Energy", "easy"),
    ("In fiscal 2023, we sourced 65% of our electricity from renewable sources, up from 48% in 2022.", UNVERIFIED, "Consumer", "easy"),
    ("We plan to reduce our absolute Scope 1+2 emissions by 45% by 2030 versus a 2019 baseline.", UNVERIFIED, "Materials", "easy"),
    ("Our lost-time injury frequency rate fell to 0.31 per million hours worked in 2023, from 0.44 in 2022.", UNVERIFIED, "Automotive", "easy"),
    ("The Company recycled 84% of its operational waste in 2023, up from 76% the prior year.", UNVERIFIED, "Retail", "easy"),
    ("We have committed to a 30% reduction in water withdrawal intensity by 2025 versus our 2018 baseline.", UNVERIFIED, "Materials", "easy"),
    ("Our Scope 2 market-based emissions were 34,000 tCO2e in FY2023, down 61% from FY2019.", UNVERIFIED, "Technology", "medium"),
    ("Total scope 3 category 1 purchased goods emissions were estimated at 3.2 million tCO2e in 2023.", UNVERIFIED, "Consumer", "medium"),
    ("We have set a target of 40% female representation in senior management by 2026, up from 31% in 2022.", UNVERIFIED, "Finance", "medium"),
    ("Our fleet electrification programme targeted 60% battery-electric vehicles by fiscal 2024.", UNVERIFIED, "Automotive", "medium"),
    ("In 2023 we trained 94% of all employees on climate risk awareness as part of our TCFD implementation.", UNVERIFIED, "Finance", "medium"),
    ("Capital expenditure on low-carbon projects reached $2.1 billion in 2023, representing 28% of total capex.", UNVERIFIED, "Energy", "medium"),
    ("Single-use plastic packaging intensity fell 22% per unit of revenue in 2023 versus our 2020 baseline.", UNVERIFIED, "Retail", "hard"),
    ("Our Scope 3 Category 11 (use of sold products) emissions were 8.4 million tCO2e, a 9% reduction per vehicle.", UNVERIFIED, "Automotive", "hard"),
    ("Supplier ESG assessments covered 78% of our Tier 1 supply chain spend in 2023.", UNVERIFIED, "Consumer", "hard"),
    ("We issued our first sustainability-linked bond in 2023, raising EUR 750 million at a 25bps premium.", UNVERIFIED, "Finance", "hard"),
    ("The Company's methane emissions intensity from upstream operations was 0.14% in 2023.", UNVERIFIED, "Energy", "hard"),
    ("Zero waste to landfill was achieved at 14 of our 18 manufacturing sites by end of 2023.", UNVERIFIED, "Materials", "hard"),
    ("Our adjusted gender pay gap narrowed to 8.4% in 2023, down from 11.2% in 2021.", UNVERIFIED, "Retail", "medium"),
    ("Employee engagement score reached 76% in our 2023 survey, above our 75% target.", UNVERIFIED, "Technology", "easy"),
    ("We planted 2.3 million trees in 2023, bringing our cumulative total to 8.1 million since 2018.", UNVERIFIED, "Consumer", "medium"),
    ("Our Paris-aligned transition plan targets a 50% reduction in Scope 1+2 by 2030 and net zero by 2050.", UNVERIFIED, "Energy", "medium"),
    ("Modern slavery risk assessments were completed for 100% of our high-risk Tier 1 suppliers in 2023.", UNVERIFIED, "Retail", "medium"),
    ("We achieved ISO 14001 certification at all 22 of our owned manufacturing facilities by Q3 2023.", UNVERIFIED, "Materials", "easy"),

    # ── FACTUAL (20) ────────────────────────────────────────────────────────
    ("Our Scope 1 and Scope 2 market-based emissions totalled 89,200 tCO2e in FY2023, a 38% absolute reduction against our FY2017 baseline, independently verified by Lloyd's Register to a limited assurance standard per ISO 14064-3.", FACTUAL, "Technology", "easy"),
    ("Science Based Targets initiative validated our 2030 target — 46% absolute Scope 1+2 reduction and 28% Scope 3 intensity reduction versus 2019 — as 1.5C-aligned in March 2023.", FACTUAL, "Consumer", "easy"),
    ("EY provided limited assurance (AA1000AS v3) over our 2023 GHG inventory: Scope 1 = 2.1 Mt CO2e; Scope 2 market-based = 0.04 Mt CO2e; total Scope 3 categories 1-15 = 24.8 Mt CO2e.", FACTUAL, "Automotive", "easy"),
    ("Our 2023 CDP Climate Change response received an A- score, reflecting TCFD-aligned disclosure, independently assured Scope 3 inventory, and SBTi-validated 1.5C targets.", FACTUAL, "Materials", "medium"),
    ("Board-level pay equity audit (Korn Ferry, 2023, adjusted methodology): mean gender pay gap = 1.8%, within our published <2% target; p-value = 0.043 confirming statistical significance.", FACTUAL, "Finance", "medium"),
    ("Water withdrawal at our three water-stressed manufacturing sites fell to 1.84 million m3 in 2023, a 41% reduction vs 2015 baseline, independently verified by SGS per ISO 14046.", FACTUAL, "Materials", "easy"),
    ("Our GHG inventory was prepared in accordance with the GHG Protocol Corporate Standard and limited-assured by KPMG; total Scope 1: 140,000 tCO2e; total Scope 2 (location-based): 210,000 tCO2e (market-based: 12,000 tCO2e).", FACTUAL, "Consumer", "medium"),
    ("Our 2023 Modern Slavery Statement (Section 54 UK MSA 2015) identified 38 Tier 1 non-conformances; 36 were remediated within the 90-day SLA, 2 resulted in supplier termination, all documented in Appendix D.", FACTUAL, "Retail", "medium"),
    ("Deloitte provided reasonable assurance over our FY2023 Scope 1+2 GHG figures (ISO 14064-3); total: 1.24 million tCO2e, a 52% absolute reduction vs FY2015 baseline of 2.58 million tCO2e.", FACTUAL, "Energy", "hard"),
    ("Our green bond framework (ICMA GBP 2021, Second Party Opinion: Sustainalytics) funded 6 LEED Platinum data centres; 2023 allocation report verified by Bureau Veritas confirmed EUR 420M deployed.", FACTUAL, "Finance", "hard"),
    ("The independently verified (PwC, limited assurance) LTIFR across all operated sites was 0.12 per million hours worked in 2023, representing a 71% reduction from our 2015 baseline of 0.41 and exceeding our 2025 target of 0.15.", FACTUAL, "Materials", "hard"),
    ("Our SBTi-validated near-term target: reduce Scope 1+2 absolute emissions 50% and Scope 3 Category 11 per-vehicle emissions 30% by 2030 vs 2021 baseline; progress independently verified by DNV.", FACTUAL, "Automotive", "hard"),
    ("Third-party verified (SGS, limited assurance) renewable electricity consumption: 98.4% of total electricity in 2023, sourced via 12 long-term PPAs and unbundled RECs compliant with RE100 additionality criteria.", FACTUAL, "Technology", "medium"),
    ("Our pay equity analysis (Willis Towers Watson, 2023) controlling for role, level, experience, and location found a mean adjusted gender pay gap of 0.9% — within statistical noise — disclosed in full in our Remuneration Report.", FACTUAL, "Finance", "easy"),
    ("CDP Water Security Score B in 2023 based on externally verified water stewardship data; freshwater withdrawal intensity (m3/tonne output) fell 28% vs 2019, assured by Bureau Veritas.", FACTUAL, "Consumer", "medium"),
    ("Our Scope 3 Category 1 (purchased goods and services) emissions of 5.6 million tCO2e were calculated using the supplier-specific method per GHG Protocol Scope 3 Standard; 84% of spend covered by supplier-reported data.", FACTUAL, "Retail", "hard"),
    ("Total waste generated: 42,000 tonnes in 2023 (down 31% vs 2020); waste diverted from landfill: 97.3%; verified by DNV under ISO 14001 environmental management system.", FACTUAL, "Materials", "easy"),
    ("Executive remuneration 2023: CEO total pay GBP 4.2M (ratio 182:1 vs median UK employee GBP 23,100); CEO climate KPI weighting 20% of STIP, measured against verified Scope 1+2 reduction target, disclosed in full Remuneration Report.", FACTUAL, "Energy", "medium"),
    ("Our human rights due diligence (aligned with UNGPs, third-party reviewed by BSR) identified 11 salient issues; remediation tracker published quarterly at esg.company.com/human-rights.", FACTUAL, "Consumer", "hard"),
    ("Forest footprint assessment (Preferred by Nature, 2023): 98% of wood pulp sourced from FSC-certified or equivalent forests; residual 2% under time-bound improvement programme with 2025 deadline.", FACTUAL, "Retail", "hard"),

    # ── EXAGGERATED (15) ────────────────────────────────────────────────────
    ("We are the undisputed global leader in sustainable manufacturing, having eliminated all environmental impact from our operations.", EXAGGERATED, "Materials", "easy"),
    ("Our carbon offset programme makes us a carbon-negative company, effectively removing more CO2 from the atmosphere than any other firm in our sector.", EXAGGERATED, "Consumer", "easy"),
    ("We are the most eco-friendly retailer in Europe, recognised by independent analysts as the gold standard for environmental responsibility.", EXAGGERATED, "Retail", "easy"),
    ("Our revolutionary product line is completely circular — every component is either recycled or biodegradable — making it the world's most sustainable offering.", EXAGGERATED, "Technology", "medium"),
    ("By planting one tree for every product sold, we have become fully carbon neutral and are now one of the greenest companies on earth.", EXAGGERATED, "Consumer", "medium"),
    ("The Company has solved its water challenge entirely through our award-winning zero-discharge manufacturing process.", EXAGGERATED, "Materials", "medium"),
    ("We are a climate-positive company — our renewable energy operations generate more clean power than our entire global footprint consumes.", EXAGGERATED, "Energy", "medium"),
    ("Our pioneering ESG framework has been adopted by more Fortune 500 companies than any other sustainability model, making us the definitive leader in corporate sustainability.", EXAGGERATED, "Finance", "hard"),
    ("Through our industry-leading circular economy programme, we have achieved a 100% waste-free manufacturing process — the first company in our sector to reach this milestone.", EXAGGERATED, "Automotive", "hard"),
    ("We have completely decarbonised our global logistics network — every shipment is 100% carbon neutral through our proprietary offset mechanism.", EXAGGERATED, "Retail", "hard"),
    ("Our water stewardship programme has restored the entire watershed in our operating region — we give back three times more water than we consume.", EXAGGERATED, "Materials", "hard"),
    ("Our AI-powered energy optimisation is so advanced it has made our headquarters the first zero-energy building of its kind anywhere in the world.", EXAGGERATED, "Technology", "hard"),
    ("We have completely eliminated single-use plastics from our entire product range globally — making us the first fast-food company to achieve full plastic-free status.", EXAGGERATED, "Consumer", "medium"),
    ("Our transition plan is the most comprehensive and ambitious of any energy company — ensuring we will be fully net zero five years ahead of the Paris Agreement.", EXAGGERATED, "Energy", "hard"),
    ("Our ESG rating is in the top 1% globally, making us the most trusted and responsible company in our industry by any objective measure.", EXAGGERATED, "Finance", "medium"),

    # ── MISLEADING (15) ─────────────────────────────────────────────────────
    ("Our headquarters and all owned offices run on 100% renewable electricity — demonstrating our commitment to a carbon-free future. Our manufacturing plants, which account for 91% of our emissions, use coal-fired power.", MISLEADING, "Consumer", "easy"),
    ("We reduced our Scope 1+2 emissions by 35% last year, driven primarily by the sale of our highest-emitting business unit rather than any operational improvement.", MISLEADING, "Energy", "easy"),
    ("Our new product line uses 100% recycled materials in the outer packaging — the product itself is 96% virgin petroleum-derived plastic.", MISLEADING, "Retail", "easy"),
    ("We achieved carbon neutrality in 2023 by purchasing offsets equivalent to our Scope 1 and Scope 2 emissions. We do not account for Scope 3, which is estimated to be 25 times our direct emissions.", MISLEADING, "Technology", "easy"),
    ("Our workforce is 50% women — we are proud to be a gender-balanced company. All eight members of our executive committee are men.", MISLEADING, "Finance", "medium"),
    ("Emissions per unit of revenue fell 18% in 2023. In absolute terms, total emissions increased by 22% as the company grew faster than our efficiency gains.", MISLEADING, "Materials", "medium"),
    ("We are proud to disclose that our Scope 1 emissions are among the lowest in our peer group. We do not currently disclose Scope 2 or Scope 3 emissions.", MISLEADING, "Automotive", "medium"),
    ("Our sustainable finance framework has financed over $3 billion in green projects. Thirty-seven percent of these proceeds funded gas infrastructure projects classified as transition assets.", MISLEADING, "Finance", "medium"),
    ("Our 2025 net zero commitment covers 100% of our operations. The commitment excludes Scope 3, which accounts for 88% of our total lifecycle emissions.", MISLEADING, "Consumer", "hard"),
    ("We have cut methane intensity in our operated assets by 40% since 2015 — our best performance on record. Absolute methane emissions increased 12% in the same period due to production growth.", MISLEADING, "Energy", "hard"),
    ("Our deforestation-free sourcing policy covers 100% of our direct (Tier 1) suppliers. We have not yet extended this to Tier 2 and beyond, which is where 73% of deforestation risk sits.", MISLEADING, "Retail", "hard"),
    ("We increased our green bond issuance by 200% — from $500M to $1.5B — making us one of the fastest-growing green issuers. The proceeds funded a natural gas pipeline classified under our internal transition taxonomy.", MISLEADING, "Finance", "hard"),
    ("Our CEO pay ratio improved from 287:1 to 195:1 this year — a significant reduction in inequality. The improvement reflects a 40% fall in our median employee wage, not an executive pay cut.", MISLEADING, "Technology", "hard"),
    ("We replant two trees for every tree used in our packaging — a 200% replenishment rate. We use 1.2 million tonnes of virgin wood fibre annually; we planted 180,000 saplings in 2023.", MISLEADING, "Materials", "hard"),
    ("Our electric vehicle programme covers 100% of our European fleet — 3,200 vehicles. This represents 4% of our global fleet of 80,000 vehicles, 96% of which remain diesel or petrol.", MISLEADING, "Automotive", "hard"),
]


def build_eval_corpus(seed: int = 99) -> pd.DataFrame:
    """Build the 100-sample held-out evaluation corpus."""
    rng = random.Random(seed)
    records = []
    for i, (text, label, sector, difficulty) in enumerate(EVAL_CORPUS):
        h2 = _simulate_expert(label, difficulty, seed=i*7+3, rng=rng)
        records.append({
            "eval_id":       f"EVAL_{i+1:03d}",
            "text":           text,
            "label":          label,
            "sector":         sector,
            "difficulty":     difficulty,
            "human_label_1":  label,          # expert 1 — ground truth
            "human_label_2":  h2,             # expert 2 — simulated IAA
            "word_count":     len(text.split()),
        })
    df = pd.DataFrame(records)
    df["human_agree"] = df["human_label_1"] == df["human_label_2"]
    return df


def _simulate_expert(label: str, difficulty: str, seed: int, rng: random.Random) -> str:
    """Simulate a second expert annotator with difficulty-weighted disagreement."""
    # Expert disagreement rates by difficulty
    error_rate = {"easy": 0.04, "medium": 0.12, "hard": 0.22}.get(difficulty, 0.10)
    if rng.random() < error_rate:
        # Confusion patterns — adjacent labels
        confusions = {
            VAGUE:       [UNVERIFIED, MISLEADING],
            UNVERIFIED:  [VAGUE, FACTUAL, MISLEADING],
            FACTUAL:     [UNVERIFIED],
            EXAGGERATED: [MISLEADING, VAGUE],
            MISLEADING:  [EXAGGERATED, UNVERIFIED],
        }
        alternatives = confusions.get(label, [UNVERIFIED])
        return rng.choice(alternatives)
    return label


def compute_eval_iaa(df: pd.DataFrame) -> dict:
    kappa = cohen_kappa_score(df["human_label_1"], df["human_label_2"])
    return {
        "n_samples":        len(df),
        "cohen_kappa":      round(kappa, 4),
        "agreement_rate":   round(df["human_agree"].mean(), 4),
        "kappa_interpret":  "Substantial" if kappa >= 0.61 else "Moderate" if kappa >= 0.41 else "Fair",
        "per_sector":       df.groupby("sector")["human_agree"].mean().round(3).to_dict(),
        "per_difficulty":   df.groupby("difficulty")["human_agree"].mean().round(3).to_dict(),
        "label_dist":       df["label"].value_counts().to_dict(),
    }


if __name__ == "__main__":
    df = build_eval_corpus()
    iaa = compute_eval_iaa(df)
    print(f"Eval corpus: {len(df)} claims")
    print(f"Label dist: {iaa['label_dist']}")
    print(f"IAA kappa:  {iaa['cohen_kappa']} ({iaa['kappa_interpret']})")
    print(f"Agreement:  {iaa['agreement_rate']:.1%}")
    print(f"Per sector: {iaa['per_sector']}")
